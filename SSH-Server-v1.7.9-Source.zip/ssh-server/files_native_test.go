package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"errors"
	"github.com/pkg/sftp"
	"golang.org/x/crypto/ssh"
	"net"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func sftpFixture(t *testing.T) (*Server, Profile, string) {
	t.Helper()
	dir := t.TempDir()
	_, key, _ := ed25519.GenerateKey(rand.Reader)
	signer, _ := ssh.NewSignerFromKey(key)
	cfg := &ssh.ServerConfig{PasswordCallback: func(_ ssh.ConnMetadata, p []byte) (*ssh.Permissions, error) {
		if string(p) != "fixture-password" {
			return nil, errors.New("denied")
		}
		return nil, nil
	}}
	cfg.AddHostKey(signer)
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	var mu sync.Mutex
	var connections []net.Conn
	t.Cleanup(func() {
		ln.Close()
		mu.Lock()
		for _, c := range connections {
			c.Close()
		}
		mu.Unlock()
	})
	go func() {
		for {
			conn, e := ln.Accept()
			if e != nil {
				return
			}
			mu.Lock()
			connections = append(connections, conn)
			mu.Unlock()
			go func() {
				defer conn.Close()
				_, channels, requests, e := ssh.NewServerConn(conn, cfg)
				if e != nil {
					return
				}
				go ssh.DiscardRequests(requests)
				for incoming := range channels {
					ch, reqs, e := incoming.Accept()
					if e != nil {
						return
					}
					go func() {
						defer ch.Close()
						for req := range reqs {
							if req.Type == "subsystem" {
								req.Reply(true, nil)
								server, e := sftp.NewServer(ch, sftp.WithServerWorkingDirectory(dir))
								if e == nil {
									server.Serve()
									server.Close()
								}
								return
							}
							req.Reply(false, nil)
						}
					}()
				}
			}()
		}
	}()
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	number, _ := strconv.Atoi(port)
	p := Profile{ID: "sftp-qa", Name: "QA", Host: "127.0.0.1", Port: number, User: "qa", Auth: "password", HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}}
	st, _ := openStore(t.TempDir())
	st.data.Profiles = []Profile{p}
	s := &Server{store: st, transfers: map[string]*Transfer{}}
	s.sshCredential(p, "fixture-password")
	return s, p, dir
}
func callFileAction(t *testing.T, s *Server, a FileAction) (int, map[string]any) {
	t.Helper()
	b, _ := json.Marshal(a)
	r := httptest.NewRequest("POST", "/api/files/action", bytes.NewReader(b))
	w := httptest.NewRecorder()
	s.filesAction(w, r)
	var result map[string]any
	json.Unmarshal(w.Body.Bytes(), &result)
	return w.Code, result
}
func TestNativeSFTPUnicodeMetadataAndRealPath(t *testing.T) {
	s, p, dir := sftpFixture(t)
	os.Mkdir(filepath.Join(dir, "Folder 10"), 0750)
	os.WriteFile(filepath.Join(dir, "Fișier românesc 2.txt"), []byte("șț Unicode\n"), 0640)
	r := httptest.NewRequest("GET", "/api/files/remote?id="+p.ID+"&path=.", nil)
	w := httptest.NewRecorder()
	s.remoteFiles(w, r)
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	var result struct {
		Path  string
		Items []FileItem
	}
	json.Unmarshal(w.Body.Bytes(), &result)
	if result.Path != dir || len(result.Items) != 2 || result.Items[0].Type != "dir" || result.Items[1].Name != "Fișier românesc 2.txt" || result.Items[1].Permissions != "0640" {
		t.Fatalf("bad listing: %+v", result)
	}
}
func TestNativeTransfersProgressNoOverwriteAndCancel(t *testing.T) {
	s, p, dir := sftpFixture(t)
	local := filepath.Join(t.TempDir(), "upload.bin")
	data := bytes.Repeat([]byte("binary\x00Ș\xff"), 40000)
	os.WriteFile(local, data, 0600)
	remote := filepath.Join(dir, "large.bin")
	var done, total int64
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	e := s.nativeTransfer(ctx, p, "upload", remote, local, "", false, func(d, n int64) { done = d; total = n })
	if e != nil {
		t.Fatal(e)
	}
	if done != int64(len(data)) || total != done {
		t.Fatal("progress inaccurate", done, total)
	}
	if e = s.nativeTransfer(ctx, p, "upload", remote, local, "", false, nil); e == nil {
		t.Fatal("overwrote existing remote file")
	}
	dest := filepath.Join(t.TempDir(), "download.bin")
	if e = s.nativeTransfer(ctx, p, "download", remote, dest, "", false, nil); e != nil {
		t.Fatal(e)
	}
	got, _ := os.ReadFile(dest)
	if !bytes.Equal(data, got) {
		t.Fatal("binary transfer changed data")
	}
	os.WriteFile(dest, []byte("keep"), 0600)
	if e = s.nativeTransfer(ctx, p, "download", remote, dest, "", false, nil); e == nil {
		t.Fatal("overwrote existing local file")
	}
	got, _ = os.ReadFile(dest)
	if string(got) != "keep" {
		t.Fatal("existing local data lost")
	}
	cancelled, c := context.WithCancel(context.Background())
	c()
	if e = s.nativeTransfer(cancelled, p, "download", remote, dest, "", false, nil); e == nil {
		t.Fatal("cancelled operation succeeded")
	}
}
func TestFileActionsCopyMoveAndProtectedEditor(t *testing.T) {
	s, p, dir := sftpFixture(t)
	source := filepath.Join(dir, "config.txt")
	os.WriteFile(source, []byte("before\n"), 0640)
	code, r := callFileAction(t, s, FileAction{ID: p.ID, Action: "read", Path: source})
	if code != 200 {
		t.Fatal(code, r)
	}
	mod := r["modified"].(string)
	code, r = callFileAction(t, s, FileAction{ID: p.ID, Action: "write", Path: source, Content: "after\n", ExpectedModified: mod})
	if code != 200 {
		t.Fatal(code, r)
	}
	backup, _ := os.ReadFile(r["backup"].(string))
	if string(backup) != "before\n" {
		t.Fatal("backup missing")
	}
	got, _ := os.ReadFile(source)
	if string(got) != "after\n" {
		t.Fatal("save failed")
	}
	code, _ = callFileAction(t, s, FileAction{ID: p.ID, Action: "write", Path: source, Content: "lost update", ExpectedModified: "2000-01-01T00:00:00Z"})
	if code == 200 {
		t.Fatal("accepted stale save")
	}
	dest := filepath.Join(dir, "copy.txt")
	code, r = callFileAction(t, s, FileAction{ID: p.ID, Action: "copy", Path: source, Dest: dest})
	if code != 200 {
		t.Fatal(code, r)
	}
	code, _ = callFileAction(t, s, FileAction{ID: p.ID, Action: "rename", Path: source, Dest: dest})
	if code == 200 {
		t.Fatal("rename overwrote destination")
	}
	folder := filepath.Join(dir, "folder")
	os.Mkdir(folder, 0755)
	os.WriteFile(filepath.Join(folder, "inside.txt"), []byte("keep"), 0644)
	code, _ = callFileAction(t, s, FileAction{ID: p.ID, Action: "rmdir", Path: folder})
	if code == 200 {
		t.Fatal("deleted non-empty directory")
	}
	code, _ = callFileAction(t, s, FileAction{ID: p.ID, Action: "copy", Path: folder, Dest: folder + "/child"})
	if code == 200 {
		t.Fatal("recursive self copy accepted")
	}
}
func TestConcurrentUploadsNeverOverwriteEachOther(t *testing.T) {
	s, p, dir := sftpFixture(t)
	remote := filepath.Join(dir, "same.bin")
	var wg sync.WaitGroup
	var mu sync.Mutex
	successes := 0
	for n := 0; n < 3; n++ {
		local := filepath.Join(t.TempDir(), "file.bin")
		os.WriteFile(local, bytes.Repeat([]byte{byte(n + 1)}, 50000), 0600)
		wg.Add(1)
		go func() {
			defer wg.Done()
			ctx, c := context.WithTimeout(context.Background(), 10*time.Second)
			defer c()
			e := s.nativeTransfer(ctx, p, "upload", remote, local, "", false, nil)
			if e == nil {
				mu.Lock()
				successes++
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	if successes != 1 {
		t.Fatalf("%d upload commits succeeded, expected one", successes)
	}
	data, e := os.ReadFile(remote)
	if e != nil || len(data) != 50000 || !bytes.Equal(data, bytes.Repeat(data[:1], 50000)) {
		t.Fatal("concurrent upload corrupted destination", e)
	}
}
