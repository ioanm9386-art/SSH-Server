'use strict';
const path=require('node:path');
const languages=require('./installer-languages.json');
const names=require('app-builder-lib/out/util/langs.js');
for(const entry of languages){names.langIdToName[entry.code.split('_')[0]]=entry.name;names.lcid[entry.code]=entry.lcid;}
// Pinned NSIS contains an unterminated quote in its Hindi installer translation.
// Vendor that single translation with the missing closing quote restored.
const nsisLang=require('app-builder-lib/out/targets/nsis/nsisLang.js');
nsisLang.createAddLangsMacro=function(generator){generator.macro('addLangs',languages.map(entry=>['Hindi','Yoruba'].includes(entry.name)?`!insertmacro MUI_LANGUAGEEX "${path.join(__dirname,'installer-translations').replaceAll('\\','/')}" "${entry.name}"`:`!insertmacro MUI_LANGUAGE "${entry.name}"`));};
// Use electron-builder's own PE uninstaller extractor on Linux, instead of
// executing an intermediate Windows-only uninstaller generator through Wine.
if(process.platform==='linux'){
 const {WineVmManager}=require('app-builder-lib/out/vm/WineVm.js');
 const {UninstallerReader}=require('app-builder-lib/out/targets/nsis/nsisUtil.js');
 const original=WineVmManager.prototype.exec;
 WineVmManager.prototype.exec=function(file,args,options){
  if(path.basename(file)==='SSH-Server-v1.7.9-Setup.exe'&&args.length===0){return UninstallerReader.exec(file,file.replace(/\.exe$/,'.__uninstaller.exe'));}
  return original.call(this,file,args,options);
 };
}
const config=require('./package.json').build;
config.nsis.installerLanguages=languages.map(x=>x.code);
module.exports=require('./signing-config.cjs')(config);
