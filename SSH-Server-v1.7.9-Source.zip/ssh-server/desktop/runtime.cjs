'use strict';
const path = require('node:path');
function parseBackendURL(line) {
 const match = /^SSH Server v[\d.]+ local: (http:\/\/127\.0\.0\.1:(\d+)\/#token=([a-f0-9]{64}))$/.exec(line.trim());
 if (!match || Number(match[2]) < 1 || Number(match[2]) > 65535) return null;
 return match[1];
}
function backendLocation(resourcesPath) { return path.join(resourcesPath,'backend','ssh-server-engine.exe'); }
function trustedURL(url, origin) { try { return new URL(url).origin===origin; } catch { return false; } }
module.exports={parseBackendURL,backendLocation,trustedURL};
