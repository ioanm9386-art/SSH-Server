$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
New-Item -ItemType Directory -Force (Join-Path $PSScriptRoot "backend") | Out-Null
Get-Command go, npm -ErrorAction Stop | Out-Null
Push-Location ..
try {
    go test ./...
    if ($LASTEXITCODE -ne 0) { throw 'Go tests failed' }
    $env:GOOS = 'windows'
    $env:GOARCH = 'amd64'
    $env:CGO_ENABLED = '0'
    go build -buildvcs=false '-ldflags=-H=windowsgui -s -w' -o desktop/backend/ssh-server-engine.exe .
    if ($LASTEXITCODE -ne 0) { throw 'Engine build failed' }
} finally { Pop-Location }
$env:ELECTRON_SKIP_BINARY_DOWNLOAD = '1'
npm ci --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
npm run check
if ($LASTEXITCODE -ne 0) { throw 'Desktop checks failed' }
npm run dist
if ($LASTEXITCODE -ne 0) { throw 'Installer build failed' }
Write-Host 'Installer: dist\SSH-Server-v1.7.9-Setup.exe'

if ($env:SSH_SERVER_SIGN_RELEASE -eq '1') {
    foreach ($file in @('dist\win-unpacked\SSH Server.exe', 'dist\win-unpacked\resources\backend\ssh-server-engine.exe', 'dist\SSH-Server-v1.7.9-Setup.exe')) {
        $signature = Get-AuthenticodeSignature -LiteralPath $file
        if ($signature.Status -ne 'Valid') { throw "Missing or invalid signature: $file" }
    }
    Write-Host 'Verified signed application, SSH engine and installer.'
} else {
    Write-Host 'Unsigned test build. SmartScreen warnings may appear.'
}
