package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"golang.org/x/crypto/ssh"
	"io"
	"net"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func commandFixture178(t *testing.T) (*Server, Profile, <-chan string) {
	t.Helper()
	_, key, _ := ed25519.GenerateKey(rand.Reader)
	signer, _ := ssh.NewSignerFromKey(key)
	cfg := &ssh.ServerConfig{NoClientAuth: true}
	cfg.AddHostKey(signer)
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	var mu sync.Mutex
	var conns []net.Conn
	t.Cleanup(func() {
		ln.Close()
		mu.Lock()
		defer mu.Unlock()
		for _, c := range conns {
			c.Close()
		}
	})
	commands := make(chan string, 50)
	go func() {
		for {
			c, e := ln.Accept()
			if e != nil {
				return
			}
			mu.Lock()
			conns = append(conns, c)
			mu.Unlock()
			go func() {
				defer c.Close()
				_, chs, reqs, e := ssh.NewServerConn(c, cfg)
				if e != nil {
					return
				}
				go ssh.DiscardRequests(reqs)
				for incoming := range chs {
					ch, requests, e := incoming.Accept()
					if e != nil {
						return
					}
					go func() {
						defer ch.Close()
						for req := range requests {
							if req.Type != "exec" {
								req.Reply(false, nil)
								continue
							}
							var msg struct{ Command string }
							ssh.Unmarshal(req.Payload, &msg)
							commands <- msg.Command
							req.Reply(true, nil)
							io.ReadAll(ch)
							if msg.Command == sampler {
								io.WriteString(ch, "SAMPLE 1000 200 100 40 1000 250 100 200 1800 12\n")
								time.Sleep(30 * time.Millisecond)
							} else {
								io.WriteString(ch, `{"ok":true,"result":{"output":"GENERATED-APP-SECRET"}}`+"\n")
							}
							ch.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{0}))
							return
						}
					}()
				}
			}()
		}
	}()
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	n, _ := strconv.Atoi(port)
	st, _ := openStore(t.TempDir())
	p := Profile{ID: "native174", Name: "Fixture", Host: "127.0.0.1", Port: n, User: "qa", Auth: "agent", HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}}
	// NoClientAuth still needs a supported auth configuration; use an unencrypted fixture key.
	p.Auth = "key"
	p.KeyPath = t.TempDir() + "/fixture-key"
	raw, _ := ssh.MarshalPrivateKey(key, "")
	if e := writeFixtureKey174(p.KeyPath, raw); e != nil {
		t.Fatal(e)
	}
	st.data.Profiles = []Profile{p}
	s := &Server{store: st, active: map[string]*Metric{}, cpuPrev: map[string][2]uint64{}, monitors: map[string]*Monitor{}}
	return s, p, commands
}
func TestAppStoreJobOwnerIsolationAndCompletion178(t *testing.T) {
	s, p, commands := commandFixture178(t)
	owner, _ := makeOwner("Owner", "owner-password-test-178")
	s.store.data.Owner = owner
	request := func(a AdminRequest) *httptest.ResponseRecorder {
		raw, _ := json.Marshal(a)
		w := httptest.NewRecorder()
		s.appStoreJobEndpoint(w, httptest.NewRequest("POST", "/api/appstore/jobs", strings.NewReader(string(raw))))
		return w
	}
	a := AdminRequest{ID: p.ID, Action: "package", Params: map[string]any{"packages": []string{"nginx"}}, OwnerPassword: "wrong", Confirmation: "CONFIRM", SudoPassword: "SUDO-SECRET"}
	if w := request(a); w.Code != 403 {
		t.Fatal(w.Code)
	}
	a.OwnerPassword = "owner-password-test-178"
	a.Confirmation = ""
	if w := request(a); w.Code != 400 {
		t.Fatal(w.Code)
	}
	a.Confirmation = "CONFIRM"
	a.Action = "mount"
	if w := request(a); w.Code != 400 {
		t.Fatal(w.Code)
	}
	a.Action = "package"
	if w := request(a); w.Code != 202 {
		t.Fatal(w.Code, w.Body.String())
	}
	select {
	case cmd := <-commands:
		if strings.Contains(cmd, "SUDO-SECRET") || !strings.HasPrefix(cmd, "sudo -S") {
			t.Fatal("credential leaked or privilege wrapper missing")
		}
	case <-time.After(3 * time.Second):
		t.Fatal("SSH not called")
	}
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		w := httptest.NewRecorder()
		s.appStoreJobEndpoint(w, httptest.NewRequest("GET", "/api/appstore/jobs?id="+p.ID, nil))
		var out struct {
			Jobs []AppStoreJob `json:"jobs"`
		}
		json.Unmarshal(w.Body.Bytes(), &out)
		if len(out.Jobs) == 1 && out.Jobs[0].Status == "success" {
			if strings.Contains(w.Body.String(), "SECRET") || strings.Contains(w.Body.String(), "owner-password") {
				t.Fatal("credentials/output exposed")
			}
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("job did not complete")
}
func TestAppStoreSerializesJobsAndBoundsServerHistory178(t *testing.T) {
	s, p, _ := commandFixture178(t)
	owner, _ := makeOwner("Owner", "owner-password-test-178")
	s.store.data.Owner = owner
	s.appStoreJobs = map[string]*AppStoreJob{"existing": {ID: "existing", ServerID: p.ID, Status: "running", Started: time.Now()}}
	a := AdminRequest{ID: p.ID, Action: "package-upgrade", Params: map[string]any{"packages": []string{"nginx"}}, OwnerPassword: "owner-password-test-178", Confirmation: "CONFIRM"}
	raw, _ := json.Marshal(a)
	w := httptest.NewRecorder()
	s.appStoreJobEndpoint(w, httptest.NewRequest("POST", "/api/appstore/jobs", strings.NewReader(string(raw))))
	if w.Code != 409 {
		t.Fatal(w.Code)
	}
	s.store.data.Profiles = append(s.store.data.Profiles, Profile{ID: "other"})
	w = httptest.NewRecorder()
	s.appStoreJobEndpoint(w, httptest.NewRequest("GET", "/api/appstore/jobs?id=other", nil))
	if strings.Contains(w.Body.String(), "existing") {
		t.Fatal("jobs from different profile exposed")
	}
}
