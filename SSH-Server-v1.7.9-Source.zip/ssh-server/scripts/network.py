import json,subprocess,sys,socket,ipaddress,re,time,os

def read(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=8)
        if p.returncode:return {'available':False,'reason':p.stderr.strip()[:250] or 'Permission or tool unavailable'}
        try:return json.loads(p.stdout)
        except ValueError:return p.stdout.strip()
    except Exception:return {'available':False,'reason':'Tool unavailable or timeout'}
def textfile(path):
    try:
        with open(path) as f:return f.read().strip()
    except OSError:return ''
def enrich_links(links):
    if not isinstance(links,list):return links
    for link in links:
        name=link.get('ifname','')
        if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,40}',name):continue
        base='/sys/class/net/'+name
        kind=link.get('linkinfo',{}).get('info_kind','')
        hardware=os.path.exists(base+'/device')
        vpn=kind in ('wireguard','tun','tap','gre','gretap','ipip','sit','vti','xfrm') or name.startswith(('tailscale','wg','tun','tap','zt'))
        link['category']='loopback' if name=='lo' else 'hardware' if hardware else 'vpn' if vpn else 'virtual'
        link['hardware']=hardware;link['wifi']=os.path.isdir(base+'/wireless')
        link['driver']=os.path.basename(os.path.realpath(base+'/device/driver')) if os.path.exists(base+'/device/driver') else ''
        speed=textfile(base+'/speed')
        link['speedMbps']=int(speed) if speed.isdigit() and int(speed)>0 else None
        link['duplex']=textfile(base+'/duplex') or None
    return links
def state():
    counters=[]
    for row in open('/proc/net/dev').readlines()[2:]:
        name,data=row.split(':',1);fields=data.split();counters.append({'name':name.strip(),'rx':int(fields[0]),'tx':int(fields[8])})
    peer=os.environ.get('SSH_CONNECTION','').split()
    access=''
    if peer:
        try:
            address=str(ipaddress.ip_address(peer[0]));route=read(['ip','-j','route','get',address])
            if isinstance(route,list) and route:access=route[0].get('dev','')
        except ValueError:pass
    return {'at':time.time(),'links':enrich_links(read(['ip','-j','-d','link','show'])),'accessInterface':access,'addresses':read(['ip','-j','address','show']),'routes':read(['ip','-j','route','show','table','all']),'ports':read(['ss','-H','-lntu']),'firewall':read(['ufw','status','verbose']),'dns':read(['resolvectl','dns']),'counters':counters}
def diagnostic(a):
    host=a.get('host','')
    try:host=str(ipaddress.ip_address(host))
    except ValueError:
        if not isinstance(host,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.\-]{0,252}',host):raise ValueError('Invalid DNS name or IP')
    if a['action']=='ping':return {'output':read(['ping','-n','-c','3','-W','1','--',host])}
    if a['action']=='tcp':
        port=a.get('port')
        if isinstance(port,bool) or not isinstance(port,int) or not 1<=port<=65535:raise ValueError('Port must be 1–65535')
        start=time.monotonic()
        try:
            with socket.create_connection((host,port),timeout=3):return {'connected':True,'milliseconds':round((time.monotonic()-start)*1000,1)}
        except OSError:return {'connected':False,'message':'TCP connection failed or timed out; this does not identify the blocking device'}
    return {'addresses':sorted(set(x[4][0] for x in socket.getaddrinfo(host,None)))}

def plan(p):
    iface=p.get('interface','')
    if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,40}',iface) or iface=='lo':raise ValueError('Invalid interface')
    if iface not in [x[1] for x in socket.if_nameindex()]:raise ValueError('Interface not found')
    mode=p.get('mode');cfg={}
    if mode=='dhcp':cfg={'dhcp4':True,'addresses':[]}
    elif mode=='static':
        address=ipaddress.ip_interface(p.get('address',''));gateway=ipaddress.ip_address(p.get('gateway',''))
        if address.version!=4 or gateway.version!=4 or gateway not in address.network:raise ValueError('Use IPv4 CIDR and a gateway in the subnet')
        dns=[str(ipaddress.ip_address(x.strip())) for x in p.get('dns','').split(',') if x.strip()]
        cfg={'dhcp4':False,'addresses':[str(address)],'routes':[{'to':'default','via':str(gateway)}],'nameservers':{'addresses':dns}}
    else:raise ValueError('Choose DHCP or static')
    return {'previewOnly':True,'note':'Review existing Netplan merge rules and recovery access before applying. No file was written.','configuration':{'network':{'version':2,'ethernets':{iface:cfg}}}}
if __name__=='__main__':
    try:
        a=json.load(sys.stdin)
        if a.get('action')=='state':result=state()
        elif a.get('action')=='plan':result=plan(a)
        elif a.get('action') in ('dns','ping','tcp'):result=diagnostic(a)
        else:raise ValueError('Unsupported operation')
        print(json.dumps(result))
    except Exception as e:print(json.dumps({'error':str(e)[:250]}));sys.exit(1)
