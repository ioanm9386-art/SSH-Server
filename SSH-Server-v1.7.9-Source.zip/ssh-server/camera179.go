package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type CameraTemplate179 struct {
	ID       string `json:"id"`
	Label    string `json:"label"`
	Camera   string `json:"camera"`
	Recorder string `json:"recorder"`
}
type CameraBrand179 struct {
	ID            string              `json:"id"`
	Name          string              `json:"name"`
	ONVIFPort     int                 `json:"onvifPort"`
	Templates     []CameraTemplate179 `json:"templates"`
	Note          string              `json:"note"`
	Documentation []string            `json:"documentation"`
	CloudSN       bool                `json:"cloudSN"`
}
type CameraConnection179 struct {
	Host         string `json:"host"`
	Port         int    `json:"port"`
	ONVIFPort    int    `json:"onvifPort"`
	HTTPS        bool   `json:"https"`
	DevicePath   string `json:"devicePath"`
	Username     string `json:"username"`
	Password     string `json:"password"`
	Template     string `json:"template"`
	Channel      int    `json:"channel"`
	Substream    bool   `json:"substream"`
	ProfileToken string `json:"profileToken"`
	KeepPassword bool   `json:"keepPassword"`
}
type CameraSaveRequest179 struct {
	ID, Name, Kind, Channel, Source, Group, Brand, Method string
	Connection                                            *CameraConnection179
	KeepExisting                                          bool
}

func brands179() []CameraBrand179 {
	raw, _ := assets.ReadFile("web/camera-brands179.json")
	var data struct {
		Brands []CameraBrand179 `json:"brands"`
	}
	_ = json.Unmarshal(raw, &data)
	return data.Brands
}
func brand179(id string) (CameraBrand179, bool) {
	for _, b := range brands179() {
		if b.ID == id {
			return b, true
		}
	}
	return CameraBrand179{}, id == "generic"
}
func (s *Server) cameraBrands179(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	jsonOut(w, 200, map[string]any{"brands": brands179(), "cloudSN": false, "onvif": true, "discovery": false, "ptz": false})
}
func validateConnection179(c CameraConnection179) error {
	if len(c.Username) > 256 || len(c.Password) > 2048 || strings.ContainsAny(c.Username+c.Password, "\x00\r\n") {
		return errors.New("Invalid device credentials")
	}
	if c.Port < 1 || c.Port > 65535 || c.ONVIFPort < 1 || c.ONVIFPort > 65535 || c.Channel < 1 || c.Channel > 1024 {
		return errors.New("Invalid port or channel number")
	}
	host := strings.Trim(c.Host, "[]")
	if len(host) > 253 || host == "" || strings.ContainsAny(host, "/@?#\\ \r\n\x00") {
		return errors.New("Enter an IP address or hostname, without protocol or port")
	}
	if net.ParseIP(host) == nil && !regexp.MustCompile(`^[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?$`).MatchString(host) {
		return errors.New("Invalid device host")
	}
	if c.DevicePath == "" || len(c.DevicePath) > 500 || !strings.HasPrefix(c.DevicePath, "/") || strings.HasPrefix(c.DevicePath, "//") || strings.ContainsAny(c.DevicePath, "?#\x00\r\n") {
		return errors.New("Invalid ONVIF device service path")
	}
	if len(c.ProfileToken) > 256 {
		return errors.New("Invalid ONVIF profile token")
	}
	return nil
}
func defaults179(c *CameraConnection179, b CameraBrand179) {
	c.Host = strings.Trim(strings.TrimSpace(c.Host), "[]")
	if c.Port == 0 {
		c.Port = 554
	}
	if c.ONVIFPort == 0 {
		c.ONVIFPort = b.ONVIFPort
		if c.ONVIFPort == 0 {
			c.ONVIFPort = 80
		}
	}
	if c.Channel == 0 {
		c.Channel = 1
	}
	if c.DevicePath == "" {
		c.DevicePath = "/onvif/device_service"
	}
}
func decodeConnection179(c LiveCamera) (CameraConnection179, error) {
	var conn CameraConnection179
	if c.ConnectionSecret == "" {
		return conn, errors.New("No saved device connection")
	}
	raw, e := decryptSecret(c.ConnectionSecret)
	if e != nil {
		return conn, e
	}
	e = json.Unmarshal([]byte(raw), &conn)
	return conn, e
}
func connectionView179(c LiveCamera) map[string]any {
	conn, e := decodeConnection179(c)
	if e != nil {
		return nil
	}
	return map[string]any{"host": conn.Host, "port": conn.Port, "onvifPort": conn.ONVIFPort, "https": conn.HTTPS, "devicePath": conn.DevicePath, "username": conn.Username, "hasPassword": conn.Password != "", "template": conn.Template, "channel": conn.Channel, "substream": conn.Substream, "profileToken": conn.ProfileToken}
}
func sourceWithCredentials179(raw, user, password string) (string, error) {
	u, e := validateCameraURL(raw)
	if e != nil {
		return "", e
	}
	if user != "" {
		u.User = url.UserPassword(user, password)
	} else if password != "" {
		return "", errors.New("Enter a username for the device password")
	}
	return u.String(), nil
}
func templateSource179(brand, kind string, c CameraConnection179) (string, error) {
	b, ok := brand179(brand)
	if !ok {
		return "", errors.New("Unknown brand")
	}
	var path string
	for _, t := range b.Templates {
		if t.ID == c.Template {
			path = t.Camera
			if kind != "camera" {
				path = t.Recorder
			}
			break
		}
	}
	if path == "" {
		return "", errors.New("No documented template for this device type. Use ONVIF or an exact RTSP URL")
	}
	stream, sub, han, suffix, mainSub, stream01 := 1, 0, 2, "", "main", "01"
	if c.Substream {
		stream = 2
		sub = 1
		han = 3
		suffix = "2"
		mainSub = "sub"
		stream01 = "02"
	}
	path = strings.NewReplacer("{channel}", strconv.Itoa(c.Channel), "{channel0}", strconv.Itoa(c.Channel-1), "{channel2}", fmt.Sprintf("%02d", c.Channel), "{stream}", strconv.Itoa(stream), "{sub}", strconv.Itoa(sub), "{hanprofile}", strconv.Itoa(han), "{vivosuffix}", suffix, "{mainSub}", mainSub, "{stream01}", stream01).Replace(path)
	raw := "rtsp://" + net.JoinHostPort(c.Host, strconv.Itoa(c.Port)) + path
	return sourceWithCredentials179(raw, c.Username, c.Password)
}
func prepareConnection179(ctx context.Context, a CameraSaveRequest179, old LiveCamera, exists bool) (string, string, error) {
	if a.KeepExisting {
		if !exists {
			return "", "", errors.New("No existing source to keep")
		}
		return "", old.ConnectionSecret, nil
	}
	if a.Method == "sn" {
		return "", "", errors.New("Cloud SN adapter is not configured for this brand. No cloud connection has been attempted")
	}
	if a.Method == "" && a.Connection == nil {
		return a.Source, old.ConnectionSecret, nil
	} // Existing API clients / legacy URLs.
	if a.Method != "ip" && a.Method != "rtsp" && a.Method != "onvif" {
		return "", "", errors.New("Choose IP, RTSP or ONVIF")
	}
	b, ok := brand179(a.Brand)
	if !ok {
		return "", "", errors.New("Choose a known brand or Generic ONVIF / RTSP")
	}
	var c CameraConnection179
	if a.Connection != nil {
		c = *a.Connection
	}
	defaults179(&c, b)
	// Manual URLs do not require a separate host; derive it before validation.
	if a.Method == "rtsp" {
		u, e := validateCameraURL(a.Source)
		if e != nil {
			return "", "", e
		}
		c.Host = u.Hostname()
	}
	if c.KeepPassword {
		saved, e := decodeConnection179(old)
		if !exists || e != nil || saved.Host != c.Host || saved.Username != c.Username {
			return "", "", errors.New("Saved password can only be reused for the same host and username")
		}
		c.Password = saved.Password
	}
	c.KeepPassword = false

	if e := validateConnection179(c); e != nil {
		return "", "", e
	}
	raw := ""
	var e error
	switch a.Method {
	case "ip":
		raw, e = templateSource179(a.Brand, a.Kind, c)
	case "rtsp":
		raw, e = sourceWithCredentials179(a.Source, c.Username, c.Password)
	case "onvif":
		var result ONVIFResult179
		result, e = readONVIF179(ctx, c, true)
		raw = result.Source
	}
	if e != nil {
		return "", "", e
	}
	if _, e = validateCameraURL(raw); e != nil {
		return "", "", e
	}
	encoded, _ := json.Marshal(c)
	secret, e := encryptSecret(string(encoded))
	return raw, secret, e
}
func (s *Server) cameraONVIF179(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct {
		ID         string              `json:"id"`
		Brand      string              `json:"brand"`
		Connection CameraConnection179 `json:"connection"`
	}
	if body(r, &a) != nil {
		fail(w, 400, "Invalid ONVIF request")
		return
	}
	b, ok := brand179(a.Brand)
	if !ok {
		fail(w, 400, "Unknown brand")
		return
	}
	defaults179(&a.Connection, b)
	if a.Connection.KeepPassword {
		old, exists := s.findCamera(a.ID)
		saved, e := decodeConnection179(old)
		if !exists || e != nil || saved.Host != a.Connection.Host || saved.Username != a.Connection.Username {
			fail(w, 400, "Cannot reuse saved password for another device")
			return
		}
		a.Connection.Password = saved.Password
	}
	if e := validateConnection179(a.Connection); e != nil {
		fail(w, 400, e.Error())
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 40*time.Second)
	defer cancel()
	result, e := readONVIF179(ctx, a.Connection, false)
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	result.Source = ""
	jsonOut(w, 200, result)
}
