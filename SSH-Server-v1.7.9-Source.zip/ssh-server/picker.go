package main

import (
	"context"
	"net/http"
	"os"
	"sync"
	"time"
)

var pickerMu sync.Mutex

func (s *Server) pickEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var request struct {
		Kind    string `json:"kind"`
		Initial string `json:"initial"`
	}
	if body(r, &request) != nil || (request.Kind != "folder" && request.Kind != "key" && request.Kind != "ffmpeg") || len(request.Initial) > 4096 {
		fail(w, 400, "Selecție invalidă.")
		return
	}
	if !pickerMu.TryLock() {
		fail(w, 409, "Există deja o fereastră de selecție deschisă. Verifică ferestrele Windows.")
		return
	}
	defer pickerMu.Unlock()
	ctx, cancel := context.WithTimeout(r.Context(), 5*time.Minute)
	defer cancel()
	chosen, err := pickWindowsPath(ctx, request.Kind, request.Initial)
	if err != nil {
		fail(w, 500, "Nu am putut deschide selectorul Windows: "+err.Error())
		return
	}
	if chosen == "" {
		jsonOut(w, 200, map[string]any{"cancelled": true})
		return
	}
	info, err := os.Stat(chosen)
	if err != nil {
		fail(w, 400, "Calea selectată nu este accesibilă.")
		return
	}
	if request.Kind == "folder" && !info.IsDir() {
		fail(w, 400, "Selectează un director.")
		return
	}
	if request.Kind != "folder" && !info.Mode().IsRegular() {
		fail(w, 400, "Selectează fișierul unei chei private SSH.")
		return
	}
	jsonOut(w, 200, map[string]any{"path": chosen, "cancelled": false})
}
