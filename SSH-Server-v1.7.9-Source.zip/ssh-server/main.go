package main

import (
	"context"
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
)

//go:embed web/*
var assets embed.FS

const version = "1.7.9"

type Server struct {
	appStoreMu   sync.Mutex
	appStoreJobs map[string]*AppStoreJob

	cameraPlaybackActive int
	energyMu             sync.Mutex
	transferSlots        chan struct{}
	credentials          map[string]string
	camerasMu            sync.Mutex
	cameraJobs           map[string]*CameraJob
	activeLive           int
	store                *Store
	token                string
	addr                 string
	sessions             map[string]*SSHSession
	mu                   sync.Mutex
	active               map[string]*Metric
	cpuPrev              map[string][2]uint64
	monitors             map[string]*Monitor
	automationMu         sync.Mutex
	automationRunning    map[string]bool
	transfers            map[string]*Transfer
}

func randHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}
func jsonOut(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func fail(w http.ResponseWriter, status int, message string) {
	jsonOut(w, status, map[string]string{"error": message})
}
func body(r *http.Request, dest any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 2<<20)
	d := json.NewDecoder(r.Body)
	d.DisallowUnknownFields()
	return d.Decode(dest)
}
func (s *Server) auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-SSH-Token") != s.token && r.URL.Query().Get("auth") != s.token {
			fail(w, 401, "Sesiunea locală nu este autorizată.")
			return
		}
		if r.Method != "GET" && r.Method != "HEAD" && r.Method != "OPTIONS" {
			origin := r.Header.Get("Origin")
			if origin != "" && origin != "http://"+s.addr {
				fail(w, 403, "Origine invalidă.")
				return
			}
		}
		next(w, r)
	}
}
func (s *Server) handle(w http.ResponseWriter, r *http.Request) {
	host := r.Host
	if !(host == s.addr || host == "localhost:"+strings.Split(s.addr, ":")[1]) {
		http.Error(w, "Invalid host", 403)
		return
	}
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Referrer-Policy", "no-referrer")
	w.Header().Set("X-Frame-Options", "DENY")
	w.Header().Set("Cross-Origin-Opener-Policy", "same-origin")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self' ws://127.0.0.1:* ws://localhost:*; object-src 'none'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
	if strings.HasPrefix(r.URL.Path, "/api/") || strings.HasPrefix(r.URL.Path, "/ws/") {
		s.auth(s.api)(w, r)
		return
	}
	if r.URL.Path == "/" {
		b, e := assets.ReadFile("web/index.html")
		if e != nil {
			http.Error(w, "HTML missing", 500)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write(b)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/")
	if !strings.HasPrefix(path, "web/") || strings.Contains(path, "..") {
		http.NotFound(w, r)
		return
	}
	b, e := assets.ReadFile(path)
	if e != nil {
		http.NotFound(w, r)
		return
	}
	switch filepath.Ext(path) {
	case ".css":
		w.Header().Set("Content-Type", "text/css; charset=utf-8")
	case ".js":
		w.Header().Set("Content-Type", "application/javascript; charset=utf-8")
	case ".png":
		w.Header().Set("Content-Type", "image/png")
	case ".svg":
		w.Header().Set("Content-Type", "image/svg+xml")
	}
	_, _ = w.Write(b)
}
func (s *Server) api(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/api/")
	if strings.HasPrefix(r.URL.Path, "/ws/") {
		s.websocket(w, r)
		return
	}
	switch path {
	case "access/test":
		s.accessTest(w, r)
	case "appstore/state":
		s.appStoreState(w, r)
	case "appstore/jobs":
		s.appStoreJobEndpoint(w, r)
	case "admin/inventory":
		s.adminInventory(w, r)
	case "admin/operation":
		s.adminOperation(w, r)
	case "admin/capabilities":
		adminCapability(w, r)
	case "bootstrap":
		s.bootstrap(w, r)
	case "setup":
		s.setup(w, r)
	case "overview":
		s.overview(w, r)
	case "profiles":
		s.profiles(w, r)
	case "profiles/trust":
		s.trustProfile(w, r)
	case "ssh/credentials":
		s.credentialsEndpoint(w, r)
	case "livecam/brands":
		s.cameraBrands179(w, r)
	case "livecam/onvif":
		s.cameraONVIF179(w, r)
	case "livecam/archive":
		s.cameraArchive(w, r)
	case "livecam/archive/file":
		s.cameraArchiveFile(w, r)
	case "livecam/playback":
		s.cameraPlayback(w, r)
	case "livecam":
		s.liveCameras(w, r)
	case "livecam/stream":
		s.cameraStream(w, r)
	case "livecam/record":
		s.cameraRecord(w, r)
	case "livecam/stop":
		s.cameraStop(w, r)
	case "livecam/settings":
		s.cameraSettings(w, r)
	case "ssh/scan":
		s.scanEndpoint(w, r)
	case "ssh/connect":
		s.connectEndpoint(w, r)
	case "ssh/close":
		s.closeEndpoint(w, r)
	case "ssh/sessions":
		s.sessionsEndpoint(w, r)
	case "ssh/exec":
		s.execEndpoint(w, r)
	case "native/pick":
		s.pickEndpoint(w, r)
	case "files/local":
		s.localFiles(w, r)
	case "files/locations":
		s.remoteLocations(w, r)
	case "files/remote":
		s.remoteFiles(w, r)
	case "files/action":
		s.filesAction(w, r)
	case "files/transfers":
		s.transfersEndpoint(w, r)
	case "files/cancel":
		s.cancelTransfer(w, r)
	case "energy":
		s.energyEndpoint(w, r)
	case "energy/sample":
		s.energySampleEndpoint(w, r)
	case "network/state":
		s.networkState(w, r)
	case "network/diagnose":
		s.networkDiagnose(w, r)
	case "automations":
		s.automationsEndpoint(w, r)
	case "automations/run":
		s.automationRunEndpoint(w, r)
	case "monitor/start":
		s.monitorStart(w, r)
	case "monitor/stop":
		s.monitorStop(w, r)
	case "monitor/state":
		s.monitorState(w, r)
	case "monitor/history":
		s.monitorHistory(w, r)
	case "monitor/processes":
		s.monitorProcesses(w, r)
	case "journal":
		s.journal(w, r)
	case "journal/export":
		s.exportJournal(w, r)
	case "settings":
		s.settings(w, r)
	case "security/verify":
		s.verifyOwner(w, r)
	case "security/totp/setup":
		s.totpSetup(w, r)
	case "security/totp/enable":
		s.totpEnable(w, r)
	case "security/totp/disable":
		s.totpDisable(w, r)
	case "security/totp/recover":
		s.totpRecover(w, r)
	case "security/password":
		s.changePassword(w, r)
	case "backup/create":
		s.backupCreate(w, r)
	case "backup/list":
		s.backupList(w, r)
	case "backup/restore":
		s.backupRestore(w, r)
	default:
		fail(w, 404, "Funcție indisponibilă.")
	}
}
func (s *Server) bootstrap(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	d := s.store.snapshot()
	configured := d.Owner != nil
	owner := ""
	if configured {
		owner = d.Owner.Name
	}
	jsonOut(w, 200, map[string]any{"version": version, "configured": configured, "owner": owner, "language": d.Settings.Language, "profiles": len(d.Profiles), "platform": runtime.GOOS, "localMode": true, "features": map[string]bool{"remoteBackend": false, "androidAPK": false, "webClient": false, "windowsDesktop": runtime.GOOS == "windows"}})
}
func (s *Server) overview(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	d := s.store.snapshot()
	s.mu.Lock()
	activeSSH := 0
	sessionSummaries := []map[string]string{}
	for _, ss := range s.sessions {
		if !ss.closed {
			activeSSH++
			sessionSummaries = append(sessionSummaries, map[string]string{"id": ss.ID, "server": ss.Profile.Name})
		}
	}
	metrics := make([]Metric, 0, len(s.active))
	for _, m := range s.active {
		metrics = append(metrics, *m)
	}
	s.mu.Unlock()
	jsonOut(w, 200, map[string]any{"servers": len(d.Profiles), "activeSSH": activeSSH, "monitoring": metrics, "recent": lastLogs(d.Logs, 8), "sessions": sessionSummaries, "owner": ownerName(d)})
}
func ownerName(d Data) string {
	if d.Owner == nil {
		return "Owner"
	}
	return d.Owner.Name
}
func main() {
	if os.Getenv("SSH_SERVER_ASKPASS_MODE") == "1" {
		fmt.Print(os.Getenv("SSH_SERVER_ASKPASS_VALUE"))
		return
	}
	desktopMode := flag.Bool("desktop", false, "Desktop launcher owns engine lifetime")
	serveOnly := flag.Bool("no-open", false, "Do not open the application window")
	listenPort := flag.Int("port", 0, "Local port, 0 selects a free port")
	dataDir := flag.String("data-dir", "", "Custom local data directory")
	flag.Parse()
	if *desktopMode {
		release, err := desktopGuard()
		if err != nil {
			log.Fatal(err)
		}
		defer release()
	}

	dir := *dataDir
	if dir == "" {
		if runtime.GOOS == "windows" {
			dir = filepath.Join(os.Getenv("LOCALAPPDATA"), "SSH Server")
		} else {
			base, _ := os.UserConfigDir()
			dir = filepath.Join(base, "ssh-server-v1.1")
		}
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		log.Fatal(err)
	}
	store, err := openStore(dir)
	if err != nil {
		log.Fatal(err)
	}
	s := &Server{store: store, token: randHex(32), sessions: map[string]*SSHSession{}, active: map[string]*Metric{}, cpuPrev: map[string][2]uint64{}, monitors: map[string]*Monitor{}, transfers: map[string]*Transfer{}}
	automationCtx, stopAutomations := context.WithCancel(context.Background())
	defer stopAutomations()
	go s.automationScheduler(automationCtx)
	go s.energyLoop(automationCtx)
	ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", *listenPort))
	if err != nil {
		log.Fatal(err)
	}
	s.addr = ln.Addr().String()
	httpServer := &http.Server{Handler: http.HandlerFunc(s.handle), ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 45 * time.Second, MaxHeaderBytes: 8192}
	url := "http://" + s.addr + "/#token=" + s.token
	fmt.Println("SSH Server v"+version+" local:", url)
	if !*serveOnly {
		go func() { time.Sleep(350 * time.Millisecond); openAppWindow(url) }()
	}
	// A daily automatic backup is created only when the Owner configuration exists.
	go func() {
		ticker := time.NewTicker(24 * time.Hour)
		defer ticker.Stop()
		s.makeAutomaticBackup()
		for range ticker.C {
			s.makeAutomaticBackup()
		}
	}()
	if *desktopMode {
		go func() {
			_, _ = io.Copy(io.Discard, os.Stdin)
			s.stopAllCameras()
			s.mu.Lock()
			for _, transfer := range s.transfers {
				transfer.cancel()
			}
			for _, monitor := range s.monitors {
				monitor.cancel()
			}
			for _, session := range s.sessions {
				session.closeTransport()
			}
			s.mu.Unlock()
			_ = httpServer.Close()
		}()
	}
	if err := httpServer.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}
func openAppWindow(url string) {
	if runtime.GOOS == "windows" {
		log.Print("Start SSH Server from the installed desktop shortcut.")
		return
	}
	for _, command := range []string{"xdg-open", "open"} {
		if p, err := exec.LookPath(command); err == nil {
			_ = exec.Command(p, url).Start()
			return
		}
	}
}
func exists(path string) bool { _, err := os.Stat(path); return err == nil }
func lastLogs(logs []JournalEntry, n int) []JournalEntry {
	if len(logs) > n {
		return logs[len(logs)-n:]
	}
	return logs
}
func trimSpace(s string, max int) string {
	s = strings.TrimSpace(s)
	if len(s) > max {
		s = s[:max]
	}
	return s
}
func copyFile(src, dest string) error {
	in, e := os.Open(src)
	if e != nil {
		return e
	}
	defer in.Close()
	out, e := os.OpenFile(dest, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	defer out.Close()
	_, e = io.Copy(out, in)
	return e
}
func embeddedIndex() (fs.File, error) { return assets.Open("web/index.html") }
func withDeadline(ctx context.Context, d time.Duration) (context.Context, context.CancelFunc) {
	return context.WithTimeout(ctx, d)
}
