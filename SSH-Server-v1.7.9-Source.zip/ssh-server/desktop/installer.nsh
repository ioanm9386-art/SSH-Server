; Private data lives outside the application directory chosen in the wizard.
!macro customInstall
  CreateDirectory "$LOCALAPPDATA\SSH Server\backups"
  IfFileExists "$LOCALAPPDATA\SSH Server\data.json" 0 dataBackupDone
  IfFileExists "$LOCALAPPDATA\SSH Server\backups\ssh-server-before-v1.7.9.json" dataBackupDone 0
  ClearErrors
  CopyFiles /SILENT "$LOCALAPPDATA\SSH Server\data.json" "$LOCALAPPDATA\SSH Server\backups\ssh-server-before-v1.7.9.json"
  IfErrors 0 dataBackupDone
  MessageBox MB_ICONSTOP "Could not back up SSH Server data. Close the application, check disk permissions and retry."
  Abort
  dataBackupDone:
  FileOpen $0 "$LOCALAPPDATA\SSH Server\install-language.json" w
  ${If} $LANGUAGE == 1048
    FileWrite $0 '{$\"language$\":$\"ro$\"}'
  ${Else}
    FileWrite $0 '{$\"language$\":$\"en$\"}'
  ${EndIf}
  FileClose $0
!macroend
