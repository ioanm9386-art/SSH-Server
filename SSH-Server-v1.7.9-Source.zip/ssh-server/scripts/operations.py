import json,os,sys,subprocess,base64,re,shutil,stat,ipaddress,tempfile
from pathlib import Path
APP_BASE="/opt/ssh-server-apps"
os.environ["LC_ALL"]="C"

def run(args,timeout=120):
    p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
    if p.returncode:raise ValueError((p.stderr or p.stdout)[-1600:] or 'Operation failed')
    return p.stdout[-100000:]
def clean(s,pattern):
    if not isinstance(s,str) or not re.fullmatch(pattern,s):raise ValueError('Invalid input')
    return s

def install(a):
    if os.geteuid()!=0:raise ValueError('Administrator privileges required')
    user=os.environ.get('SUDO_USER','')
    if not user or user=='root':raise ValueError('Install using a non-root SSH account with sudo')
    import pwd
    owner=pwd.getpwnam(user)
    os.makedirs('/opt/ssh-server-agent',mode=0o755,exist_ok=True)
    if os.path.islink('/opt/ssh-server-agent'):raise ValueError('Unsafe install directory')
    for name in ('inventory.py','agent.py','ddns.py'):
        data=base64.b64decode(a['files'][name],validate=True)
        if len(data)>200000:raise ValueError('Invalid agent file')
        file='/opt/ssh-server-agent/'+name
        if os.path.islink(file):raise ValueError('Unsafe install file')
        with open(file+'.new','wb') as f:f.write(data)
        os.chmod(file+'.new',0o644);os.replace(file+'.new',file)
    base='/var/lib/ssh-server-agent'
    if os.path.islink(base):raise ValueError('Unsafe data directory')
    os.makedirs(base,mode=0o700,exist_ok=True);os.chown(base,owner.pw_uid,owner.pw_gid)
    service='''[Unit]\nDescription=SSH Server monitoring and alarms\nAfter=network-online.target\nWants=network-online.target\n[Service]\nType=simple\nUser=%s\nGroup=%s\nExecStart=/usr/bin/python3 /opt/ssh-server-agent/agent.py\nRestart=on-failure\nRestartSec=10\nUMask=0077\nNoNewPrivileges=true\nPrivateTmp=true\nProtectSystem=strict\nProtectHome=true\nReadWritePaths=/var/lib/ssh-server-agent\n[Install]\nWantedBy=multi-user.target\n'''%(owner.pw_name,owner.pw_gid)
    unit='/etc/systemd/system/ssh-server-agent.service'
    if os.path.islink(unit):raise ValueError('Unsafe service file')
    with open(unit,'w') as f:f.write(service)
    run(['systemctl','daemon-reload']);run(['systemctl','enable','ssh-server-agent.service']);run(['systemctl','restart','ssh-server-agent.service'])
    return {'message':'Monitoring service installed. First inventory can take up to one minute.'}

def operation(a):
    action=a['action'];p=a.get('params',{})
    if action=='dns-flush':return {'output':run(['resolvectl','flush-caches'])}
    if action=='agent-install':return install(a)
    if action=='agent-state':
        with open('/var/lib/ssh-server-agent/state.json') as f:return json.load(f)
    if action=='agent-smtp':
        from email.utils import parseaddr
        c={k:p.get(k,'') for k in ('host','username','password','from','to','mode')};c['port']=int(p.get('port',587));c['enabled']=bool(p.get('enabled',False))
        if not 1<=c['port']<=65535 or c['mode'] not in ('tls','starttls'):raise ValueError('Choose TLS or STARTTLS')
        for k in ('host','username','password','from','to'):
            if not isinstance(c[k],str) or len(c[k])>1000 or '\n' in c[k] or '\r' in c[k]:raise ValueError('Invalid SMTP configuration')
        if c['enabled'] and (not c['host'] or any('@' not in parseaddr(c[k])[1] for k in ('from','to'))):raise ValueError('SMTP host and email addresses required')
        base='/var/lib/ssh-server-agent';temp=base+'/config.json.tmp'
        try:
            with open(base+'/config.json') as f:config=json.load(f)
        except (OSError,ValueError):config={}
        config['smtp']=c
        with open(temp,'w') as f:json.dump(config,f)
        os.chmod(temp,0o600);os.replace(temp,base+'/config.json')
        if p.get('test'):
            sys.path.insert(0,'/opt/ssh-server-agent');from agent import mail
            mail({'smtp':c},'Test notification','SSH Server email configuration test.')
        return {'message':'SMTP settings saved. Test sent if requested.'}
    if action=='ddns':
        configfile='/var/lib/ssh-server-agent/config.json'
        try:
            with open(configfile) as f:config=json.load(f)
        except (OSError,ValueError):config={}
        sys.path.insert(0,'/opt/ssh-server-agent');from ddns import update
        if p.get('enabled'):
            result=update(p)
        else:result='Disabled'
        config['ddns']=p
        with open(configfile+'.tmp','w') as f:json.dump(config,f)
        os.chmod(configfile+'.tmp',0o600);os.replace(configfile+'.tmp',configfile)
        return {'message':result}
    if action=='service':
        name=clean(p.get('name'),r'[A-Za-z0-9_@.:\-]{1,160}\.service');verb=p.get('verb')
        if verb not in ('start','stop','restart','enable','disable'):raise ValueError('Invalid service operation')
        if name in ('ssh.service','sshd.service','systemd-networkd.service','NetworkManager.service','ssh-server-agent.service','networking.service','systemd-resolved.service','tailscaled.service','dbus.service') or name.startswith(('ssh@','sshd@','wg-quick@','openvpn')):raise ValueError('Critical access services cannot be changed from this operation')
        return {'output':run(['systemctl',verb,'--',name])}
    if action=='service-logs':
        name=clean(p.get('name'),r'[A-Za-z0-9_@.:\-]{1,160}\.service')
        return {'output':run(['journalctl','--no-pager','-n','100','-u',name])}
    if action in ('package','package-upgrade'):
        allowed={'smartmontools','mdadm','samba','nfs-kernel-server','docker.io','docker-compose-v2','curl','python3-yaml','ufw','miniupnpc','nginx','apache2','redis-server','mariadb-server','postgresql','git','python3','build-essential','nodejs','npm','ffmpeg','fail2ban','wireguard-tools','rclone','rsync','restic','borgbackup','htop','btop','glances','prometheus','cron','ansible','unzip','zip','ncdu','jq','wget'}
        packages=p.get('packages',[])
        if not isinstance(packages,list) or not packages or any(not isinstance(x,str) for x in packages) or not set(packages)<=allowed:raise ValueError('Select packages from the supported list')
        for name in packages:
            policy=run(['apt-cache','policy','--',name])
            if not re.search(r'Candidate:\s+(?!\(none\))\S+',policy):raise ValueError('No cached installation candidate for '+name+'. Refresh the APT package indexes on this server first.')
            if action=='package-upgrade':
                status=run(['dpkg-query','-W','-f=${db:Status-Status}',name])
                if status!='installed':raise ValueError('Only already installed packages can be updated')
        env=os.environ.copy();env['DEBIAN_FRONTEND']='noninteractive'
        result=subprocess.run(['apt-get','install','-y','--no-install-recommends','--no-remove']+(['--only-upgrade'] if action=='package-upgrade' else [])+['--']+packages,env=env,capture_output=True,text=True,timeout=600)
        if result.returncode:raise ValueError((result.stderr or result.stdout)[-1500:])
        return {'output':result.stdout[-12000:]}
    if action=='docker-control':
        name=clean(p.get('name'),r'[A-Za-z0-9][A-Za-z0-9_.\-]{0,127}');verb=p.get('verb')
        if verb not in ('start','stop','restart','logs'):raise ValueError('Invalid container action')
        args=['docker',verb]+(['--tail','100'] if verb=='logs' else [])+['--',name]
        return {'output':run(args)}
    if action=='compose-deploy':
        name=clean(p.get('name'),r'[a-z][a-z0-9\-]{0,49}');text=p.get('compose','')
        if not isinstance(text,str) or len(text)>150000:raise ValueError('Invalid Compose document')
        # Full Compose can execute privileged host operations. Desktop displays it and requires Owner+sudo confirmation.
        base=APP_BASE;os.makedirs(base,mode=0o700,exist_ok=True)
        if os.path.islink(base):raise ValueError('Unsafe application directory')
        folder=base+'/'+name
        if os.path.lexists(folder):raise ValueError('Project already exists. Existing projects are never overwritten.')
        os.mkdir(folder,0o700)
        with open(folder+'/compose.yaml','w') as f:f.write(text)
        try:
            document=json.loads(run(['docker','compose','-p',name,'-f',folder+'/compose.yaml','config','--format','json']))
            import socket
            reservations=[]
            try:
                for service in document.get('services',{}).values():
                    for port in service.get('ports',[]):
                        published=str(port.get('published',''))
                        if not published.isdigit():raise ValueError('Choose a fixed single host port for this installation')
                        host=port.get('host_ip','0.0.0.0');proto=port.get('protocol','tcp')
                        probe=socket.socket(socket.AF_INET6 if ':' in host else socket.AF_INET,socket.SOCK_DGRAM if proto=='udp' else socket.SOCK_STREAM)
                        reservations.append(probe)
                        try:probe.bind((host,int(published)))
                        except OSError:raise ValueError('Published port '+published+'/'+proto+' is already in use or unavailable. Choose a different port in the installation preview.')
            finally:
                for probe in reservations:probe.close()
        except Exception:
            shutil.rmtree(folder);raise
        return {'output':run(['docker','compose','-p',name,'-f',folder+'/compose.yaml','up','-d'],600),'project':folder}
    if action=='mount':
        uuid=clean(p.get('uuid'),r'[A-Za-z0-9\-]{4,80}');target=clean(p.get('target'),r'/mnt/[A-Za-z0-9_\-]{1,60}')
        source='/dev/disk/by-uuid/'+uuid
        if not os.path.exists(source):raise ValueError('UUID not present on this server')
        if os.path.lexists(target):raise ValueError('Choose a new empty mount directory')
        if os.path.islink('/mnt'):raise ValueError('Unsafe /mnt directory')
        os.mkdir(target,0o755)
        try:run(['mount','--',source,target])
        except Exception:os.rmdir(target);raise
        return {'message':'Mounted temporarily. Existing /etc/fstab was not changed.'}
    if action=='smart':
        device=clean(p.get('device'),r'/dev/[A-Za-z0-9_\-]{1,80}')
        if not stat.S_ISBLK(os.stat(device).st_mode):raise ValueError('Not a block device')
        r=subprocess.run(['smartctl','-a','-j',device],capture_output=True,text=True,timeout=30)
        if not r.stdout:raise ValueError(r.stderr[-1000:])
        return json.loads(r.stdout)
    if action=='raid-plan':
        level=str(p.get('level'));minimum={'1':2,'5':3,'6':4,'10':4}
        devices=p.get('devices',[])
        if level not in minimum or not isinstance(devices,list) or len(set(devices))!=len(devices) or len(devices)<minimum[level] or (level=='10' and len(devices)%2):raise ValueError('Invalid RAID member count')
        available=json.loads(run(['lsblk','-J','-b','-o','PATH,TYPE,SIZE,FSTYPE,MOUNTPOINTS,SERIAL,RO']))
        all_disks={d['path']:d for d in available['blockdevices'] if d['type']=='disk'};selected=[]
        for name in devices:
            if name not in all_disks:raise ValueError('Select whole disks from current inventory')
            d=all_disks[name]
            if d.get('ro') or d.get('fstype') or d.get('children') or any(d.get('mountpoints') or []):raise ValueError('Disk contains partitions, filesystem or mounted data; not eligible for this wizard')
            selected.append(d)
        size=min(int(d['size']) for d in selected);n=len(selected);usable=size*(1 if level=='1' else n-1 if level=='5' else n-2 if level=='6' else n//2)
        return {'planOnly':True,'level':level,'devices':selected,'usableBytes':usable,'message':'Preview only. RAID creation and formatting are not enabled until destructive operations have been validated on disposable virtual disks.'}
    raise ValueError('Unsupported operation')
if __name__=='__main__':
    os.umask(0o077)
    try:print(json.dumps({'ok':True,'result':operation(json.load(sys.stdin))}))
    except Exception as e:print(json.dumps({'ok':False,'error':str(e)[:1800]}));sys.exit(1)
