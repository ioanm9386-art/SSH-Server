import json,sys,time,glob,subprocess,os,re

def rapl_snapshot():
    result={}
    for path in glob.glob('/sys/class/powercap/intel-rapl:*'):
        # Only package domains: including children would count energy twice.
        try:
            name=open(path+'/name').read().strip()
            if not name.startswith('package-'):continue
            result[path]=(int(open(path+'/energy_uj').read()),int(open(path+'/max_energy_range_uj').read()))
        except (OSError,ValueError):pass
    return result

def collect(params):
    if params.get('kind')=='rapl':
        before=rapl_snapshot();start=time.monotonic();time.sleep(1);after=rapl_snapshot();seconds=time.monotonic()-start
        if not before or set(before)!=set(after):raise ValueError('CPU energy counters unavailable or restricted')
        joules=0
        for path,(end,maximum) in after.items():
            initial=before[path][0]
            joules+=(end-initial if end>=initial else maximum-initial+end)/1000000
        return {'watts':joules/seconds,'scope':'CPU packages only','source':'Linux RAPL'}
    name=params.get('ups','')
    if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_.:@\[\]-]{1,180}',name) or name.startswith('-'):raise ValueError('Invalid NUT UPS name')
    p=subprocess.run(['upsc',name,'ups.realpower'],capture_output=True,text=True,timeout=8)
    if p.returncode:raise ValueError('NUT real power unavailable; upsc and ups.realpower are required')
    watts=float(p.stdout.strip())
    if watts<0 or watts>10000000:raise ValueError('Invalid power reading')
    return {'watts':watts,'scope':'UPS output; may include other devices','source':'NUT ups.realpower'}
if __name__=='__main__':
    try:print(json.dumps(collect(json.load(sys.stdin)),allow_nan=False))
    except Exception as e:print(json.dumps({'error':str(e)[:300]}));sys.exit(1)
