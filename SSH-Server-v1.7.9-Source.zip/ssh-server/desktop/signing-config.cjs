'use strict';
module.exports=function(config,env=process.env){
 const enabled=env.SSH_SERVER_SIGN_RELEASE==='1';
 if(!enabled){config.win.signExecutable=false;return config}
 if(!env.WIN_CSC_LINK&&!env.CSC_LINK&&!env.SSH_SERVER_CERT_SHA1)throw Error('Signed release requested, but no verified signing certificate is configured.');
 if(!env.SSH_SERVER_PUBLISHER)throw Error('Set SSH_SERVER_PUBLISHER to the verified certificate publisher.');
 config.forceCodeSigning=true;
 config.win.signExecutable=true;
 config.win.signtoolOptions={publisherName:env.SSH_SERVER_PUBLISHER,signingHashAlgorithms:['sha256'],rfc3161TimeStampServer:'http://timestamp.digicert.com'};
 if(env.SSH_SERVER_CERT_SHA1){if(!/^[a-f0-9]{40}$/i.test(env.SSH_SERVER_CERT_SHA1))throw Error('Invalid certificate SHA1 thumbprint');config.win.signtoolOptions.certificateSha1=env.SSH_SERVER_CERT_SHA1}
 return config;
};
