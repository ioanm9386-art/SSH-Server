//go:build windows

package main

import (
	"errors"
	"golang.org/x/sys/windows"
	"os"
	"path/filepath"
	"strings"
	"unsafe"
)

func desktopGuard() (func(), error) {
	name, _ := windows.UTF16PtrFromString(`Local\SSHServerDesktopData`)
	h, err := windows.CreateMutex(nil, false, name)
	if errors.Is(err, windows.ERROR_ALREADY_EXISTS) {
		if h != 0 {
			windows.CloseHandle(h)
		}
		return nil, errors.New("SSH_SERVER_ALREADY_RUNNING: SSH Server is already using these data")
	}
	if err != nil {
		return nil, err
	}
	release := func() { windows.CloseHandle(h) }
	snapshot, err := windows.CreateToolhelp32Snapshot(windows.TH32CS_SNAPPROCESS, 0)
	if err != nil {
		release()
		return nil, err
	}
	defer windows.CloseHandle(snapshot)
	entry := windows.ProcessEntry32{Size: uint32(unsafe.Sizeof(windows.ProcessEntry32{}))}
	legacyPaths := []string{filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "SSH Server", "SSH-Server.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "SSH Server v1.1", "SSH-Server.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "SSH Server v1.1", "SSH-Server-v1.1.exe")}
	for e := windows.Process32First(snapshot, &entry); e == nil; e = windows.Process32Next(snapshot, &entry) {
		exe := windows.UTF16ToString(entry.ExeFile[:])
		if !strings.EqualFold(exe, "SSH-Server.exe") && !strings.EqualFold(exe, "SSH-Server-v1.1.exe") {
			continue
		}
		process, e := windows.OpenProcess(windows.PROCESS_QUERY_LIMITED_INFORMATION, false, entry.ProcessID)
		if e != nil {
			continue
		}
		buffer := make([]uint16, 32768)
		size := uint32(len(buffer))
		e = windows.QueryFullProcessImageName(process, 0, &buffer[0], &size)
		windows.CloseHandle(process)
		if e != nil {
			continue
		}
		actual := windows.UTF16ToString(buffer[:size])
		for _, old := range legacyPaths {
			if strings.EqualFold(actual, old) {
				release()
				return nil, errors.New("SSH_SERVER_LEGACY_RUNNING: Close the old SSH Server test application before starting v1.5; existing data will be preserved")
			}
		}
	}
	return release, nil
}
