package main

import (
	"context"
	"net"
	"net/http"
	"strconv"
	"time"
)

func (s *Server) accessTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID, Name string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	var ep *AccessEndpoint
	for i := range p.Access {
		if p.Access[i].Name == a.Name {
			ep = &p.Access[i]
		}
	}
	if ep == nil {
		fail(w, 400, "Select a saved access address")
		return
	}
	ctx, c := context.WithTimeout(r.Context(), 5*time.Second)
	defer c()
	start := time.Now()
	conn, e := (&net.Dialer{}).DialContext(ctx, "tcp", net.JoinHostPort(ep.Host, strconv.Itoa(ep.Port)))
	if e != nil {
		jsonOut(w, 200, map[string]any{"reachable": false, "message": "Connection failed from this Windows device. Check VPN, port forwarding, firewall and CGNAT."})
		return
	}
	conn.Close()
	jsonOut(w, 200, map[string]any{"reachable": true, "latencyMs": time.Since(start).Milliseconds(), "message": "TCP reachable from this device. This does not verify SSH identity or prove availability from another network."})
}
