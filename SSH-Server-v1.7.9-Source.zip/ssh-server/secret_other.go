//go:build !windows

package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
)

func devKey() ([]byte, error) {
	dir, e := os.UserConfigDir()
	if e != nil {
		return nil, e
	}
	f := filepath.Join(dir, "ssh-server-v1.1", "development.key")
	_ = os.MkdirAll(filepath.Dir(f), 0700)
	b, e := os.ReadFile(f)
	if e == nil {
		return b, nil
	}
	b = make([]byte, 32)
	_, _ = rand.Read(b)
	e = os.WriteFile(f, b, 0600)
	return b, e
}
func encryptSecret(s string) (string, error) {
	k, e := devKey()
	if e != nil {
		return "", e
	}
	key := sha256.Sum256(k)
	block, e := aes.NewCipher(key[:])
	if e != nil {
		return "", e
	}
	gcm, e := cipher.NewGCM(block)
	if e != nil {
		return "", e
	}
	nonce := make([]byte, gcm.NonceSize())
	_, _ = rand.Read(nonce)
	data := gcm.Seal(nonce, nonce, []byte(s), nil)
	return "dev:" + base64.StdEncoding.EncodeToString(data), nil
}
func decryptSecret(s string) (string, error) {
	if len(s) < 4 || s[:4] != "dev:" {
		return "", errors.New("invalid secret")
	}
	k, e := devKey()
	if e != nil {
		return "", e
	}
	key := sha256.Sum256(k)
	block, e := aes.NewCipher(key[:])
	if e != nil {
		return "", e
	}
	gcm, e := cipher.NewGCM(block)
	if e != nil {
		return "", e
	}
	data, e := base64.StdEncoding.DecodeString(s[4:])
	if e != nil {
		return "", e
	}
	if len(data) < gcm.NonceSize() {
		return "", errors.New("short data")
	}
	plain, e := gcm.Open(nil, data[:gcm.NonceSize()], data[gcm.NonceSize():], nil)
	return string(plain), e
}
func hideProcessWindow(c *exec.Cmd) {}
