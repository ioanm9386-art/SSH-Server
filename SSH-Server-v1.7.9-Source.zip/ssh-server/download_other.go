//go:build !windows

package main

import "os"

func commitDownload(temp, dest string, overwrite bool) error {
	if overwrite {
		return os.Rename(temp, dest)
	}
	return os.Link(temp, dest)
}
