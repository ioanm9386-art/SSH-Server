package main

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestArchiveApprovedLocationsAndTraversal177(t *testing.T) {
	st, _ := openStore(t.TempDir())
	st.data.Cameras = []LiveCamera{{ID: "cam1", Name: "Gate", Kind: "camera", Group: "Outside"}}
	s := &Server{store: st}
	dir := t.TempDir()
	if e := s.rememberArchive("cam1", "", dir); e != nil {
		t.Fatal(e)
	}
	name := "cam1-20261113-120000.mkv"
	os.WriteFile(filepath.Join(dir, name), []byte("fixture recording"), 0600)
	os.WriteFile(filepath.Join(dir, "private.txt"), []byte("secret"), 0600)
	w := httptest.NewRecorder()
	s.cameraArchive(w, httptest.NewRequest("GET", "/api/livecam/archive?id=cam1", nil))
	var result struct {
		Recordings []ArchiveEntry `json:"recordings"`
	}
	json.Unmarshal(w.Body.Bytes(), &result)
	if w.Code != 200 || len(result.Recordings) != 1 || result.Recordings[0].Name != name {
		t.Fatal(w.Code, w.Body.String())
	}
	loc := result.Recordings[0].LocationID
	for _, bad := range []string{"../private.txt", "cam1-20261113-120000.mkv/../../secret", "cam2-20261113-120000.mkv", "cam1-20261113-120000.mkv\r\nX-Test:true"} {
		if f, close, _, e := s.archiveOpen(context.Background(), "cam1", loc, bad); e == nil {
			close()
			t.Fatal("unsafe path accepted", f, bad)
		}
	}
	w = httptest.NewRecorder()
	s.cameraArchiveFile(w, httptest.NewRequest("GET", "/api/livecam/archive/file?id=cam1&location="+loc+"&name="+name, nil))
	if w.Code != 200 || w.Body.String() != "fixture recording" {
		t.Fatal(w.Code, w.Body.String())
	}
	if strings.Contains(w.Header().Get("Content-Disposition"), "\r") {
		t.Fatal("unsafe header")
	}
	reopened, e := openStore(st.dir)
	if e != nil || reopened.snapshot().Cameras[0].Group != "Outside" || len(reopened.snapshot().CameraArchives) != 1 {
		t.Fatal("metadata migration failed", e)
	}
}
func TestArchivePlaybackProducesRealMP4177(t *testing.T) {
	engine, e := exec.LookPath("ffmpeg")
	if e != nil {
		t.Skip("FFmpeg unavailable")
	}
	st, _ := openStore(t.TempDir())
	st.data.Settings.FFmpegPath = engine
	st.data.Cameras = []LiveCamera{{ID: "cam1", Kind: "camera", Name: "Fixture"}}
	s := &Server{store: st}
	dir := t.TempDir()
	name := "cam1-20261113-120001.mkv"
	cmd := exec.Command(engine, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=160x90:rate=5", "-t", "0.6", "-c:v", "libx264", "-pix_fmt", "yuv420p", filepath.Join(dir, name))
	if out, e := cmd.CombinedOutput(); e != nil {
		t.Fatal(e, string(out))
	}
	if e = s.rememberArchive("cam1", "", dir); e != nil {
		t.Fatal(e)
	}
	loc := s.archiveLocations("cam1")[0].ID
	w := httptest.NewRecorder()
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	r := httptest.NewRequest("GET", "/api/livecam/playback?id=cam1&location="+loc+"&name="+name, nil).WithContext(ctx)
	s.cameraPlayback(w, r)
	if w.Code != 200 || !bytes.Contains(w.Body.Bytes(), []byte("ftyp")) || w.Body.Len() < 1000 {
		t.Fatal("MP4 not produced", w.Code, w.Body.Len())
	}
	if s.cameraPlaybackActive != 0 {
		t.Fatal("playback slot leaked")
	}
}
func TestCameraGroupSavePreservesProtectedSource177(t *testing.T) {
	st, _ := openStore(t.TempDir())
	secret, e := encryptSecret("rtsp://user:private@192.168.1.2/live")
	if e != nil {
		t.Fatal(e)
	}
	st.data.Cameras = []LiveCamera{{ID: "cam1", Name: "Gate", Kind: "camera", Secret: secret}}
	s := &Server{store: st}
	w := httptest.NewRecorder()
	s.liveCameras(w, httptest.NewRequest("POST", "/api/livecam", strings.NewReader(`{"id":"cam1","name":"Gate","kind":"camera","group":"Outside","source":""}`)))
	if w.Code != 200 || st.snapshot().Cameras[0].Secret != secret || st.snapshot().Cameras[0].Group != "Outside" {
		t.Fatal(w.Code, w.Body.String())
	}
}
func TestLinuxArchiveUsesNativeSFTP177(t *testing.T) {
	s, p, dir := sftpFixture(t)
	s.store.data.Cameras = []LiveCamera{{ID: "cam-remote", Name: "Remote", Kind: "nvr"}}
	name := "cam-remote-20261113-130000.mkv"
	os.WriteFile(filepath.Join(dir, name), []byte("remote-video-fixture"), 0600)
	if e := s.rememberArchive("cam-remote", p.ID, dir); e != nil {
		t.Fatal(e)
	}
	w := httptest.NewRecorder()
	s.cameraArchive(w, httptest.NewRequest("GET", "/api/livecam/archive?id=cam-remote", nil))
	var data struct {
		Recordings []ArchiveEntry `json:"recordings"`
	}
	json.Unmarshal(w.Body.Bytes(), &data)
	if w.Code != 200 || len(data.Recordings) != 1 {
		t.Fatal(w.Code, w.Body.String())
	}
	w = httptest.NewRecorder()
	s.cameraArchiveFile(w, httptest.NewRequest("GET", "/api/livecam/archive/file?id=cam-remote&location="+data.Recordings[0].LocationID+"&name="+name, nil))
	if w.Code != 200 || w.Body.String() != "remote-video-fixture" {
		t.Fatal(w.Code, w.Body.String())
	}
}
