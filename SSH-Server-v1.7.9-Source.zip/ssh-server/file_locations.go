package main

import (
	"encoding/json"
	"errors"
	"net/http"
	"path"
	"sort"
	"strconv"
	"strings"
	"time"
)

type RemoteLocation struct {
	Path       string `json:"path"`
	Label      string `json:"label"`
	Source     string `json:"source,omitempty"`
	Filesystem string `json:"filesystem,omitempty"`
}

func listingCommand(dir string) string {
	return "CDPATH= cd -P -- " + shellQuote(dir) + " || exit 1; printf '%s\\0' \"$(pwd -P)\"; LC_ALL=C find . -mindepth 1 -maxdepth 1 -printf '%y\\0%s\\0%T@\\0%f\\0'"
}
func parseRemoteListing(raw string) (string, []FileItem, error) {
	f := strings.Split(raw, "\x00")
	if len(f) < 2 || !strings.HasPrefix(f[0], "/") {
		return "", nil, errors.New("Server did not return an absolute directory path")
	}
	dir := f[0]
	items := []FileItem{}
	for i := 1; i+3 < len(f); i += 4 {
		name := f[i+3]
		if !safeRemote(name) {
			continue
		}
		kind := "file"
		if f[i] == "d" {
			kind = "dir"
		} else if f[i] == "l" {
			kind = "link"
		}
		size, _ := strconv.ParseInt(f[i+1], 10, 64)
		sec, _ := strconv.ParseFloat(f[i+2], 64)
		items = append(items, FileItem{Name: name, Path: path.Join(dir, name), Type: kind, Size: size, Modified: time.Unix(int64(sec), 0)})
	}
	sort.SliceStable(items, func(i, j int) bool {
		if (items[i].Type == "dir") != (items[j].Type == "dir") {
			return items[i].Type == "dir"
		}
		return strings.ToLower(items[i].Name) < strings.ToLower(items[j].Name)
	})
	return dir, items, nil
}
func parseRemoteLocations(raw string) ([]RemoteLocation, error) {
	part := strings.SplitN(raw, "\x00", 2)
	if len(part) != 2 {
		return nil, errors.New("Invalid storage locations response")
	}
	locations := []RemoteLocation{{Path: part[0], Label: "Home"}, {Path: "/", Label: "Root /"}}
	seen := map[string]bool{part[0]: true, "/": true}
	var mounts struct {
		Filesystems []struct {
			Target string `json:"target"`
			Source string `json:"source"`
			FSType string `json:"fstype"`
		} `json:"filesystems"`
	}
	if err := json.Unmarshal([]byte(part[1]), &mounts); err != nil {
		return nil, err
	}
	for _, m := range mounts.Filesystems {
		if m.Target == "/" {
			locations[1].Source = m.Source
			locations[1].Filesystem = m.FSType
			continue
		}
		if seen[m.Target] || !strings.HasPrefix(m.Target, "/") || !safeRemote(m.Target) {
			continue
		}
		if !strings.HasPrefix(m.Source, "/dev/") && m.FSType != "nfs" && m.FSType != "nfs4" && m.FSType != "cifs" {
			continue
		}
		if m.FSType == "squashfs" || strings.HasPrefix(m.Target, "/dev/") {
			continue
		}
		seen[m.Target] = true
		locations = append(locations, RemoteLocation{Path: m.Target, Label: m.Target, Source: m.Source, Filesystem: m.FSType})
	}
	return locations, nil
}
func (s *Server) remoteLocations(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	command := `printf '%s\0' "$HOME"; if command -v findmnt >/dev/null 2>&1; then findmnt --json --list --output TARGET,SOURCE,FSTYPE; else printf '{"filesystems":[]}'; fi`
	raw, e := s.remoteCommand(r, r.URL.Query().Get("id"), r.Header.Get("X-SSH-Password"), command)
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	locations, e := parseRemoteLocations(raw)
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	jsonOut(w, 200, map[string]any{"locations": locations})
}
