package main

import (
	"context"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"

	"golang.org/x/crypto/ssh"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

type HostKey struct {
	Line        string `json:"line"`
	Type        string `json:"type"`
	Fingerprint string `json:"fingerprint"`
}
type SSHSession struct {
	NativeClient    *ssh.Client
	NativeShell     *ssh.Session
	AgentConnection io.ReadWriteCloser
	ID              string
	Profile         Profile
	Cmd             *exec.Cmd
	Stdin           io.WriteCloser
	Started         time.Time
	Password        string
	mu              sync.Mutex
	conns           map[*WSConn]struct{}
	buffer          string
	closed          bool
}
type WSConn struct {
	rw    io.ReadWriteCloser
	mu    sync.Mutex
	alive bool
}

func (ws *WSConn) send(payload any) error {
	b, e := json.Marshal(payload)
	if e != nil {
		return e
	}
	ws.mu.Lock()
	defer ws.mu.Unlock()
	if !ws.alive {
		return errors.New("websocket closed")
	}
	head := []byte{0x81}
	switch {
	case len(b) < 126:
		head = append(head, byte(len(b)))
	case len(b) <= 65535:
		head = append(head, 126, byte(len(b)>>8), byte(len(b)))
	default:
		head = append(head, 127, 0, 0, 0, 0, byte(uint64(len(b))>>24), byte(uint64(len(b))>>16), byte(uint64(len(b))>>8), byte(len(b)))
	}
	_, e = ws.rw.Write(append(head, b...))
	return e
}
func (ws *WSConn) read() ([]byte, error) {
	var h [2]byte
	if _, e := io.ReadFull(ws.rw, h[:]); e != nil {
		return nil, e
	}
	op := h[0] & 15
	n := uint64(h[1] & 127)
	masked := h[1]&128 != 0
	if !masked {
		return nil, errors.New("client frame must be masked")
	}
	if n == 126 {
		var z [2]byte
		if _, e := io.ReadFull(ws.rw, z[:]); e != nil {
			return nil, e
		}
		n = uint64(binary.BigEndian.Uint16(z[:]))
	} else if n == 127 {
		var z [8]byte
		if _, e := io.ReadFull(ws.rw, z[:]); e != nil {
			return nil, e
		}
		n = binary.BigEndian.Uint64(z[:])
	}
	if n > 65536 {
		return nil, errors.New("frame too large")
	}
	var mask [4]byte
	if _, e := io.ReadFull(ws.rw, mask[:]); e != nil {
		return nil, e
	}
	b := make([]byte, n)
	if _, e := io.ReadFull(ws.rw, b); e != nil {
		return nil, e
	}
	for i := range b {
		b[i] ^= mask[i%4]
	}
	if op == 8 {
		return nil, io.EOF
	}
	if op != 1 && op != 2 {
		return []byte{}, nil
	}
	return b, nil
}
func (s *SSHSession) broadcast(v any) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for c := range s.conns {
		if e := c.send(v); e != nil {
			c.mu.Lock()
			c.alive = false
			c.mu.Unlock()
			_ = c.rw.Close()
			delete(s.conns, c)
		}
	}
}
func (s *SSHSession) appendOutput(output string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.buffer += output
	if len(s.buffer) > 140000 {
		s.buffer = s.buffer[len(s.buffer)-120000:]
	}
	payload := map[string]any{"type": "data", "data": base64.StdEncoding.EncodeToString([]byte(output))}
	for c := range s.conns {
		if e := c.send(payload); e != nil {
			_ = c.rw.Close()
			delete(s.conns, c)
		}
	}
}

func (s *Server) websocket(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	if r.Header.Get("Upgrade") != "websocket" || !strings.Contains(strings.ToLower(r.Header.Get("Connection")), "upgrade") {
		fail(w, 400, "WebSocket required")
		return
	}
	origin := r.Header.Get("Origin")
	if origin != "http://"+s.addr && origin != "http://localhost:"+strings.Split(s.addr, ":")[1] {
		fail(w, 403, "Invalid origin")
		return
	}
	key := r.Header.Get("Sec-Websocket-Key")
	if len(key) < 16 || len(key) > 100 {
		fail(w, 400, "Invalid handshake")
		return
	}
	if r.URL.Path != "/ws/terminal" {
		fail(w, 404, "Socket type not available")
		return
	}
	id := r.URL.Query().Get("id")
	s.mu.Lock()
	session := s.sessions[id]
	s.mu.Unlock()
	if session == nil {
		fail(w, 404, "Session not found")
		return
	}
	hijacker, ok := w.(http.Hijacker)
	if !ok {
		fail(w, 500, "WebSocket unsupported")
		return
	}
	conn, buf, err := hijacker.Hijack()
	if err != nil {
		return
	}
	acc := sha1.Sum([]byte(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"))
	_, _ = buf.WriteString("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + base64.StdEncoding.EncodeToString(acc[:]) + "\r\n\r\n")
	_ = buf.Flush()
	ws := &WSConn{rw: conn, alive: true}
	session.mu.Lock()
	history := session.buffer
	closed := session.closed
	_ = ws.send(map[string]any{"type": "init", "data": base64.StdEncoding.EncodeToString([]byte(history)), "closed": closed})
	session.conns[ws] = struct{}{}
	session.mu.Unlock()
	defer func() {
		session.mu.Lock()
		delete(session.conns, ws)
		session.mu.Unlock()
		ws.mu.Lock()
		ws.alive = false
		ws.mu.Unlock()
		_ = conn.Close()
	}()
	for {
		b, e := ws.read()
		if e != nil {
			return
		}
		if len(b) == 0 {
			continue
		}
		var msg struct {
			Type, Text string
			Cols, Rows int
		}
		if json.Unmarshal(b, &msg) != nil {
			continue
		}
		if msg.Type == "resize" && msg.Cols >= 20 && msg.Cols <= 500 && msg.Rows >= 5 && msg.Rows <= 200 {
			session.mu.Lock()
			shell := session.NativeShell
			closed := session.closed
			session.mu.Unlock()
			if shell != nil && !closed {
				_ = shell.WindowChange(msg.Rows, msg.Cols)
			}
		}
		if msg.Type == "input" && len(msg.Text) <= 8192 {
			session.mu.Lock()
			w := session.Stdin
			alreadyClosed := session.closed
			session.mu.Unlock()
			if !alreadyClosed && w != nil {
				_, _ = io.WriteString(w, msg.Text)
			}
		}
	}
}
func (s *Server) scanEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Profilul nu există.")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 14*time.Second)
	defer cancel()
	keys, err := scanHostKey(ctx, p.Host, p.Port)
	if err != nil {
		fail(w, 502, "Nu s-a putut citi amprenta SSH: "+err.Error())
		return
	}
	result := keys
	jsonOut(w, 200, map[string]any{"keys": result, "host": p.Host, "port": p.Port})
}

// scanHostKey obtains the server identity during key exchange and deliberately
// stops before authentication. A scanned key is NOT trusted until Owner approval.
func scanHostKey(ctx context.Context, host string, port int) ([]HostKey, error) {
	if !validHost(host) || port < 1 || port > 65535 {
		return nil, errors.New("invalid host or SSH port")
	}
	address := net.JoinHostPort(host, strconv.Itoa(port))
	conn, err := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp", address)
	if err != nil {
		return nil, fmt.Errorf("TCP connection: %w", err)
	}
	defer conn.Close()
	deadline := time.Now().Add(12 * time.Second)
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	if err = conn.SetDeadline(deadline); err != nil {
		return nil, err
	}
	done := make(chan struct{})
	defer close(done)
	go func() {
		select {
		case <-ctx.Done():
			conn.Close()
		case <-done:
		}
	}()
	var found []HostKey
	stop := errors.New("identity collected; authentication intentionally not attempted")
	config := &ssh.ClientConfig{User: "ssh-server-identity-check", HostKeyAlgorithms: []string{ssh.KeyAlgoED25519, ssh.KeyAlgoECDSA256, ssh.KeyAlgoECDSA384, ssh.KeyAlgoECDSA521, ssh.KeyAlgoRSASHA512, ssh.KeyAlgoRSASHA256}, HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
		name := host
		if port != 22 {
			name = "[" + host + "]:" + strconv.Itoa(port)
		}
		public := strings.TrimSpace(string(ssh.MarshalAuthorizedKey(key)))
		found = []HostKey{{Line: name + " " + public, Type: key.Type(), Fingerprint: ssh.FingerprintSHA256(key)}}
		return stop
	}}
	_, _, _, err = ssh.NewClientConn(conn, address, config)
	if len(found) > 0 {
		return found, nil
	}
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}
	return nil, fmt.Errorf("SSH negotiation: %w", err)
}

func (s *Server) trustProfile(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct {
		ID   string
		Keys []string
	}
	if body(r, &a) != nil || len(a.Keys) == 0 || len(a.Keys) > 8 {
		fail(w, 400, "Chei invalide.")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server inexistent.")
		return
	}
	for _, key := range a.Keys {
		f := strings.Fields(key)
		if len(f) != 3 || (!strings.HasPrefix(f[1], "ssh-") && !strings.HasPrefix(f[1], "ecdsa-")) || len(key) > 1800 {
			fail(w, 400, "Formatul unei chei este invalid.")
			return
		}
		expected := p.Host
		if p.Port != 22 {
			expected = "[" + p.Host + "]:" + strconv.Itoa(p.Port)
		}
		if f[0] != expected {
			fail(w, 400, "Cheia nu aparține serverului selectat.")
			return
		}
	}
	s.store.mu.Lock()
	found := false
	for i := range s.store.data.Profiles {
		if s.store.data.Profiles[i].ID == p.ID {
			s.store.data.Profiles[i].HostKeys = a.Keys
			found = true
			break
		}
	}
	e := s.store.saveLocked()
	s.store.mu.Unlock()
	if !found || e != nil {
		fail(w, 500, "Nu s-au putut salva amprentele SSH.")
		return
	}
	s.store.log("ssh_host_trusted", p.Name+" — cheile gazdei aprobate de Owner", "warning")
	jsonOut(w, 200, map[string]bool{"ok": true})
}

var usernameRE = regexp.MustCompile(`^[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,69}$`)

func (s *Server) knownHosts(p Profile) (string, error) {
	if len(p.HostKeys) == 0 {
		return "", errors.New("Confirmă amprenta SSH înainte de conectare")
	}
	dir := filepath.Join(s.store.dir, "hostkeys")
	if e := os.MkdirAll(dir, 0700); e != nil {
		return "", e
	}
	path := filepath.Join(dir, p.ID+".known_hosts")
	e := os.WriteFile(path, []byte(strings.Join(p.HostKeys, "\n")+"\n"), 0600)
	return path, e
}
func (s *Server) sshCmd(ctx context.Context, p Profile, password string, interactive bool, remote string) (*exec.Cmd, error) {
	if !usernameRE.MatchString(p.User) || !validHost(p.Host) {
		return nil, errors.New("Nume de utilizator sau gazdă SSH invalidă")
	}
	known, e := s.knownHosts(p)
	if e != nil {
		return nil, e
	}
	password = s.sshCredential(p, password)
	args := []string{"-o", "StrictHostKeyChecking=yes", "-o", "GlobalKnownHostsFile=" + nullDevice(), "-o", "UserKnownHostsFile=" + sshOptionPath(known), "-o", "ConnectTimeout=10", "-o", "ServerAliveInterval=20", "-o", "ServerAliveCountMax=3", "-p", strconv.Itoa(p.Port), "-l", p.User}
	if interactive {
		args = append(args, "-tt")
	} else {
		args = append(args, "-T")
	}
	if p.Auth == "key" {
		args = append(args, "-i", p.KeyPath, "-o", "IdentitiesOnly=yes")
	}
	if p.Auth == "agent" {
		args = append(args, "-o", "BatchMode=yes", "-o", "PreferredAuthentications=publickey", "-o", "PasswordAuthentication=no")
	}
	if p.Auth == "password" {
		args = append(args, "-o", "PreferredAuthentications=password,keyboard-interactive", "-o", "PubkeyAuthentication=no", "-o", "NumberOfPasswordPrompts=1")
	}
	args = append(args, p.Host)
	if remote != "" {
		args = append(args, remote)
	}
	cmd := exec.CommandContext(ctx, "ssh", args...)
	hideProcessWindow(cmd)
	cmd.Env = os.Environ()
	if p.Auth == "password" && password != "" {
		cmd.Env = append(cmd.Env, "SSH_ASKPASS_REQUIRE=force", "SSH_ASKPASS="+executablePath(), "SSH_SERVER_ASKPASS_MODE=1", "SSH_SERVER_ASKPASS_VALUE="+password, "DISPLAY=ssh-server:0")
	}
	return cmd, nil
}
func nullDevice() string {
	if os.PathSeparator == '\\' {
		return "NUL"
	}
	return "/dev/null"
}
func executablePath() string {
	p, e := os.Executable()
	if e != nil {
		return "sshserver"
	}
	return p
}
func (s *Server) connectEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID, Password string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Serverul nu există.")
		return
	}
	s.mu.Lock()
	if len(s.sessions) >= 12 {
		s.mu.Unlock()
		fail(w, 429, "Maximum 12 terminale simultane.")
		return
	}
	s.mu.Unlock()
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	session, e := s.openTerminal(ctx, p, a.Password)
	cancel()
	if e != nil {
		fail(w, 502, "SSH: "+e.Error())
		return
	}
	s.mu.Lock()
	if len(s.sessions) >= 12 {
		s.mu.Unlock()
		session.closeTransport()
		fail(w, 429, "Maximum 12 terminal sessions")
		return
	}
	s.sessions[session.ID] = session
	s.mu.Unlock()
	go func() {
		err := session.NativeShell.Wait()
		session.closeTransport()
		session.mu.Lock()
		session.closed = true
		session.mu.Unlock()
		message := "Connection closed"
		if err != nil {
			message = err.Error()
		}
		session.broadcast(map[string]any{"type": "exit", "text": message})
		s.store.log("ssh_closed", p.Name+": "+message, "info")
		time.AfterFunc(5*time.Minute, func() { s.mu.Lock(); delete(s.sessions, session.ID); s.mu.Unlock() })
	}()

	s.store.log("ssh_opened", p.Name, "info")
	jsonOut(w, 200, map[string]any{"sessionId": session.ID, "profile": p.Name})
}
func (s *Server) closeEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	s.mu.Lock()
	ss := s.sessions[a.ID]
	if ss != nil {
		delete(s.sessions, a.ID)
	}
	s.mu.Unlock()
	if ss == nil {
		fail(w, 404, "Sesiune inexistentă.")
		return
	}
	ss.closeTransport()
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) sessionsEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	s.mu.Lock()
	sessions := []map[string]any{}
	for _, ss := range s.sessions {
		ss.mu.Lock()
		entry := map[string]any{"id": ss.ID, "name": ss.Profile.Name, "host": ss.Profile.Host, "started": ss.Started, "closed": ss.closed}
		ss.mu.Unlock()
		sessions = append(sessions, entry)
	}
	s.mu.Unlock()
	jsonOut(w, 200, map[string]any{"sessions": sessions})
}
func (s *Server) execEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID, Command, Password string }
	if body(r, &a) != nil || len(a.Command) > 500 {
		fail(w, 400, "Invalid command")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()
	cmd, e := s.sshCmd(ctx, p, a.Password, false, a.Command)
	if e != nil {
		fail(w, 412, e.Error())
		return
	}
	out, e := cmd.CombinedOutput()
	if len(out) > 250000 {
		out = out[:250000]
	}
	if e != nil {
		fail(w, 502, "SSH: "+trimSpace(string(out), 500))
		return
	}
	s.store.log("ssh_command", p.Name+" — comandă executată (conținut neînregistrat)", "info")
	jsonOut(w, 200, map[string]string{"output": string(out)})
}
