package main

import (
	"context"
	"encoding/json"
	"net/http"
	"sort"
	"strings"
	"time"
)

type AppStoreJob struct {
	ID       string          `json:"id"`
	ServerID string          `json:"serverId"`
	Action   string          `json:"action"`
	Name     string          `json:"name"`
	Status   string          `json:"status"`
	Started  time.Time       `json:"started"`
	Finished *time.Time      `json:"finished,omitempty"`
	Error    string          `json:"error,omitempty"`
	Result   json.RawMessage `json:"result,omitempty"`
}

func (s *Server) appStoreState(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	p, ok := s.findProfile(r.URL.Query().Get("id"))
	if !ok {
		fail(w, 404, "Select a server")
		return
	}
	script, _ := adminAssets.ReadFile("scripts/appstore.py")
	ctx, cancel := context.WithTimeout(r.Context(), 65*time.Second)
	defer cancel()
	out, e := s.runNative(ctx, p, r.Header.Get("X-SSH-Password"), pythonCommand(script), "")
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	var result any
	if json.Unmarshal(out, &result) != nil {
		fail(w, 502, "Invalid App Store inventory")
		return
	}
	jsonOut(w, 200, result)
}
func (s *Server) appStoreJobEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		id := r.URL.Query().Get("id")
		if _, ok := s.findProfile(id); !ok {
			fail(w, 404, "Server not found")
			return
		}
		s.appStoreMu.Lock()
		jobs := []AppStoreJob{}
		for _, j := range s.appStoreJobs {
			if j.ServerID == id {
				jobs = append(jobs, *j)
			}
		}
		s.appStoreMu.Unlock()
		sort.Slice(jobs, func(i, j int) bool { return jobs[i].Started.After(jobs[j].Started) })
		jsonOut(w, 200, map[string]any{"jobs": jobs})
		return
	}
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a AdminRequest
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	if a.Action != "package" && a.Action != "package-upgrade" && a.Action != "compose-deploy" {
		fail(w, 400, "Unsupported App Store action")
		return
	}
	if validateAdmin(a) != nil {
		fail(w, 400, "Review and confirm the operation")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	if !ownerVerified(s.store.snapshot().Owner, a.OwnerPassword, a.Code) {
		fail(w, 403, "Owner password or TOTP code is incorrect")
		return
	}
	if p.Auth == "password" && s.sshCredential(p, "") == "" {
		fail(w, 409, "Unlock the SSH connection first")
		return
	}
	name := "APT"
	if a.Action == "compose-deploy" {
		name, _ = a.Params["name"].(string)
		if len(name) > 50 {
			fail(w, 400, "Invalid project name")
			return
		}
	}
	s.appStoreMu.Lock()
	if s.appStoreJobs == nil {
		s.appStoreJobs = map[string]*AppStoreJob{}
	}
	for _, j := range s.appStoreJobs {
		if j.ServerID == p.ID && j.Status == "running" {
			s.appStoreMu.Unlock()
			fail(w, 409, "An installation is already running on this server")
			return
		}
	}
	// Bound in-memory history; no passwords or request parameters are stored in it.
	if len(s.appStoreJobs) >= 100 {
		var oldest *AppStoreJob
		for _, j := range s.appStoreJobs {
			if j.Status != "running" && (oldest == nil || j.Started.Before(oldest.Started)) {
				oldest = j
			}
		}
		if oldest == nil {
			s.appStoreMu.Unlock()
			fail(w, 429, "Too many active jobs")
			return
		}
		delete(s.appStoreJobs, oldest.ID)
	}
	job := AppStoreJob{ID: randHex(12), ServerID: p.ID, Action: a.Action, Name: name, Status: "running", Started: time.Now().UTC()}
	s.appStoreJobs[job.ID] = &job
	response := job
	s.appStoreMu.Unlock()
	input, _ := json.Marshal(map[string]any{"action": a.Action, "params": a.Params})
	script, _ := adminAssets.ReadFile("scripts/operations.py")
	cmd := pythonCommand(script)
	stdin := string(input)
	if a.SudoPassword != "" {
		cmd = "sudo -S -p '' -- " + cmd
		stdin = a.SudoPassword + "\n" + stdin
	} else {
		cmd = "sudo -n -- " + cmd
	}
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 12*time.Minute)
		defer cancel()
		out, e := s.runNative(ctx, p, "", cmd, stdin)
		var result struct {
			OK     bool            `json:"ok"`
			Error  string          `json:"error"`
			Result json.RawMessage `json:"result"`
		}
		valid := json.Unmarshal(out, &result) == nil
		status := "success"
		message := ""
		if !valid {
			status = "error"
			message = "Invalid operation response"
			if e != nil {
				message = e.Error()
			}
		} else if !result.OK {
			status = "error"
			message = result.Error
		} else if e != nil {
			status = "error"
			message = e.Error()
		}
		// Remote command output can contain application secrets. Keep details private to
		// the job response; redact submitted credentials before sending even that output.
		for _, secret := range []string{a.SudoPassword, a.OwnerPassword, s.sshCredential(p, "")} {
			if secret != "" {
				message = strings.ReplaceAll(message, secret, "[redacted]")
			}
		}
		finish := time.Now().UTC()
		s.appStoreMu.Lock()
		job.Status = status
		job.Error = message
		job.Finished = &finish
		// Results intentionally omit subprocess output, which may contain generated credentials.
		job.Result = json.RawMessage(`{"message":"Refresh inventory and complete the application's first-run setup."}`)
		s.appStoreMu.Unlock()
		s.store.log("appstore_"+a.Action, p.Name+" — "+status+"; no credentials or command output logged", "info")
	}()
	jsonOut(w, 202, map[string]any{"job": response})
}
