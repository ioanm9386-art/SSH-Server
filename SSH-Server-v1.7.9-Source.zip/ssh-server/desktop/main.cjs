'use strict';
const {app,BrowserWindow,dialog,session,ipcMain,clipboard,Tray,Menu,Notification}=require('electron');
const {spawn}=require('node:child_process');
const path=require('node:path');
const fs=require('node:fs');
let tray,closeBehavior='exit';const noticeSeen=new Set();
function desktopPreferenceFile(){return path.join(process.env.LOCALAPPDATA,'SSH Server','desktop-preferences.json')}
function saveCloseBehavior(value){if(!['exit','tray'].includes(value))throw Error('Invalid close behavior');closeBehavior=value;fs.mkdirSync(path.dirname(desktopPreferenceFile()),{recursive:true});fs.writeFileSync(desktopPreferenceFile(),JSON.stringify({closeBehavior:value}));return value}
ipcMain.handle('desktop:preferences',event=>{if(!clipboardSender(event))throw Error('Denied');return {closeBehavior}});
ipcMain.handle('desktop:close-behavior',(event,value)=>{if(!clipboardSender(event))throw Error('Denied');return saveCloseBehavior(value)});
ipcMain.handle('alarms:notify',(event,title,body,id)=>{if(!clipboardSender(event)||typeof title!=='string'||typeof body!=='string'||title.length>250||body.length>1200)throw Error('Denied');const key=typeof id==='string'&&id.length<300?id:title+' '+body;if(noticeSeen.has(key))return false;if(noticeSeen.size>200)noticeSeen.clear();noticeSeen.add(key);if(Notification.isSupported())new Notification({title,body}).show();return true});
const {parseBackendURL,backendLocation,trustedURL}=require('./runtime.cjs');
let engine,win,quitting=false,ready=false,engineOrigin="";
function clipboardSender(event){return !!win&&event.sender===win.webContents&&event.senderFrame===win.webContents.mainFrame&&trustedURL(event.senderFrame.url,engineOrigin)}
ipcMain.handle("terminal:clipboard-read",event=>{if(!clipboardSender(event))throw Error("Clipboard access denied");return clipboard.readText()});
ipcMain.handle("terminal:clipboard-write",(event,text)=>{if(!clipboardSender(event)||typeof text!=="string"||text.length>1000000)throw Error("Clipboard access denied");clipboard.writeText(text);return true});
ipcMain.handle('files:pick-upload',async event=>{if(!clipboardSender(event))throw Error('File access denied');const r=await dialog.showOpenDialog(win,{title:'SSH Server — Upload files',properties:['openFile','multiSelections']});return {cancelled:r.canceled,paths:r.filePaths}});
ipcMain.handle('files:pick-save',async(event,name)=>{if(!clipboardSender(event)||typeof name!=='string'||name.length>255||/[\\/\x00\r\n]/.test(name))throw Error('Invalid download name');const r=await dialog.showSaveDialog(win,{title:'SSH Server — Save download',defaultPath:path.join(app.getPath('downloads'),name),properties:['showOverwriteConfirmation','createDirectory']});return {cancelled:r.canceled,path:r.filePath||''}});
ipcMain.handle('files:pick-folder',async event=>{if(!clipboardSender(event))throw Error('File access denied');const r=await dialog.showOpenDialog(win,{title:'SSH Server — Download destination',properties:['openDirectory','createDirectory']});return {cancelled:r.canceled,path:r.filePaths[0]||''}});
const lock=app.requestSingleInstanceLock();
if(!lock){app.quit();}else{
 app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus();}});
 app.whenReady().then(start).catch(()=>{dialog.showErrorBox('SSH Server','The desktop application could not start. Your data has not been removed.');app.quit();});
}
function start(){
 app.setAppUserModelId('community.sshserver.desktop');
 try{const p=JSON.parse(fs.readFileSync(desktopPreferenceFile(),'utf8'));if(['exit','tray'].includes(p.closeBehavior))closeBehavior=p.closeBehavior}catch{}
 const enginePath=app.isPackaged?backendLocation(process.resourcesPath):path.join(__dirname,'backend','ssh-server-engine.exe');
 // Keep the established data location, independent of the installation directory.
 const dataDir=path.join(process.env.LOCALAPPDATA,'SSH Server');
 engine=spawn(enginePath,['--no-open','--desktop','--data-dir',dataDir],{windowsHide:true,stdio:['pipe','pipe','pipe']});
 let buffer='',errorText='';
 const timeout=setTimeout(()=>startupError('The local engine did not start within 25 seconds.'),25000);
 function startupError(message){clearTimeout(timeout);if(quitting)return;dialog.showErrorBox('SSH Server',message);app.quit();}
 engine.on('error',()=>startupError('Cannot start the SSH Server engine. Check Windows Security protection history.'));
 engine.stderr.on('data',chunk=>{errorText=(errorText+chunk.toString()).slice(-3000);});
 engine.on('exit',()=>{clearTimeout(timeout);if(!quitting){dialog.showErrorBox('SSH Server',ready?'The local engine stopped. Restart SSH Server.':errorText.includes('SSH_SERVER_LEGACY_RUNNING')?'Close the old SSH Server test application (including its background process), then open v1.7 again. Your existing data is preserved.':errorText.includes('SSH_SERVER_ALREADY_RUNNING')?'SSH Server is already running. Open its existing window.':'The local engine could not start. Your existing data is preserved.');app.quit();}});
 engine.stdout.on('data',chunk=>{
  buffer+=chunk.toString();if(buffer.length>16384){startupError('Invalid engine startup response.');return;}
  let index;
  while((index=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,index);buffer=buffer.slice(index+1);const url=parseBackendURL(line);if(url&&!ready){ready=true;clearTimeout(timeout);createWindow(url);}}
 });
}
function createWindow(url){
 const origin=new URL(url).origin;engineOrigin=origin;
 session.defaultSession.setPermissionRequestHandler((_wc,permission,callback,details)=>callback(permission==='notifications'&&trustedURL(details.requestingUrl,origin)));
 win=new BrowserWindow({title:'SSH Server',width:1440,height:940,minWidth:820,minHeight:620,show:false,backgroundColor:'#000000',icon:path.join(__dirname,'assets','icon.png'),autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true,webviewTag:false,spellcheck:false,backgroundThrottling:false}});
 win.setMenu(null);
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-navigate',(event,target)=>{if(!trustedURL(target,origin))event.preventDefault();});
 win.webContents.on('will-attach-webview',event=>event.preventDefault());
 win.once('ready-to-show',()=>{win.maximize();win.show();});
 win.on('close',event=>{if(!quitting&&closeBehavior==='tray'){event.preventDefault();win.hide();}});
 win.on('closed',()=>{win=null;app.quit();});
 tray=new Tray(path.join(__dirname,'assets','icon.png'));tray.setToolTip('SSH Server');tray.setContextMenu(Menu.buildFromTemplate([{label:'Open SSH Server',click:()=>{win?.show();win?.focus()}},{label:'Exit',click:()=>app.quit()}]));tray.on('double-click',()=>{win?.show();win?.focus()});
 win.loadURL(url).catch(()=>{dialog.showErrorBox('SSH Server','Cannot open the application interface.');app.quit();});
}
app.on('before-quit',event=>{
 if(quitting||!engine||engine.exitCode!==null)return;
 event.preventDefault();quitting=true;
 // EOF requests orderly shutdown: close SSH sessions, then the local HTTP server.
 engine.stdin.end();
 const timer=setTimeout(()=>{engine.kill();app.exit();},4000);
 engine.once('exit',()=>{clearTimeout(timer);app.exit();});
});
app.on('window-all-closed',()=>app.quit());
