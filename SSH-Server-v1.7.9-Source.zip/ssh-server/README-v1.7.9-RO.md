# SSH Server v1.7.9 — LiveCam beta

Actualizare Windows x64, cu noul formular pentru camere și registratoare. Numele aplicației rămâne **SSH Server**, iar designul Corporate Black și funcțiile precedente se păstrează.

## Instalare

Închide complet SSH Server, inclusiv din zona de notificări. Extrage arhiva și rulează `SSH-Server-v1.7.9-Setup.exe`, peste instalarea existentă. Instalatorul permite alegerea folderului. Datele rămân în `%LOCALAPPDATA%\SSH Server`; se păstrează o copie a bazei existente în `backups\ssh-server-before-v1.7.9.json`, dacă acea copie nu există deja.

Instalatorul de test este **nesemnat**. Suportul de semnare este păstrat, dar nu există încă un certificat verificat pentru editor; SmartScreen poate apărea.

## Ordinea formularului

1. **Name / Nume**.
2. **Metodă de conectare**: IP, SN / cloud, RTSP / HTTP, ONVIF.
3. **Producător**: cele 13 branduri cerute și „Alt producător · ONVIF / RTSP”.
4. **Device type / Tip dispozitiv**: Camera, NVR, DVR, XVR.
5. **User / Utilizator** al dispozitivului sau contului ONVIF.
6. **Password / Parolă**, într-un câmp separat, mascat.
7. Setările metodei: IP/hostname, port, canal numeric, profil/flux sau URL exact.
8. Etichetă canal și grup.

Parola salvată nu este returnată în formular. La editare poți păstra conexiunea întreagă fără să rescrii parola. Pentru reconfigurare, debifează „Păstrează conexiunea video existentă”. O parolă criptată salvată poate fi reutilizată numai pentru aceeași adresă și același utilizator; introducerea unei parole noi debifează reutilizarea.

## Ce funcționează în această versiune

### IP și profil RTSP de producător

Selectează brandul, tipul de dispozitiv, utilizatorul, parola, IP-ul/hostname-ul, portul RTSP, canalul numeric și profilul video. Aplicația construiește URL-ul unde există un șablon documentat pentru acel tip.

Canalele numerice sunt separate de etichetele descriptive. De exemplu, la Hikvision canalul 2 este transformat în `201` pentru principal și `202` pentru secundar; la Dahua este parametrul `channel=2`.

### ONVIF nativ în aplicație

Clientul Go integrat citește direct dispozitivul, fără un terminal SSH și fără un serviciu pe serverul Nebula:

- informațiile dispozitivului: producător, model, serie și firmware, dacă sunt expuse;
- profilurile video reale prin ONVIF Media și fallback Media2;
- numele profilului, codec și rezoluție, dacă sunt raportate de dispozitiv;
- URI-ul video al profilului ales la salvare.

Autentificare: WS-Security UsernameToken PasswordDigest; HTTP Digest MD5/SHA-256 și Basic atunci când dispozitivul le solicită. Ceasul UTC raportat de dispozitiv este folosit pentru compensarea diferenței de timp a tokenului, fără modificarea ceasului camerei.

**Pași:** selectează ONVIF → introdu IP, contul ONVIF și portul → „Citește dispozitivul și profilurile ONVIF” → alege profilul → salvează → pornește Live. Citirea ONVIF reușită nu confirmă încă decodarea fluxului video.

Unele dispozitive necesită activarea ONVIF și un utilizator ONVIF separat. Porturile sunt editabile; profilul Tapo propune 2020, iar Reolink 8000, dar valoarea configurată în dispozitiv are prioritate. Calea serviciului este editabilă, implicit `/onvif/device_service`.

HTTP transmite cererile fără criptarea transportului: folosește LAN/VPN de încredere sau HTTPS cu certificat valid/de încredere. Clientul nu ignoră certificatele și nu trimite acreditările către redirecționări HTTP ori servicii ONVIF care indică alt hostname. Dacă dispozitivul returnează un URI de flux cu altă adresă decât cea introdusă, folosește explicit metoda RTSP cu adresa accesibilă. Nu se aplică automat reguli NAT și nu se schimbă adresa dispozitivului.

### RTSP / HTTP universal

Pentru orice marcă, introdu URL-ul exact al fluxului și utilizatorul/parola în câmpurile separate. Rămân acceptate și URL-urile care includ deja acreditările. URL-ul complet și configurația conexiunii sunt criptate prin Windows DPAPI în profilul utilizatorului curent.

Compatibilitatea video depinde de model, firmware, protocoalele activate și codec. Vizualizarea folosește în continuare FFmpeg pe Windows. Dispozitivele exclusiv cloud, care nu expun un flux local compatibil, nu devin accesibile prin simpla selectare a brandului.

## Matricea celor 13 branduri

„ONVIF nativ” înseamnă clientul de protocol integrat descris mai sus, pe modelele care expun servicii compatibile. Nu înseamnă SDK proprietar al fiecărui producător, certificare ONVIF a aplicației sau compatibilitate garantată cu toate modelele.

| Producător | Profil IP/RTSP inclus | Alternativă locală |
|---|---|---|
| Hikvision | Streaming Channels, cameră și registrator, principal/secundar | ONVIF nativ / RTSP exact |
| Dahua Technology | cam/realmonitor, canal și subtype | ONVIF nativ / RTSP exact |
| Axis Communications | VAPIX media.amp; profilul nu forțează un substream | ONVIF nativ pentru profilurile efective |
| Hanwha Vision (Samsung) | Wisenet profile2/profile3; căile canalelor pot varia | ONVIF nativ / RTSP exact |
| Uniview (UNV) | media/video pentru cameră, unicast pentru registrator | ONVIF nativ / RTSP exact |
| Bosch Security Systems | Fără cale RTSP presupusă | ONVIF nativ sau URL-ul documentat al modelului |
| TP-Link (Tapo) | stream1 / stream2, pe modelele compatibile | ONVIF nativ; folosește Camera Account |
| EZVIZ | Fără cale RTSP presupusă pentru toate modelele | URL RTSP exact; ONVIF numai dacă modelul îl oferă |
| Imou | Fără cale RTSP presupusă pentru toate modelele | ONVIF nativ, unde este expus, sau URL RTSP exact |
| Reolink | Preview cu canal și principal/secundar | ONVIF nativ; suportul modelelor pe baterie/hub diferă |
| Avigilon | defaultPrimary pentru camere compatibile | ONVIF nativ pentru alte profiluri / RTSP exact |
| Tiandy | Fără cale RTSP neverificată | ONVIF nativ sau URL RTSP documentat |
| Vivotek | Variante de acces legacy și firmware nou | ONVIF nativ; numele de acces sunt configurabile |

Pentru Bosch, EZVIZ, Imou și Tiandy nu am inventat un URL universal. Selectorul păstrează profilurile și instrucțiunile specifice, iar conectarea locală folosește capabilitățile reale ale dispozitivului.

## SN / cloud — cerință rămasă neimplementată

Ai ales explicit **conectare prin cloud-ul producătorului, cu seria**, nu descoperirea locală după serie.

Această versiune **nu implementează conectarea cloud/P2P prin SN** pentru cele 13 branduri și nu include SDK-urile lor proprietare. Opțiunea este vizibilă cu explicația stării; salvarea este blocată în acest mod, iar backend-ul refuză o cerere SN. Nu există un dispozitiv fictiv salvat sau o stare „conectat” fără conexiune.

Pentru realizarea cerinței complete sunt necesare, separat pentru fiecare platformă:

- identificarea unui API/SDK oficial care permite accesul la dispozitivele utilizatorilor dintr-o aplicație Windows terță;
- accesul de dezvoltator/partener, AppKey/AppId sau alte acreditări ale aplicației, dacă sunt cerute;
- autorizarea utilizatorului și drepturile asupra dispozitivului;
- integrarea playerului, sesiunilor, tokenurilor și eventual a cheii de verificare/criptare a dispozitivului;
- verificarea licenței, redistribuirii SDK-ului și disponibilității regionale;
- testarea pe modele reale.

Nu toate platformele oferă aceeași funcție SN/P2P sau aceleași drepturi unor aplicații terțe. Un SDK Android nu este automat utilizabil în aplicația Windows. Nu sunt incluse AppSecret-uri partajate în executabil și nu sunt cerute parole cloud într-o integrare inexistentă.

Exemple oficiale:

- EZVIZ descrie AppKey, autorizare/accessToken, deviceSerial și playerul din SDK: https://support.ezviz.com/faq/428
- Imou descrie AppId/AppSecret, accessToken și serialul pentru înrolare: https://open.imoulife.com/book/03-guides/02.device-access/05.bind-device-via-api.html
- Hikvision descrie seria și codul de verificare în aplicația sa Hik-Connect: https://supportusa.hikvision.com/support/solutions/articles/17000130024

Această limitare cloud nu împiedică folosirea IP/RTSP/ONVIF prin LAN sau VPN/Tailscale, dacă dispozitivul este accesibil în rețea și expune protocolul ales. Pentru vizualizare nu trebuie păstrat un terminal SSH deschis.

## Ce se păstrează

App Store cu 36 de aplicații/instrumente și 9 categorii, Files/SFTP, terminal, automatizări, monitorizare, jurnale, Storage, alarme, Network, porturi TCP/UDP, Energie și arhiva LiveCam.

LiveCam rămâne beta: maximum 4 vizualizări și 4 înregistrări simultane, fără audio în previzualizarea MJPEG. Înregistrarea gestionată de aplicația Windows necesită ca aceasta să rămână pornită. Nu sunt implementate PTZ universal, descoperire multicast, AI, detecție automată a mișcării sau retenție automată.

## Verificări

- Teste Go cu detector de concurență, inclusiv servere HTTP/SOAP de test care verifică autentificarea Digest, tokenul WS-Security, Media/Media2 și URI-ul fluxului.
- Teste pentru criptarea configurației, editarea fără rescrierea sursei, refuzul reutilizării parolei către alt host, limite XML și refuzul redirecționărilor.
- Testele interfeței: ordinea câmpurilor, 13 branduri plus generic, cele patru metode, citirea profilurilor și blocarea SN neintegrat.
- Regresie pentru modulele precedente, 39 de teste Python și 9 verificări Electron/instalator/semnare.
- Compilare Windows x64 și generare instalator NSIS.

Testele de protocol folosesc dispozitive simulate. **Nu s-au testat fizic toate cele 13 branduri și nu s-a executat instalatorul pe calculatorul tău.** Nu reprezintă o certificare de compatibilitate cu toate camerele/NVR-urile acestor producători.

Sursele complete sunt în `source/ssh-server/`. Registrul profilurilor și legăturile către documentația producătorilor sunt în `web/camera-brands179.json`.
