package main

import (
	"context"
	"errors"
	"fmt"
	"github.com/pkg/sftp"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

func (s *Server) openSFTP(ctx context.Context, p Profile, password string) (*sftp.Client, func(), error) {
	client, extra, e := s.dialSSH(ctx, p, password)
	if e != nil {
		return nil, nil, e
	}
	stop := context.AfterFunc(ctx, func() { client.Close() })
	sf, e := sftp.NewClient(client)
	if e != nil {
		stop()
		client.Close()
		if extra != nil {
			extra.Close()
		}
		return nil, nil, e
	}
	close := func() {
		stop()
		sf.Close()
		client.Close()
		if extra != nil {
			extra.Close()
		}
	}
	return sf, close, nil
}
func fileEntry(dir string, info os.FileInfo) FileItem {
	kind := "file"
	if info.IsDir() {
		kind = "dir"
	}
	link := info.Mode()&os.ModeSymlink != 0
	if link {
		kind = "link"
	}
	item := FileItem{Name: info.Name(), Path: path.Join(dir, info.Name()), Type: kind, Size: info.Size(), Modified: info.ModTime(), Permissions: fmt.Sprintf("%04o", uint32(info.Mode().Perm())), Link: link}
	if stat, ok := info.Sys().(*sftp.FileStat); ok {
		item.UID = stat.UID
		item.GID = stat.GID
		item.Permissions = fmt.Sprintf("%04o", stat.Mode&07777)
	}
	return item
}
func (s *Server) nativeRemoteFiles(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	p, ok := s.findProfile(r.URL.Query().Get("id"))
	if !ok {
		fail(w, 404, "Select a server")
		return
	}
	dir := r.URL.Query().Get("path")
	if dir == "" {
		dir = "."
	}
	if !safeRemote(dir) {
		fail(w, 400, "Invalid remote directory")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 35*time.Second)
	defer cancel()
	sf, close, e := s.openSFTP(ctx, p, r.Header.Get("X-SSH-Password"))
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	defer close()
	dir, e = sf.RealPath(dir)
	if e != nil {
		fail(w, 403, "Cannot resolve directory: "+e.Error())
		return
	}
	entries, e := sf.ReadDir(dir)
	if e != nil {
		fail(w, 403, "Cannot read directory: "+e.Error())
		return
	}
	items := make([]FileItem, 0, len(entries))
	for _, info := range entries {
		if info.Name() == "." || info.Name() == ".." || !safeRemote(info.Name()) {
			continue
		}
		items = append(items, fileEntry(dir, info))
	}
	sort.SliceStable(items, func(i, j int) bool {
		if (items[i].Type == "dir") != (items[j].Type == "dir") {
			return items[i].Type == "dir"
		}
		return strings.ToLower(items[i].Name) < strings.ToLower(items[j].Name)
	})
	jsonOut(w, 200, map[string]any{"path": dir, "parent": path.Dir(dir), "items": items})
}
func destinationFree(sf *sftp.Client, dest string) error {
	_, e := sf.Lstat(dest)
	if e == nil {
		return errors.New("Destination already exists; choose a different name")
	}
	if !os.IsNotExist(e) {
		return e
	}
	return nil
}
func copyRemote(ctx context.Context, sf *sftp.Client, src, dest string, count *int) error {
	if ctx.Err() != nil {
		return ctx.Err()
	}
	*count++
	if *count > 20000 {
		return errors.New("Copy exceeded 20,000 entries; use smaller batches")
	}
	info, e := sf.Lstat(src)
	if e != nil {
		return e
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return errors.New("Copying symbolic links is not supported; open the actual target instead")
	}
	if e = destinationFree(sf, dest); e != nil {
		return e
	}
	if info.IsDir() {
		if e = sf.Mkdir(dest); e != nil {
			return e
		}
		entries, e := sf.ReadDir(src)
		if e != nil {
			return e
		}
		for _, entry := range entries {
			if e = copyRemote(ctx, sf, path.Join(src, entry.Name()), path.Join(dest, entry.Name()), count); e != nil {
				return e
			}
		}
		return nil
	}
	if !info.Mode().IsRegular() {
		return errors.New("Only regular files and directories can be copied")
	}
	in, e := sf.Open(src)
	if e != nil {
		return e
	}
	defer in.Close()
	out, e := sf.OpenFile(dest, os.O_CREATE|os.O_EXCL|os.O_WRONLY)
	if e != nil {
		return e
	}
	_, e = io.Copy(out, in)
	if e == nil {
		e = out.Chmod(info.Mode().Perm())
	}
	ce := out.Close()
	if e != nil {
		return e
	}
	return ce
}

type FileAction struct {
	ID, Action, Path, Dest, Password, Content, Mode, ExpectedModified string
	Overwrite                                                         bool
}

func (s *Server) nativeFileAction(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a FileAction
	if body(r, &a) != nil || !safeRemote(a.Path) {
		fail(w, 400, "Invalid file operation")
		return
	}
	if a.Action == "upload" || a.Action == "download" {
		s.startTransfer(w, r, a.ID, a.Action, a.Path, a.Dest, a.Password, a.Overwrite)
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	sf, close, e := s.openSFTP(ctx, p, a.Password)
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	defer close()
	a.Path = path.Clean(a.Path)
	if !strings.HasPrefix(a.Path, "/") {
		fail(w, 400, "Open an absolute server directory first")
		return
	}
	out := ""
	result := map[string]any{"ok": true, "output": ""}
	switch a.Action {
	case "mkdir":
		e = sf.Mkdir(a.Path)
	case "rename", "move", "copy":
		if !safeRemote(a.Dest) || !strings.HasPrefix(a.Dest, "/") {
			fail(w, 400, "Use an absolute destination")
			return
		}
		a.Dest = path.Clean(a.Dest)
		if a.Path == "/" || a.Dest == a.Path || strings.HasPrefix(a.Dest, a.Path+"/") {
			fail(w, 400, "Cannot move/copy a folder into itself")
			return
		}
		if e = destinationFree(sf, a.Dest); e == nil {
			if a.Action == "copy" {
				count := 0
				e = copyRemote(ctx, sf, a.Path, a.Dest, &count)
			} else {
				e = sf.Rename(a.Path, a.Dest)
			}
		}
	case "delete":
		var info os.FileInfo
		info, e = sf.Lstat(a.Path)
		if e == nil {
			if info.IsDir() {
				e = errors.New("Use the empty-folder delete action for directories")
			} else {
				e = sf.Remove(a.Path)
			}
		}
	case "rmdir":
		if a.Path == "/" {
			e = errors.New("Cannot remove root")
		} else {
			e = sf.RemoveDirectory(a.Path)
		}
	case "chmod":
		if len(a.Mode) != 3 && len(a.Mode) != 4 {
			fail(w, 400, "Enter 3 or 4 octal digits")
			return
		}
		var mode uint64
		mode, e = strconv.ParseUint(a.Mode, 8, 12)
		if e == nil {
			var info os.FileInfo
			info, e = sf.Lstat(a.Path)
			if e == nil {
				if info.Mode()&os.ModeSymlink != 0 {
					e = errors.New("Change permissions on the actual target, not a symbolic link")
				} else {
					perms := os.FileMode(mode & 0777)
					if mode&04000 != 0 {
						perms |= os.ModeSetuid
					}
					if mode&02000 != 0 {
						perms |= os.ModeSetgid
					}
					if mode&01000 != 0 {
						perms |= os.ModeSticky
					}
					e = sf.Chmod(a.Path, perms)
				}
			}
		}
	case "read":
		var info os.FileInfo
		info, e = sf.Lstat(a.Path)
		if e == nil {
			if !info.Mode().IsRegular() || info.Size() > 180000 {
				e = errors.New("Editor accepts regular UTF-8 text files up to 180 KB")
			} else {
				var f *sftp.File
				f, e = sf.Open(a.Path)
				if e == nil {
					var data []byte
					data, e = io.ReadAll(io.LimitReader(f, 180001))
					f.Close()
					if e == nil && (!utf8.Valid(data) || len(data) > 180000 || strings.ContainsRune(string(data), '\x00')) {
						e = errors.New("This is not a supported UTF-8 text file")
					}
					out = string(data)
					result["modified"] = info.ModTime().UTC().Format(time.RFC3339Nano)
				}
			}
		}
	case "write":
		if len(a.Content) > 180000 || !utf8.ValidString(a.Content) || strings.ContainsRune(a.Content, '\x00') {
			fail(w, 400, "Editor limit is 180 KB of UTF-8 text")
			return
		}
		var backup string
		backup, e = saveRemoteText(sf, a.Path, a.Content, a.ExpectedModified)
		result["backup"] = backup
	default:
		fail(w, 400, "Unsupported file operation")
		return
	}
	if e != nil {
		fail(w, 422, e.Error())
		return
	}
	if a.Action != "read" {
		s.store.log("sftp_"+a.Action, p.Name+" — "+a.Path, "info")
	}
	result["output"] = out
	jsonOut(w, 200, result)
}
func saveRemoteText(sf *sftp.Client, name, content, modified string) (string, error) {
	if _, ok := sf.HasExtension("posix-rename@openssh.com"); !ok {
		return "", errors.New("Server does not support atomic editor saves")
	}
	info, e := sf.Lstat(name)
	if e != nil {
		return "", e
	}
	if !info.Mode().IsRegular() || info.Size() > 180000 {
		return "", errors.New("Only regular text files up to 180 KB can be edited")
	}
	if modified != "" && info.ModTime().UTC().Format(time.RFC3339Nano) != modified {
		return "", errors.New("File changed on the server; reopen it before saving")
	}
	backup := path.Join(path.Dir(name), "."+path.Base(name)+".ssh-backup-"+time.Now().UTC().Format("20060102-150405")+"-"+randHex(3))
	count := 0
	if e = copyRemote(context.Background(), sf, name, backup, &count); e != nil {
		return "", e
	}
	temp := name + ".ssh-save-" + randHex(8)
	f, e := sf.OpenFile(temp, os.O_CREATE|os.O_EXCL|os.O_WRONLY)
	if e != nil {
		return backup, e
	}
	defer sf.Remove(temp)
	_, e = io.WriteString(f, content)
	if e == nil {
		e = f.Chmod(info.Mode().Perm())
	}
	ce := f.Close()
	if e != nil {
		return backup, e
	}
	if ce != nil {
		return backup, ce
	}
	return backup, sf.PosixRename(temp, name)
}

type progressReader struct {
	reader      io.Reader
	done, total int64
	progress    func(int64, int64)
}

func (r *progressReader) Read(b []byte) (int, error) {
	n, e := r.reader.Read(b)
	r.done += int64(n)
	if r.progress != nil {
		r.progress(r.done, r.total)
	}
	return n, e
}
func (s *Server) nativeTransfer(ctx context.Context, p Profile, kind, remote, local, password string, overwrite bool, progress func(int64, int64)) error {
	sf, close, e := s.openSFTP(ctx, p, password)
	if e != nil {
		return e
	}
	defer close()
	if kind == "upload" {
		if e = destinationFree(sf, remote); e != nil {
			return e
		}
		in, e := os.Open(local)
		if e != nil {
			return e
		}
		defer in.Close()
		info, e := in.Stat()
		if e != nil || !info.Mode().IsRegular() {
			return errors.New("Select a regular local file")
		}
		temp := remote + ".ssh-upload-" + randHex(8)
		out, e := sf.OpenFile(temp, os.O_CREATE|os.O_EXCL|os.O_WRONLY)
		if e != nil {
			return e
		}
		defer sf.Remove(temp)
		reader := &progressReader{reader: in, total: info.Size(), progress: progress}
		_, e = io.Copy(out, reader)
		ce := out.Close()
		if e != nil {
			return e
		}
		if ce != nil {
			return ce
		}
		if e = destinationFree(sf, remote); e != nil {
			return e
		}
		return commitRemoteUpload(sf, temp, remote)
	}
	in, e := sf.Open(remote)
	if e != nil {
		return e
	}
	defer in.Close()
	info, e := in.Stat()
	if e != nil || !info.Mode().IsRegular() {
		return errors.New("Select a regular remote file")
	}
	if _, err := os.Lstat(local); err == nil {
		if !overwrite {
			return errors.New("Local file exists; choose a different name")
		}
		if fi, err := os.Lstat(local); err != nil || !fi.Mode().IsRegular() {
			return errors.New("Destination must be a regular file")
		}
	} else if !os.IsNotExist(err) {
		return err
	}
	out, e := os.CreateTemp(filepath.Dir(local), ".ssh-server-download-*")
	if e != nil {
		return e
	}
	temp := out.Name()
	defer os.Remove(temp)
	reader := &progressReader{reader: in, total: info.Size(), progress: progress}
	_, e = io.Copy(out, reader)
	if e == nil {
		e = out.Sync()
	}
	ce := out.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	if ctx.Err() != nil {
		return ctx.Err()
	}
	if !overwrite {
		if _, e = os.Lstat(local); e == nil {
			return errors.New("Destination appeared while downloading; choose a different name")
		}
	}
	return commitDownload(temp, local, overwrite)
}

// Link or exclusive creation prevents concurrent uploads from replacing an existing file.
func commitRemoteUpload(sf *sftp.Client, temp, dest string) error {
	if _, ok := sf.HasExtension("hardlink@openssh.com"); ok {
		if e := sf.Link(temp, dest); e == nil {
			return nil
		}
	}
	out, e := sf.OpenFile(dest, os.O_CREATE|os.O_EXCL|os.O_WRONLY)
	if e != nil {
		return e
	}
	in, e := sf.Open(temp)
	if e != nil {
		out.Close()
		sf.Remove(dest)
		return e
	}
	_, e = io.Copy(out, in)
	in.Close()
	ce := out.Close()
	if e != nil {
		return e
	}
	return ce
}
