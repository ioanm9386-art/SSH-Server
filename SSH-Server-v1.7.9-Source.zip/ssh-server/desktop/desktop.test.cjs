const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const {parseBackendURL,trustedURL}=require('./runtime.cjs');
test('accept only engine loopback token URL',()=>{const token='a'.repeat(64);assert.equal(parseBackendURL(`SSH Server v1.5 local: http://127.0.0.1:3000/#token=${token}`),`http://127.0.0.1:3000/#token=${token}`);for(const s of [`SSH Server v1.5 local: http://evil.test:3000/#token=${token}`,`SSH Server v1.5 local: http://127.0.0.1:99999/#token=${token}`,'garbage'])assert.equal(parseBackendURL(s),null);});
test('navigation confined to engine origin',()=>{assert.ok(trustedURL('http://127.0.0.1:3000/web/','http://127.0.0.1:3000'));assert.ok(!trustedURL('https://example.com','http://127.0.0.1:3000'));assert.ok(!trustedURL('file:///C:/secret','http://127.0.0.1:3000'));});
test('classic setup preserves appdata and supports directory choice',()=>{const p=require('./package.json');assert.equal(p.build.nsis.oneClick,false);assert.equal(p.build.nsis.allowToChangeInstallationDirectory,true);assert.equal(p.build.nsis.deleteAppDataOnUninstall,false);});
test('desktop renderer isolated and maximized',()=>{const s=fs.readFileSync(__dirname+'/main.cjs','utf8');for(const text of ['contextIsolation:true','nodeIntegration:false','sandbox:true','win.maximize()','engine.stdin.end()'])assert.ok(s.includes(text));assert.ok(!s.includes('msedge.exe'));});

test('terminal emulator interprets erase and cursor controls',async()=>{
 const {Terminal}=require('@xterm/headless');const t=new Terminal({cols:80,rows:24,allowProposedApi:true});
 const write=text=>new Promise(resolve=>t.write(text,resolve));
 await write('wrongX\b \b');assert.equal(t.buffer.active.getLine(0).translateToString(true).trimEnd(),'wrong');assert.equal(t.buffer.active.cursorX,5);
 await write('\x1b[2DOK');assert.equal(t.buffer.active.getLine(0).translateToString(true).trimEnd(),'wroOK');
 await write('\r\x1b[2Kready');assert.equal(t.buffer.active.getLine(0).translateToString(true).trimEnd(),'ready');
 t.resize(132,44);assert.equal(t.cols,132);assert.equal(t.rows,44);t.dispose();
});
test('clipboard IPC only accepts the main local application frame',()=>{
 const vm=require('node:vm');const handlers=new Map();let value='echo clipboard';const localFrame={url:'http://127.0.0.1:3000/#token=secret'};const wc={mainFrame:localFrame};
 const electron={app:{requestSingleInstanceLock:()=>true,on:()=>{},whenReady:()=>new Promise(()=>{})},BrowserWindow:function(){},dialog:{},session:{},ipcMain:{handle:(name,fn)=>handlers.set(name,fn)},clipboard:{readText:()=>value,writeText:text=>value=text}};
 const context={require:name=>name==='electron'?electron:require(name),process,setTimeout,clearTimeout,console,__dirname};vm.createContext(context);vm.runInContext(fs.readFileSync(__dirname+'/main.cjs','utf8'),context);context.testWC=wc;vm.runInContext('win={webContents:testWC};engineOrigin="http://127.0.0.1:3000";',context);
 const event={sender:wc,senderFrame:localFrame};assert.equal(handlers.get('terminal:clipboard-read')(event),'echo clipboard');handlers.get('terminal:clipboard-write')(event,'copied');assert.equal(value,'copied');
 assert.throws(()=>handlers.get('terminal:clipboard-read')({sender:wc,senderFrame:{url:localFrame.url}}));
 localFrame.url='https://example.com';assert.throws(()=>handlers.get('terminal:clipboard-read')(event));
});
test('native file dialogs require the trusted application frame',async()=>{
 const vm=require('node:vm'),handlers=new Map();let opened=0;const localFrame={url:'http://127.0.0.1:3000/#token=test'};const wc={mainFrame:localFrame};const dialog={showOpenDialog:async()=>{opened++;return{canceled:false,filePaths:['C:\\Downloads\\one.txt']}},showSaveDialog:async()=>{opened++;return{canceled:false,filePath:'C:\\Downloads\\out.txt'}}};const electron={app:{getPath:()=>'/downloads',requestSingleInstanceLock:()=>true,on:()=>{},whenReady:()=>new Promise(()=>{})},BrowserWindow:function(){},dialog,session:{},ipcMain:{handle:(k,f)=>handlers.set(k,f)},clipboard:{}};const c={require:n=>n==='electron'?electron:require(n),process,setTimeout,clearTimeout,console,__dirname};vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+'/main.cjs','utf8'),c);c.wc=wc;vm.runInContext('win={webContents:wc};engineOrigin="http://127.0.0.1:3000"',c);const event={sender:wc,senderFrame:localFrame};assert.equal((await handlers.get('files:pick-upload')(event)).paths.length,1);assert.equal((await handlers.get('files:pick-save')(event,'out.txt')).cancelled,false);await assert.rejects(handlers.get('files:pick-save')(event,'../secret'));await assert.rejects(handlers.get('files:pick-upload')({sender:wc,senderFrame:{url:localFrame.url}}));assert.equal(opened,2);
});

require('node:test')('installer filename matches the product version',()=>{const pkg=require('./package.json');require('node:assert/strict').equal(pkg.build.win.artifactName,'SSH-Server-v'+pkg.version+'-Setup.${ext}')});
