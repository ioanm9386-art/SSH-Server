package main

import (
	"context"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestLinuxSamplerEmitsTenIntegerMetrics(t *testing.T) {
	if runtime.GOOS != "linux" {
		t.Skip("Linux /proc sampler")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 1300*time.Millisecond)
	defer cancel()
	output, _ := exec.CommandContext(ctx, "sh", "-c", sampler).Output()
	samples := 0
	for _, line := range strings.Split(string(output), "\n") {
		if !strings.HasPrefix(line, "SAMPLE ") {
			continue
		}
		f := strings.Fields(line)
		if len(f) != 11 {
			t.Fatalf("wrong sample layout: %q", line)
		}
		for _, v := range f[1:] {
			if _, e := strconv.ParseUint(v, 10, 64); e != nil {
				t.Fatalf("counter not an integer: %q (%v)", line, e)
			}
		}
		samples++
	}
	if samples < 1 {
		t.Fatal("No Linux metrics collected")
	}
}
