package main

import (
	"fmt"
	"net/url"
	"strings"
	"time"
)

// The end is exclusive; the UI advances a selected ending minute by one minute.
func filterJournal(entries []JournalEntry, q url.Values) ([]JournalEntry, error) {
	var from, to time.Time
	var err error
	if q.Get("from") != "" {
		from, err = time.Parse(time.RFC3339, q.Get("from"))
		if err != nil {
			return nil, fmt.Errorf("Invalid starting date")
		}
	}
	if q.Get("to") != "" {
		to, err = time.Parse(time.RFC3339, q.Get("to"))
		if err != nil {
			return nil, fmt.Errorf("Invalid ending date")
		}
	}
	if !from.IsZero() && !to.IsZero() && !to.After(from) {
		return nil, fmt.Errorf("Ending date must follow starting date")
	}
	out := []JournalEntry{}
	text := strings.ToLower(q.Get("search"))
	level := q.Get("level")
	for _, a := range entries {
		if !from.IsZero() && a.At.Before(from) {
			continue
		}
		if !to.IsZero() && !a.At.Before(to) {
			continue
		}
		if level != "" && a.Level != level {
			continue
		}
		if text != "" && !strings.Contains(strings.ToLower(a.Action+" "+a.Detail+" "+a.Level), text) {
			continue
		}
		out = append(out, a)
	}
	return out, nil
}
