import unittest
from unittest.mock import patch
import network
class InterfaceTests(unittest.TestCase):
 def test_hardware_and_docker_are_separate(self):
  links=[{'ifname':'enp0s25'},{'ifname':'docker0','linkinfo':{'info_kind':'bridge'}},{'ifname':'veth123','linkinfo':{'info_kind':'veth'}},{'ifname':'tailscale0'},{'ifname':'lo'}]
  with patch('network.os.path.exists',side_effect=lambda p:p=='/sys/class/net/enp0s25/device'),patch('network.os.path.isdir',return_value=False),patch('network.textfile',return_value=''):
   result=network.enrich_links(links)
  self.assertEqual([x['category'] for x in result],['hardware','virtual','virtual','vpn','loopback'])
  self.assertIsNone(result[0]['speedMbps'])
 def test_diagnostics_use_arguments_not_shell(self):
  with patch('network.read',return_value='fixture') as read:
   self.assertEqual(network.diagnostic({'action':'ping','host':'192.168.1.1'})['output'],'fixture')
   read.assert_called_once_with(['ping','-n','-c','3','-W','1','--','192.168.1.1'])
  for host in ['-c 10000','localhost; reboot','$(id)']:
   with self.assertRaises(ValueError):network.diagnostic({'action':'ping','host':host})
 def test_tcp_requires_valid_port(self):
  with self.assertRaises(ValueError):network.diagnostic({'action':'tcp','host':'example.test','port':65536})
