package main

import (
	"context"
	"errors"
	"strings"
	"sync"
)

type boundedOutput struct {
	mu sync.Mutex
	b  []byte
}

func (b *boundedOutput) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if len(b.b)+len(p) > 2<<20 {
		return 0, errors.New("SSH response exceeds 2 MiB")
	}
	b.b = append(b.b, p...)
	return len(p), nil
}
func (s *Server) runNative(ctx context.Context, p Profile, password, command, input string) ([]byte, error) {
	c, extra, e := s.dialSSH(ctx, p, password)
	if e != nil {
		return nil, e
	}
	defer c.Close()
	if extra != nil {
		defer extra.Close()
	}
	stop := context.AfterFunc(ctx, func() { c.Close() })
	defer stop()
	session, e := c.NewSession()
	if e != nil {
		return nil, e
	}
	defer session.Close()
	var out boundedOutput
	var stderr boundedOutput
	session.Stdout = &out
	session.Stderr = &stderr
	session.Stdin = strings.NewReader(input)
	e = session.Run(command)
	if ctx.Err() != nil {
		return out.b, ctx.Err()
	}
	if e != nil {
		return out.b, errors.New("Remote operation failed: " + trimSpace(string(stderr.b), 350))
	}
	return out.b, nil
}
