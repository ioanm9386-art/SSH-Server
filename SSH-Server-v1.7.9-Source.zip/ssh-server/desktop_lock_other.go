//go:build !windows

package main

func desktopGuard() (func(), error) { return func() {}, nil }
