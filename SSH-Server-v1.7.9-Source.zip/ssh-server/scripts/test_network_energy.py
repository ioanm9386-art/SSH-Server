import unittest
from unittest.mock import patch
import network,energy
class NetworkEnergyTests(unittest.TestCase):
 def test_plan_is_validated_and_preview_only(self):
  with patch('network.socket.if_nameindex',return_value=[(2,'eth0')]):
   p=network.plan({'interface':'eth0','mode':'static','address':'192.168.1.10/24','gateway':'192.168.1.1','dns':'1.1.1.1'})
   self.assertTrue(p['previewOnly']);self.assertFalse(p['configuration']['network']['ethernets']['eth0']['dhcp4'])
   with self.assertRaises(ValueError):network.plan({'interface':'eth0','mode':'static','address':'192.168.1.10/24','gateway':'10.0.0.1'})
 def test_ups_never_converts_percent_or_va(self):
  with patch('energy.subprocess.run') as run:
   run.return_value.returncode=0;run.return_value.stdout='120.5'
   self.assertEqual(energy.collect({'kind':'nut','ups':'ups@localhost'})['watts'],120.5)
   self.assertEqual(run.call_args.args[0],['upsc','ups@localhost','ups.realpower'])
  with self.assertRaises(ValueError):energy.collect({'kind':'nut','ups':'-unsafe'})
 def test_rapl_missing_is_unavailable(self):
  with patch('energy.rapl_snapshot',return_value={}),patch('energy.time.sleep'):
   with self.assertRaises(ValueError):energy.collect({'kind':'rapl'})
