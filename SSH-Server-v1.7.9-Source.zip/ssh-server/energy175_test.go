package main

import (
	"context"
	"encoding/json"
	"math"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestEnergyIntegrationGaps175(t *testing.T) {
	start := time.Now()
	a := EnergySample{At: start, Watts: 100}
	b := integrateEnergy(a, EnergySample{At: start.Add(time.Minute), Watts: 100})
	if math.Abs(b.KWh-100.0/60000) > 1e-10 || b.CoveredSeconds != 60 {
		t.Fatal(b)
	}
	c := integrateEnergy(b, EnergySample{At: start.Add(time.Hour), Watts: 100})
	if c.KWh != b.KWh || c.CoveredSeconds != 60 {
		t.Fatal("gap counted", c)
	}
	c = integrateEnergy(b, EnergySample{At: start.Add(2 * time.Minute), Error: "unavailable"})
	if c.KWh != b.KWh {
		t.Fatal("missing sample counted")
	}
}
func TestHAUnitsAndRedirect175(t *testing.T) {
	token, e := encryptSecret("fixture-token")
	if e != nil {
		t.Fatal(e)
	}
	unit := "kW"
	called := false
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer fixture-token" {
			t.Error("bad authorization")
		}
		if r.URL.Path != "/api/states/sensor.power" {
			t.Error(r.URL.Path)
		}
		called = true
		json.NewEncoder(w).Encode(map[string]any{"state": "0.12", "attributes": map[string]string{"unit_of_measurement": unit}})
	}))
	defer server.Close()
	c := EnergyConfig{Kind: "ha", URL: server.URL, Entity: "sensor.power", Scope: "Dedicated server meter", Token: token}
	if validEnergy(c) == nil {
		t.Fatal("plaintext not explicitly authorized")
	}
	c.AllowHTTP = true
	if validEnergy(c) != nil {
		t.Fatal("local HA rejected")
	}
	watts, e := haPower(context.Background(), c)
	if e != nil || watts != 120 || !called {
		t.Fatal(watts, e)
	}
	unit = "VA"
	if _, e := haPower(context.Background(), c); e == nil {
		t.Fatal("VA treated as watts")
	}
	redirect := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { http.Redirect(w, r, server.URL, http.StatusFound) }))
	defer redirect.Close()
	c.URL = redirect.URL
	called = false
	if _, e := haPower(context.Background(), c); e == nil || called {
		t.Fatal("redirect followed; token leakage risk")
	}
}
func TestEnergyConfigPersistenceAndTokenRedaction175(t *testing.T) {
	st, _ := openStore(t.TempDir())
	owner, _ := makeOwner("Owner", "owner-energy-test-password")
	st.data.Owner = owner
	st.data.Profiles = []Profile{{ID: "p"}}
	s := &Server{store: st}
	post := func(kind string) *httptest.ResponseRecorder {
		payload := map[string]any{"id": "p", "kind": kind, "url": "https://ha.example", "entity": "sensor.power", "scope": "Server meter", "token": "private-token", "tariff": 1, "ownerPassword": "owner-energy-test-password"}
		raw, _ := json.Marshal(payload)
		r := httptest.NewRequest("POST", "/api/energy", strings.NewReader(string(raw)))
		w := httptest.NewRecorder()
		s.energyEndpoint(w, r)
		return w
	}
	if w := post("ha"); w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	if st.snapshot().EnergyConfigs["p"].Token == "private-token" {
		t.Fatal("token persisted as plaintext")
	}
	w := httptest.NewRecorder()
	s.energyEndpoint(w, httptest.NewRequest("GET", "/api/energy?id=p", nil))
	if strings.Contains(w.Body.String(), "private-token") || strings.Contains(w.Body.String(), st.snapshot().EnergyConfigs["p"].Token) {
		t.Fatal("token returned")
	}
	s.saveEnergy("p", EnergySample{At: time.Now(), Watts: 50})
	if w := post("off"); w.Code != 200 {
		t.Fatal("disable failed", w.Code, w.Body.String())
	}
	if st.snapshot().EnergyConfigs["p"].Enabled || len(st.snapshot().EnergyHistory["p"]) != 1 {
		t.Fatal("disable erased history or remained enabled")
	}
	reopened, e := openStore(st.dir)
	if e != nil || len(reopened.snapshot().EnergyHistory["p"]) != 1 {
		t.Fatal("history persistence failed", e)
	}
}
