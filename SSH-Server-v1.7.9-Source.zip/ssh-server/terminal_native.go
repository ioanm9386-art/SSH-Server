package main

import (
	"context"
	"errors"
	"fmt"
	"golang.org/x/crypto/ssh"
	"golang.org/x/crypto/ssh/agent"
	"golang.org/x/crypto/ssh/knownhosts"
	"io"
	"net"
	"os"
	"strconv"
	"time"
)

type terminalWriter struct{ session *SSHSession }

func (w terminalWriter) Write(b []byte) (int, error) {
	w.session.appendOutput(string(b))
	return len(b), nil
}

func (s *Server) openTerminal(ctx context.Context, p Profile, supplied string) (*SSHSession, error) {
	client, agentConnection, e := s.dialSSH(ctx, p, supplied)
	if e != nil {
		return nil, e
	}
	cleanupAgent := func() {
		if agentConnection != nil {
			agentConnection.Close()
		}
	}
	shell, e := client.NewSession()
	if e != nil {
		client.Close()
		cleanupAgent()
		return nil, e
	}
	stdin, e := shell.StdinPipe()
	if e != nil {
		shell.Close()
		client.Close()
		cleanupAgent()
		return nil, e
	}
	session := &SSHSession{ID: randHex(8), Profile: p, Stdin: stdin, Started: time.Now(), conns: map[*WSConn]struct{}{}, NativeClient: client, NativeShell: shell, AgentConnection: agentConnection}
	shell.Stdout = terminalWriter{session}
	shell.Stderr = terminalWriter{session}
	modes := ssh.TerminalModes{ssh.ECHO: 1, ssh.VERASE: 127, ssh.TTY_OP_ISPEED: 38400, ssh.TTY_OP_OSPEED: 38400}
	if e = shell.RequestPty("xterm-256color", 30, 100, modes); e != nil {
		session.closeTransport()
		return nil, e
	}
	if e = shell.Shell(); e != nil {
		session.closeTransport()
		return nil, e
	}
	return session, nil
}
func (s *SSHSession) closeTransport() {
	if s.NativeShell != nil {
		_ = s.NativeShell.Close()
	}
	if s.NativeClient != nil {
		_ = s.NativeClient.Close()
	}
	if s.AgentConnection != nil {
		_ = s.AgentConnection.Close()
	}
	if s.Cmd != nil && s.Cmd.Process != nil {
		_ = s.Cmd.Process.Kill()
	}
}

func (s *Server) dialSSH(ctx context.Context, p Profile, supplied string) (*ssh.Client, io.ReadWriteCloser, error) {
	known, e := s.knownHosts(p)
	if e != nil {
		return nil, nil, e
	}
	verify, e := knownhosts.New(known)
	if e != nil {
		return nil, nil, errors.New("Cannot read approved host keys")
	}
	algorithms, e := approvedHostKeyAlgorithms(p.HostKeys)
	if e != nil {
		return nil, nil, e
	}
	var methods []ssh.AuthMethod
	var agentConnection io.ReadWriteCloser
	switch p.Auth {
	case "password":
		password := s.sshCredential(p, supplied)
		if password == "" {
			return nil, nil, errors.New("Unlock this server with its SSH password first")
		}
		methods = []ssh.AuthMethod{ssh.Password(password), ssh.KeyboardInteractive(func(user, instruction string, questions []string, echo []bool) ([]string, error) {
			if len(questions) != 1 || len(echo) != 1 || echo[0] {
				return nil, errors.New("Additional server authentication challenge is not supported here")
			}
			return []string{password}, nil
		})}
	case "key":
		f, err := os.Open(p.KeyPath)
		if err != nil {
			return nil, nil, errors.New("Private SSH key file is not accessible")
		}
		data, err := io.ReadAll(io.LimitReader(f, 1<<20))
		f.Close()
		if err != nil {
			return nil, nil, err
		}
		signer, err := ssh.ParsePrivateKey(data)
		if err != nil {
			return nil, nil, errors.New("Cannot unlock the key. Load passphrase-protected keys in SSH Agent and select Agent authentication")
		}
		methods = []ssh.AuthMethod{ssh.PublicKeys(signer)}
	case "agent":
		agentConnection, e = openSSHAgent()
		if e != nil {
			return nil, nil, errors.New("SSH Agent unavailable. Start/unlock the agent and load the key, or choose password authentication")
		}
		methods = []ssh.AuthMethod{ssh.PublicKeysCallback(agent.NewClient(agentConnection).Signers)}
	default:
		return nil, nil, errors.New("Unsupported SSH authentication method")
	}
	cleanupAgent := func() {
		if agentConnection != nil {
			agentConnection.Close()
		}
	}
	address := net.JoinHostPort(p.Host, strconv.Itoa(p.Port))
	conn, e := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp", address)
	if e != nil {
		cleanupAgent()
		return nil, nil, e
	}
	deadline := time.Now().Add(15 * time.Second)
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	_ = conn.SetDeadline(deadline)
	config := &ssh.ClientConfig{User: p.User, Auth: methods, HostKeyCallback: verify, HostKeyAlgorithms: algorithms, ClientVersion: "SSH-2.0-SSHServer_1.7.9"}
	cc, chans, requests, e := ssh.NewClientConn(conn, address, config)
	if e != nil {
		conn.Close()
		cleanupAgent()
		var keyError *knownhosts.KeyError
		if errors.As(e, &keyError) {
			return nil, nil, fmt.Errorf("Server identity does not match the approved fingerprint. Verify the host key on the server before approving any change: %w", e)
		}
		return nil, nil, e
	}
	_ = conn.SetDeadline(time.Time{})
	client := ssh.NewClient(cc, chans, requests)
	return client, agentConnection, nil
}
