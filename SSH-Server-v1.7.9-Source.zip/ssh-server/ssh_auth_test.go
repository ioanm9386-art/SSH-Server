package main

import (
	"context"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestAuthMethodControlsSSHArguments(t *testing.T) {
	for _, method := range []string{"password", "key", "agent"} {
		t.Run(method, func(t *testing.T) {
			st, err := openStore(t.TempDir())
			if err != nil {
				t.Fatal(err)
			}
			s := &Server{store: st}
			p := Profile{ID: "test", Host: "example.test", Port: 22, User: "test", Auth: method, KeyPath: "keyfile", HostKeys: []string{"example.test ssh-ed25519 AAAA"}}
			cmd, err := s.sshCmd(context.Background(), p, "a-secret", false, "")
			if err != nil {
				t.Fatal(err)
			}
			args := strings.Join(cmd.Args, " ")
			switch method {
			case "password":
				if !strings.Contains(args, "PubkeyAuthentication=no") || !strings.Contains(args, "PreferredAuthentications=password,keyboard-interactive") {
					t.Fatal(args)
				}
			case "key":
				if !strings.Contains(args, "-i keyfile") || !strings.Contains(args, "IdentitiesOnly=yes") {
					t.Fatal(args)
				}
			case "agent":
				if !strings.Contains(args, "BatchMode=yes") || !strings.Contains(args, "PasswordAuthentication=no") {
					t.Fatal(args)
				}
			}
			if strings.Contains(args, "a-secret") {
				t.Fatal("SSH password leaked into arguments")
			}
		})
	}
}
func TestNativePickerValidation(t *testing.T) {
	s := &Server{}
	for _, v := range []struct {
		method, body string
		status       int
	}{{"GET", "", 405}, {"POST", `{"kind":"unsupported"}`, 400}, {"POST", `{"kind":"folder","unknown":true}`, 400}} {
		r := httptest.NewRequest(v.method, "/api/native/pick", strings.NewReader(v.body))
		w := httptest.NewRecorder()
		s.pickEndpoint(w, r)
		if w.Code != v.status {
			t.Fatalf("got %d want %d", w.Code, v.status)
		}
	}
}
