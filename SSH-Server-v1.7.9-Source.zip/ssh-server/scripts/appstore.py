"""Read-only App Store inventory. No sudo, package refresh, installs or raw repository credentials."""
import json,subprocess,os,time,shutil,glob,re
from urllib.parse import urlsplit
os.environ["LC_ALL"]="C"

def command(args,timeout=15):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        if p.returncode:return None
        return p.stdout[:1500000]
    except (OSError,subprocess.TimeoutExpired):return None

def repositories():
    result=[]
    def add(source,uris,suites,components,enabled=True):
        hosts=[]
        for uri in uris.split():
            try:
                host=urlsplit(uri).hostname
                if host:hosts.append(host)
            except ValueError:pass
        result.append({'file':os.path.basename(source),'hosts':hosts,'suites':suites.split(),'components':components.split(),'enabled':enabled})
    for file in ['/etc/apt/sources.list']+sorted(glob.glob('/etc/apt/sources.list.d/*.list'))+sorted(glob.glob('/etc/apt/sources.list.d/*.sources')):
        try:
            with open(file) as f:text=f.read(200000)
        except OSError:continue
        if file.endswith('.sources'):
            for block in re.split(r'\n\s*\n',text):
                fields={}
                for line in block.splitlines():
                    if ':' in line and not line.startswith(('#',' ','\t')):
                        k,v=line.split(':',1);fields[k.lower()]=v.strip()
                if 'uris' in fields:add(file,fields['uris'],fields.get('suites',''),fields.get('components',''),fields.get('enabled','yes').lower()!='no')
        else:
            for line in text.splitlines():
                if not line.strip().startswith('deb '):continue
                line=re.sub(r'\[[^]]*\]','',line).split('#',1)[0];parts=line.split()
                if len(parts)>=3:add(file,parts[1],parts[2],' '.join(parts[3:]))
    return result[:100]

def collect():
    osinfo={}
    try:
        with open('/etc/os-release') as f:
            for line in f:
                if '=' in line:
                    k,v=line.strip().split('=',1);osinfo[k]=v.strip('"')
    except OSError:pass
    installed={};raw=command(['dpkg-query','-W','-f=${Package}\t${Version}\t${db:Status-Status}\n'])
    if raw is not None:
        for line in raw.splitlines():
            parts=line.split('\t')
            if len(parts)==3 and parts[2]=='installed':installed[parts[0]]=parts[1]
    updates=[];upgrade=command(['apt','list','--upgradable'],25) if shutil.which('apt') else None
    for line in (upgrade or '').splitlines():
        parts=line.split()
        if len(parts)>2 and '/' in parts[0]:updates.append({'name':parts[0].split('/')[0],'candidate':parts[1],'installed':installed.get(parts[0].split('/')[0],'')})
    docker=command(['docker','ps','-a','--format','{{json .}}']);containers=[]
    for line in (docker or '').splitlines():
        try:
            c=json.loads(line);containers.append({k:c.get(k,'') for k in ('ID','Names','Image','Status','State','Ports')})
        except ValueError:pass
    base='/opt' if os.path.exists('/opt') else '/';disk=shutil.disk_usage(base)
    cache=glob.glob('/var/lib/apt/lists/*_Packages*');cache_at=max((os.path.getmtime(x) for x in cache),default=0)
    return {'at':int(time.time()),'os':osinfo,'kernel':os.uname().release,'architecture':os.uname().machine,'disk':{'path':base,'total':disk.total,'used':disk.used,'free':disk.free},'aptAvailable':bool(shutil.which('apt-get')),'packagesKnown':raw is not None,'packages':installed,'updatesKnown':upgrade is not None,'updates':updates,'aptCacheAt':cache_at,'repositories':repositories(),'dockerAvailable':docker is not None,'composeAvailable':command(['docker','compose','version']) is not None,'containers':containers,'repositoryManagement':'read-only'}
if __name__=='__main__':print(json.dumps(collect()))
