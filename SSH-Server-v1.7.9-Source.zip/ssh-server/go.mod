module sshserver/v1.1

go 1.26.0

require golang.org/x/crypto v0.58.0

require (
	github.com/kr/fs v0.1.0 // indirect
	github.com/pkg/sftp v1.13.10 // indirect
	golang.org/x/sys v0.49.0 // indirect
)
