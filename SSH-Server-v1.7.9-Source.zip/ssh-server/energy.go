package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type EnergyConfig struct {
	Enabled   bool    `json:"enabled"`
	AllowHTTP bool    `json:"allowHTTP"`
	ID        string  `json:"id"`
	Kind      string  `json:"kind"`
	URL       string  `json:"url"`
	Entity    string  `json:"entity"`
	Token     string  `json:"token,omitempty"`
	UPS       string  `json:"ups"`
	Scope     string  `json:"scope"`
	Tariff    float64 `json:"tariff"`
}
type EnergySample struct {
	At             time.Time `json:"at"`
	Watts          float64   `json:"watts"`
	KWh            float64   `json:"kwh"`
	CoveredSeconds float64   `json:"coveredSeconds"`
	Scope          string    `json:"scope"`
	Error          string    `json:"error,omitempty"`
}

func validEnergy(c EnergyConfig) error {
	if c.Tariff < 0 || c.Tariff > 10000 || math.IsNaN(c.Tariff) {
		return errors.New("Invalid tariff")
	}
	switch c.Kind {
	case "off", "rapl":
		return nil
	case "nut":
		if regexp.MustCompile(`^[A-Za-z0-9_.:@\[\]-]{1,180}$`).MatchString(c.UPS) && !strings.HasPrefix(c.UPS, "-") {
			return nil
		}
	case "ha":
		u, e := url.Parse(c.URL)
		if e == nil && u.Host != "" && u.User == nil && u.RawQuery == "" && u.Fragment == "" && (u.Scheme == "https" || (u.Scheme == "http" && c.AllowHTTP)) && regexp.MustCompile(`^sensor\.[a-z0-9_]{1,120}$`).MatchString(c.Entity) && len(c.Scope) > 0 && len(c.Scope) < 160 {
			return nil
		}
	}
	return errors.New("Choose a supported energy source and valid settings")
}
func (s *Server) energyEndpoint(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if r.Method == "GET" {
		d := s.store.snapshot()
		c := d.EnergyConfigs[id]
		has := c.Token != ""
		c.Token = ""
		samples := d.EnergyHistory[id]
		if samples == nil {
			samples = []EnergySample{}
		}
		jsonOut(w, 200, map[string]any{"config": c, "hasToken": has, "samples": samples, "collection": "While SSH Server Windows is open"})
		return
	}
	if r.Method != "POST" && r.Method != "DELETE" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct {
		EnergyConfig
		OwnerPassword string `json:"ownerPassword"`
		Code          string `json:"code"`
	}
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	if !ownerVerified(s.store.snapshot().Owner, a.OwnerPassword, a.Code) {
		fail(w, 403, "Owner confirmation required")
		return
	}
	if r.Method == "DELETE" {
		s.energyMu.Lock()
		defer s.energyMu.Unlock()
		s.store.mu.Lock()
		defer s.store.mu.Unlock()
		delete(s.store.data.EnergyHistory, a.ID)
		if e := s.store.saveLocked(); e != nil {
			fail(w, 500, "Could not clear history")
			return
		}
		jsonOut(w, 200, map[string]bool{"ok": true})
		return
	}
	if _, ok := s.findProfile(a.ID); !ok {
		fail(w, 404, "Server not found")
		return
	}
	if e := validEnergy(a.EnergyConfig); e != nil {
		fail(w, 400, e.Error())
		return
	}
	s.energyMu.Lock()
	defer s.energyMu.Unlock()
	old := s.store.snapshot().EnergyConfigs[a.ID]
	if a.Kind == "off" && old.Kind != "" {
		a.EnergyConfig = old
		a.Enabled = false
	} else {
		a.Enabled = a.Kind != "off"
	}
	if a.Kind == "ha" {
		if a.Token != "" && a.Enabled {
			cipher, e := encryptSecret(a.Token)
			if e != nil {
				fail(w, 500, "Could not protect token")
				return
			}
			a.Token = cipher
		} else if old.Kind == "ha" && old.URL == a.URL {
			a.Token = old.Token
		}
		if a.Token == "" {
			fail(w, 400, "Home Assistant token required")
			return
		}
	} else {
		a.Token = ""
	}
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	if s.store.data.EnergyConfigs == nil {
		s.store.data.EnergyConfigs = map[string]EnergyConfig{}
	}
	if s.store.data.EnergyHistory == nil {
		s.store.data.EnergyHistory = map[string][]EnergySample{}
	}
	changed := old.Kind != a.Kind || old.URL != a.URL || old.Entity != a.Entity || old.UPS != a.UPS || old.Scope != a.Scope
	if changed && len(s.store.data.EnergyHistory[a.ID]) > 0 {
		fail(w, 409, "Export then clear existing energy history before changing the measured source")
		return
	}
	s.store.data.EnergyConfigs[a.ID] = a.EnergyConfig
	if e := s.store.saveLocked(); e != nil {
		fail(w, 500, "Could not save energy settings")
		return
	}
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func haPower(ctx context.Context, c EnergyConfig) (float64, error) {
	secret, e := decryptSecret(c.Token)
	if e != nil {
		return 0, errors.New("Could not unlock Home Assistant token")
	}
	req, e := http.NewRequestWithContext(ctx, "GET", strings.TrimRight(c.URL, "/")+"/api/states/"+url.PathEscape(c.Entity), nil)
	if e != nil {
		return 0, e
	}
	req.Header.Set("Authorization", "Bearer "+secret)
	client := &http.Client{Timeout: 10 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return errors.New("Redirect rejected") }}
	res, e := client.Do(req)
	if e != nil {
		return 0, errors.New("Home Assistant unavailable; check address and TLS certificate")
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return 0, fmt.Errorf("Home Assistant HTTP %d", res.StatusCode)
	}
	var data struct {
		State       string    `json:"state"`
		LastUpdated time.Time `json:"last_updated"`
		Attributes  struct {
			Unit string `json:"unit_of_measurement"`
		} `json:"attributes"`
	}
	if json.NewDecoder(io.LimitReader(res.Body, 200000)).Decode(&data) != nil {
		return 0, errors.New("Invalid sensor response")
	}
	watts, e := strconv.ParseFloat(data.State, 64)
	if e != nil {
		return 0, errors.New("Sensor unavailable or nonnumeric")
	}
	switch data.Attributes.Unit {
	case "W":
	case "kW":
		watts *= 1000
	default:
		return 0, errors.New("Select a power sensor in W or kW, not VA or percent")
	}
	return watts, nil
}
func integrateEnergy(previous EnergySample, now EnergySample) EnergySample {
	now.KWh = previous.KWh
	now.CoveredSeconds = previous.CoveredSeconds
	seconds := now.At.Sub(previous.At).Seconds()
	if !previous.At.IsZero() && previous.Error == "" && now.Error == "" && seconds > 0 && seconds <= 120 {
		now.KWh += (previous.Watts + now.Watts) / 2 * seconds / 3600000
		now.CoveredSeconds += seconds
	}
	return now
}
func (s *Server) sampleEnergy(ctx context.Context, c EnergyConfig) EnergySample {
	sample := EnergySample{At: time.Now(), Scope: c.Scope}
	var watts float64
	var err error
	if c.Kind == "ha" {
		watts, err = haPower(ctx, c)
	} else {
		p, ok := s.findProfile(c.ID)
		if !ok {
			err = errors.New("Server removed")
		} else if p.Auth == "password" && s.sshCredential(p, "") == "" {
			err = errors.New("Unlock SSH server first")
		} else {
			script, _ := adminAssets.ReadFile("scripts/energy.py")
			input, _ := json.Marshal(map[string]string{"kind": c.Kind, "ups": c.UPS})
			out, e := s.runNative(ctx, p, "", pythonCommand(script), string(input))
			err = e
			if e != nil {
				var failure struct {
					Error string `json:"error"`
				}
				if json.Unmarshal(out, &failure) == nil && failure.Error != "" {
					err = errors.New(failure.Error)
				}
			}
			if e == nil {
				var result struct {
					Watts float64 `json:"watts"`
					Scope string  `json:"scope"`
				}
				err = json.Unmarshal(out, &result)
				watts = result.Watts
				sample.Scope = result.Scope
			}
		}
	}
	if err == nil && (math.IsNaN(watts) || math.IsInf(watts, 0) || watts < 0 || watts > 10000000) {
		err = errors.New("Invalid power measurement")
	}
	if err != nil {
		sample.Error = "Energy unavailable: " + trimSpace(err.Error(), 250)
	} else {
		sample.Watts = watts
	}
	sample.At = time.Now()
	return sample
}
func (s *Server) energySampleEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	s.energyMu.Lock()
	defer s.energyMu.Unlock()
	c, ok := s.store.snapshot().EnergyConfigs[a.ID]
	if !ok || c.Kind == "off" || !c.Enabled {
		fail(w, 412, "Configure an energy source first")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()
	sample := s.sampleEnergy(ctx, c)
	if err := s.saveEnergy(c.ID, sample); err != nil {
		fail(w, 500, "Could not save measurement")
		return
	}
	jsonOut(w, 200, map[string]any{"sample": sample})
}
func (s *Server) saveEnergy(id string, sample EnergySample) error {
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	if s.store.data.EnergyHistory == nil {
		s.store.data.EnergyHistory = map[string][]EnergySample{}
	}
	rows := s.store.data.EnergyHistory[id]
	if len(rows) > 0 {
		sample = integrateEnergy(rows[len(rows)-1], sample)
	}
	rows = append(rows, sample)
	cut := time.Now().Add(-30 * 24 * time.Hour)
	start := 0
	for start < len(rows) && rows[start].At.Before(cut) {
		start++
	}
	rows = rows[start:]
	if len(rows) > 45000 {
		rows = rows[len(rows)-45000:]
	}
	s.store.data.EnergyHistory[id] = rows
	return s.store.saveLocked()
}
func (s *Server) energyLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			s.energyMu.Lock()
			for _, c := range s.store.snapshot().EnergyConfigs {
				if c.Kind == "off" || !c.Enabled {
					continue
				}
				one, cancel := context.WithTimeout(ctx, 15*time.Second)
				sample := s.sampleEnergy(one, c)
				cancel()
				s.saveEnergy(c.ID, sample)
			}
			s.energyMu.Unlock()
		}
	}
}
