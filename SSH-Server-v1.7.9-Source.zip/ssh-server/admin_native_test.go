package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"errors"
	"golang.org/x/crypto/ssh"
	"io"
	"net"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestNativeAdministrativeCommandPreservesPrivateInput(t *testing.T) {
	_, key, _ := ed25519.GenerateKey(rand.Reader)
	signer, _ := ssh.NewSignerFromKey(key)
	cfg := &ssh.ServerConfig{PasswordCallback: func(_ ssh.ConnMetadata, p []byte) (*ssh.Permissions, error) {
		if string(p) != "ssh-test-password" {
			return nil, errors.New("denied")
		}
		return nil, nil
	}}
	cfg.AddHostKey(signer)
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	defer ln.Close()
	input := make(chan string, 1)
	go func() {
		conn, e := ln.Accept()
		if e != nil {
			return
		}
		defer conn.Close()
		_, channels, requests, e := ssh.NewServerConn(conn, cfg)
		if e != nil {
			return
		}
		go ssh.DiscardRequests(requests)
		for incoming := range channels {
			ch, reqs, e := incoming.Accept()
			if e != nil {
				return
			}
			for req := range reqs {
				if req.Type != "exec" {
					req.Reply(false, nil)
					continue
				}
				var msg struct{ Command string }
				ssh.Unmarshal(req.Payload, &msg)
				if strings.Contains(msg.Command, "sudo-test-password") {
					input <- "password leaked in command"
					return
				}
				req.Reply(true, nil)
				b, _ := io.ReadAll(ch)
				input <- string(b)
				io.WriteString(ch, `{"ok":true,"result":{"hostname":"qa"}}`)
				ch.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{0}))
				ch.Close()
				return
			}
		}
	}()
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	number, _ := strconv.Atoi(port)
	st, _ := openStore(t.TempDir())
	s := &Server{store: st}
	p := Profile{ID: "admin-test", User: "qa", Host: "127.0.0.1", Port: number, Auth: "password", HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	stdin := "sudo-test-password\n{\"action\":\"service\"}"
	out, e := s.runNative(ctx, p, "ssh-test-password", "sudo -S python3 -c 'test'", stdin)
	if e != nil || !strings.Contains(string(out), `"hostname":"qa"`) {
		t.Fatal(string(out), e)
	}
	if got := <-input; got != stdin {
		t.Fatal("stdin changed or secret leaked", got)
	}
}
