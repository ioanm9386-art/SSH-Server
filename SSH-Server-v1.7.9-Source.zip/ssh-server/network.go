package main

import (
	"context"
	"encoding/json"
	"net/http"
	"time"
)

func (s *Server) networkState(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	s.runNetwork(w, r, r.URL.Query().Get("id"), map[string]any{"action": "state"})
}
func (s *Server) networkDiagnose(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct {
		ID     string         `json:"id"`
		Params map[string]any `json:"params"`
	}
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	if a.Params["action"] != "dns" && a.Params["action"] != "plan" && a.Params["action"] != "ping" && a.Params["action"] != "tcp" {
		fail(w, 400, "Unsupported diagnostic")
		return
	}
	s.runNetwork(w, r, a.ID, a.Params)
}
func (s *Server) runNetwork(w http.ResponseWriter, r *http.Request, id string, params map[string]any) {
	p, ok := s.findProfile(id)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	script, _ := adminAssets.ReadFile("scripts/network.py")
	input, _ := json.Marshal(params)
	ctx, cancel := context.WithTimeout(r.Context(), 50*time.Second)
	defer cancel()
	out, e := s.runNative(ctx, p, "", pythonCommand(script), string(input))
	if e != nil {
		fail(w, 502, e.Error())
		return
	}
	var result any
	if json.Unmarshal(out, &result) != nil {
		fail(w, 502, "Invalid network data")
		return
	}
	jsonOut(w, 200, result)
}
