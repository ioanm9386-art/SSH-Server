import json,os,subprocess,time,glob,socket,shutil

def run(args,json_result=False,timeout=12):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        if json_result and p.stdout.strip().startswith(('{','[')):
            try:return json.loads(p.stdout)
            except ValueError:pass
        if p.returncode!=0:return {'available':False,'reason':p.stderr.strip()[:500] or 'Command returned '+str(p.returncode)}
        return json.loads(p.stdout) if json_result else p.stdout.strip()
    except Exception as e:return {'available':False,'reason':str(e)[:300]}
def read(p,default=''):
    try:
        with open(p) as f:return f.read().strip()
    except OSError:return default
def collect():
    osinfo={}
    for line in read('/etc/os-release').splitlines():
        if '=' in line:
            k,v=line.split('=',1);osinfo[k]=v.strip('"')
    mem={}
    for line in read('/proc/meminfo').splitlines():
        k,v=line.split(':',1);mem[k]=int(v.split()[0])*1024
    cpu=read('/proc/stat').splitlines()[0].split()[1:];cpu=[int(x) for x in cpu];cpu_total=sum(cpu[:8]);cpu_idle=cpu[3]+cpu[4]
    arrays=[]
    for d in sorted(glob.glob('/sys/block/md*/md')):
        arrays.append({'name':d.split('/')[3],'level':read(d+'/level'),'state':read(d+'/array_state'),'degraded':read(d+'/degraded','unknown'),'members':read(d+'/raid_disks'),'sync':read(d+'/sync_action'),'progress':read(d+'/sync_completed'),'devices':[{'name':x.rsplit('/',1)[-1][4:],'state':read(x+'/state')} for x in glob.glob(d+'/dev-*')]})
    mounts=run(['findmnt','-J','-b','-o','TARGET,SOURCE,FSTYPE,SIZE,USED,AVAIL,USE%,OPTIONS'],True)
    disks=run(['lsblk','-J','-b','-o','NAME,PATH,TYPE,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINTS,MODEL,SERIAL,ROTA,RO'],True)
    if isinstance(disks,dict) and disks.get('available') is False:
        disks=run(['lsblk','-J','-b','-o','NAME,PATH,TYPE,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINT,MODEL,SERIAL,ROTA,RO'],True)
    ips=run(['ip','-j','address','show'],True);routes=run(['ip','-j','route','show'],True)
    services=run(['systemctl','list-units','--all','--type=service','--no-pager','--plain','--no-legend'])
    docker=run(['docker','ps','-a','--format','{{json .}}']);containers=[]
    if isinstance(docker,str):
        for line in docker.splitlines():
            try:containers.append(json.loads(line))
            except ValueError:pass
    smart=[]
    def visit(items):
        for d in items:
            if d.get('type')=='disk':
                check=run(['smartctl','-H','-j',d.get('path','')],True)
                smart.append({'device':d.get('path'),'result':check})
            visit(d.get('children',[]))
    if isinstance(disks,dict):visit(disks.get('blockdevices',[]))
    nics=[]
    for d in glob.glob('/sys/class/net/*'):
        nics.append({'name':os.path.basename(d),'state':read(d+'/operstate'),'speed':read(d+'/speed','unknown'),'mac':read(d+'/address'),'rx':read(d+'/statistics/rx_bytes','0'),'tx':read(d+'/statistics/tx_bytes','0')})
    networks={os.path.basename(p):read(p) for p in glob.glob('/etc/netplan/*.yaml')}
    # Config files may contain Wi-Fi credentials: never send their raw contents to the UI.
    netplan=[]
    try:
        import yaml
        for name,text in networks.items():
            cfg=yaml.safe_load(text) or {};network=cfg.get('network',{})
            for group in ('ethernets','wifis','bonds','bridges','vlans'):
                for name,values in network.get(group,{}).items():
                    netplan.append({'interface':name,'type':group,'dhcp4':values.get('dhcp4','unknown'),'dhcp6':values.get('dhcp6','unknown'),'addresses':values.get('addresses',[]),'dns':values.get('nameservers',{}).get('addresses',[]),'gateway4':values.get('gateway4',''),'routes':values.get('routes',[])})
    except Exception:pass
    interfaces_config=[]
    for line in read('/etc/network/interfaces').splitlines():
        stripped=line.strip()
        if stripped and stripped.split()[0] in ('auto','allow-hotplug','iface','address','netmask','gateway','dns-nameservers','bridge_ports','bond-slaves'):
            interfaces_config.append(stripped)
    fstab=[]
    for line in read('/etc/fstab').splitlines():
        fields=line.split()
        if fields and not fields[0].startswith('#') and len(fields)>=3:
            source=fields[0]
            if '@' in source:source='[credential-bearing source omitted]'
            fstab.append({'source':source,'target':fields[1],'filesystem':fields[2]})
    return {'fstab':fstab,'zfs':run(['zpool','list','-H']),'btrfs':run(['btrfs','filesystem','show']),'interfacesConfig':interfaces_config,'networkManager':run(['nmcli','-t','-f','GENERAL.DEVICE,GENERAL.STATE,IP4.ADDRESS,IP4.GATEWAY,IP4.DNS','device','show']),'at':int(time.time()),'hostname':socket.gethostname(),'os':osinfo,'kernel':os.uname().release,'cpuTotal':cpu_total,'cpuIdle':cpu_idle,'memoryTotal':mem.get('MemTotal',0),'memoryAvailable':mem.get('MemAvailable',0),'uptime':read('/proc/uptime').split()[0],'disks':disks,'mounts':mounts,'raid':arrays,'mdstat':read('/proc/mdstat'),'addresses':ips,'routes':routes,'interfaces':nics,'dns':run(['resolvectl','status']),'netplan':netplan,'netplanFiles':list(networks),'services':services,'containers':containers,'docker':{'available':isinstance(docker,str),'reason':docker.get('reason','') if isinstance(docker,dict) else ''},'compose':run(['docker','compose','version']),'smart':smart,'tools':{x:bool(shutil.which(x)) for x in ['lsblk','findmnt','mdadm','smartctl','docker','netplan','systemctl','apt-get']},'agent':run(['systemctl','is-active','ssh-server-agent.service'])}
if __name__=='__main__':print(json.dumps(collect()))
