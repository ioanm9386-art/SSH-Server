package main

import (
	"context"
	"encoding/base64"
	"errors"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

type FileItem struct {
	Permissions string    `json:"permissions,omitempty"`
	UID         uint32    `json:"uid"`
	GID         uint32    `json:"gid"`
	Link        bool      `json:"link,omitempty"`
	Name        string    `json:"name"`
	Path        string    `json:"path"`
	Type        string    `json:"type"`
	Size        int64     `json:"size"`
	Modified    time.Time `json:"modified"`
}
type Transfer struct {
	ServerID    string    `json:"serverId"`
	Bytes       int64     `json:"bytes"`
	Total       int64     `json:"total"`
	ID          string    `json:"id"`
	Kind        string    `json:"kind"`
	Source      string    `json:"source"`
	Destination string    `json:"destination"`
	Status      string    `json:"status"`
	Error       string    `json:"error,omitempty"`
	Started     time.Time `json:"started"`
	Finished    time.Time `json:"finished,omitempty"`
	cancel      context.CancelFunc
	mu          sync.Mutex
}

func listLocal(dir string) ([]FileItem, error) {
	items, e := os.ReadDir(dir)
	if e != nil {
		return nil, e
	}
	out := []FileItem{}
	for _, item := range items {
		info, e := item.Info()
		if e != nil {
			continue
		}
		typ := "file"
		if item.IsDir() {
			typ = "dir"
		}
		out = append(out, FileItem{Name: item.Name(), Path: filepath.Join(dir, item.Name()), Type: typ, Size: info.Size(), Modified: info.ModTime()})
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Type != out[j].Type {
			return out[i].Type == "dir"
		}
		return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
	})
	return out, nil
}
func defaultLocalDir() string {
	h, e := os.UserHomeDir()
	if e != nil {
		return "."
	}
	d := filepath.Join(h, "Downloads")
	if exists(d) {
		return d
	}
	return h
}
func (s *Server) localFiles(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	dir := r.URL.Query().Get("path")
	if dir == "" {
		dir = defaultLocalDir()
	}
	dir, e := filepath.Abs(dir)
	if e != nil {
		fail(w, 400, "Cale invalidă.")
		return
	}
	items, e := listLocal(dir)
	if e != nil {
		fail(w, 403, "Nu pot citi directorul local.")
		return
	}
	jsonOut(w, 200, map[string]any{"path": dir, "parent": filepath.Dir(dir), "items": items})
}
func shellQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
func safeRemote(s string) bool {
	return len(s) > 0 && len(s) < 900 && !strings.ContainsAny(s, "\n\r\x00")
}
func (s *Server) remoteCommand(r *http.Request, id, password, command string) (string, error) {
	p, ok := s.findProfile(id)
	if !ok {
		return "", errors.New("Serverul nu există")
	}
	ctx, cancel := context.WithTimeout(r.Context(), 25*time.Second)
	defer cancel()
	out, e := s.runNative(ctx, p, password, command, "")
	if e != nil {
		return "", e
	}
	if len(out) > 1<<20 {
		return "", errors.New("Răspunsul SSH este prea mare")
	}
	return string(out), nil
}
func (s *Server) remoteFiles(w http.ResponseWriter, r *http.Request) { s.nativeRemoteFiles(w, r) }
func (s *Server) filesAction(w http.ResponseWriter, r *http.Request) { s.nativeFileAction(w, r) }
func encodeBase64(s string) string                                   { return base64.StdEncoding.EncodeToString([]byte(s)) }
func quoteSFTP(p string) string {
	return `"` + strings.ReplaceAll(strings.ReplaceAll(p, `\`, `\\`), `"`, `\"`) + `"`
}
func (s *Server) startTransfer(w http.ResponseWriter, r *http.Request, id, kind, remote, local, password string, overwrite bool) {
	p, ok := s.findProfile(id)
	if !ok {
		fail(w, 404, "Serverul nu există.")
		return
	}
	if !safeRemote(remote) || len(local) > 1200 || local == "" || strings.ContainsAny(local, "\n\r\x00") {
		fail(w, 400, "Cale invalidă.")
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	s.mu.Lock()
	if s.transferSlots == nil {
		s.transferSlots = make(chan struct{}, 3)
	}
	active := 0
	for _, old := range s.transfers {
		old.mu.Lock()
		if old.Status == "queued" || old.Status == "running" {
			active++
		}
		old.mu.Unlock()
	}
	if active >= 40 {
		s.mu.Unlock()
		cancel()
		fail(w, 429, "Transfer queue is full (40 active files)")
		return
	}
	if len(s.transfers) > 200 {
		for key, old := range s.transfers {
			old.mu.Lock()
			done := old.Status != "queued" && old.Status != "running"
			old.mu.Unlock()
			if done {
				delete(s.transfers, key)
			}
		}
	}
	t := &Transfer{ServerID: p.ID, ID: randHex(8), Kind: kind, Source: remote, Destination: local, Status: "queued", Started: time.Now(), cancel: cancel}
	if s.transfers == nil {
		s.transfers = map[string]*Transfer{}
	}
	if kind == "upload" {
		t.Source = local
		t.Destination = remote
	}
	s.transfers[t.ID] = t
	s.mu.Unlock()
	go func() {
		select {
		case s.transferSlots <- struct{}{}:
			defer func() { <-s.transferSlots }()
		case <-ctx.Done():
			t.mu.Lock()
			t.Status = "cancelled"
			t.mu.Unlock()
			return
		}
		t.mu.Lock()
		t.Status = "running"
		t.mu.Unlock()
		err := s.nativeTransfer(ctx, p, kind, remote, local, password, overwrite, func(done, total int64) { t.mu.Lock(); t.Bytes = done; t.Total = total; t.mu.Unlock() })
		t.mu.Lock()
		if ctx.Err() != nil {
			t.Status = "cancelled"
		} else if err != nil {
			t.Status = "error"
			t.Error = trimSpace(err.Error(), 320)
		} else {
			t.Status = "completed"
		}
		t.Finished = time.Now()
		t.mu.Unlock()
		if err == nil {
			s.store.log("sftp_"+kind, p.Name+" — "+path.Base(remote), "success")
		}
	}()
	jsonOut(w, 202, map[string]any{"transferId": t.ID})
}
func (s *Server) performSFTP(ctx context.Context, p Profile, kind, remote, local, password string) error {
	return s.nativeTransfer(ctx, p, kind, remote, local, password, false, nil)
}
func (s *Server) transfersEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	s.mu.Lock()
	items := []map[string]any{}
	for _, t := range s.transfers {
		t.mu.Lock()
		items = append(items, map[string]any{"id": t.ID, "kind": t.Kind, "source": t.Source, "destination": t.Destination, "status": t.Status, "error": t.Error, "started": t.Started, "serverId": t.ServerID, "bytes": t.Bytes, "total": t.Total})
		t.mu.Unlock()
	}
	s.mu.Unlock()
	sort.Slice(items, func(i, j int) bool { return items[i]["started"].(time.Time).After(items[j]["started"].(time.Time)) })
	jsonOut(w, 200, map[string]any{"transfers": items})
}
func (s *Server) cancelTransfer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	s.mu.Lock()
	t := s.transfers[a.ID]
	s.mu.Unlock()
	if t == nil {
		fail(w, 404, "Transfer not found")
		return
	}
	t.cancel()
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func safeFileID(s string) bool { return len(s) == 16 && !strings.ContainsAny(s, "./\\") }
