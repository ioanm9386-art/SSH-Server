//go:build !windows

package main

import (
	"context"
	"errors"
)

func pickWindowsPath(ctx context.Context, kind, initial string) (string, error) {
	return "", errors.New("selectorul nativ este disponibil numai pe Windows")
}
