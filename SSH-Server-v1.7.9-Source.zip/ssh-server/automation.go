package main

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// Jobs run with the SSH user's permissions, never with a stored sudo password.
type Automation struct {
	ID       string    `json:"id"`
	ServerID string    `json:"serverId"`
	Name     string    `json:"name"`
	Kind     string    `json:"kind"`
	Command  string    `json:"command,omitempty"`
	Interval int       `json:"interval"`
	Enabled  bool      `json:"enabled"`
	NextRun  time.Time `json:"nextRun"`
	LastRun  time.Time `json:"lastRun"`
	Status   string    `json:"status"`
	Output   string    `json:"output,omitempty"`
}
type automationRequest struct {
	Automation
	OwnerPassword string `json:"ownerPassword"`
	Code          string `json:"code"`
}

func automationCommand(a Automation) (string, error) {
	switch a.Kind {
	case "disk":
		return "LC_ALL=C df -hT", nil
	case "services":
		return "systemctl --failed --no-pager", nil
	case "containers":
		return "docker ps --format '{{.Names}}\\t{{.Status}}\\t{{.Image}}'", nil
	case "custom":
		if strings.TrimSpace(a.Command) != "" && len(a.Command) <= 8192 && !strings.ContainsRune(a.Command, 0) {
			return a.Command, nil
		}
	}
	return "", fmt.Errorf("Invalid task command")
}
func (s *Server) automationsEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		jobs := s.store.snapshot().Automations
		if jobs == nil {
			jobs = []Automation{}
		}
		s.automationMu.Lock()
		running := map[string]bool{}
		for k, v := range s.automationRunning {
			running[k] = v
		}
		s.automationMu.Unlock()
		jsonOut(w, 200, map[string]any{"tasks": jobs, "running": running})
		return
	}
	if r.Method != "POST" && r.Method != "DELETE" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a automationRequest
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	if !ownerVerified(s.store.snapshot().Owner, a.OwnerPassword, a.Code) {
		fail(w, 403, "Owner confirmation required")
		return
	}
	if r.Method == "POST" {
		if _, ok := s.findProfile(a.ServerID); !ok {
			fail(w, 404, "Server not found")
			return
		}
		if _, err := automationCommand(a.Automation); err != nil || len(strings.TrimSpace(a.Name)) == 0 || len(a.Name) > 120 || a.Interval < 60 || a.Interval > 604800 {
			fail(w, 400, "Invalid task; interval must be 60–604800 seconds")
			return
		}
	}
	s.automationMu.Lock()
	defer s.automationMu.Unlock()
	if s.automationRunning[a.ID] {
		fail(w, 409, "Wait for the running task to finish")
		return
	}
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	jobs := append([]Automation(nil), s.store.data.Automations...)
	index := -1
	for i, t := range jobs {
		if t.ID == a.ID {
			index = i
			break
		}
	}
	if r.Method == "DELETE" {
		if index < 0 {
			fail(w, 404, "Task not found")
			return
		}
		jobs = append(jobs[:index], jobs[index+1:]...)
	} else {
		if a.ID != "" && index < 0 {
			fail(w, 404, "Task not found")
			return
		}
		if a.ID == "" {
			if len(jobs) >= 100 {
				fail(w, 400, "Task limit reached")
				return
			}
			a.ID = randHex(8)
		}
		a.Name = strings.TrimSpace(a.Name)
		a.Status = "idle"
		a.Output = ""
		a.LastRun = time.Time{}
		a.NextRun = time.Now().Add(time.Duration(a.Interval) * time.Second)
		if a.Kind != "custom" {
			a.Command = ""
		}
		if index < 0 {
			jobs = append(jobs, a.Automation)
		} else {
			jobs[index] = a.Automation
		}
	}
	old := s.store.data.Automations
	s.store.data.Automations = jobs
	if err := s.store.saveLocked(); err != nil {
		s.store.data.Automations = old
		fail(w, 500, "Could not save tasks")
		return
	}
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) automationRunEndpoint(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a automationRequest
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	if !ownerVerified(s.store.snapshot().Owner, a.OwnerPassword, a.Code) {
		fail(w, 403, "Owner confirmation required")
		return
	}
	var task *Automation
	for _, t := range s.store.snapshot().Automations {
		if t.ID == a.ID {
			copy := t
			task = &copy
			break
		}
	}
	if task == nil {
		fail(w, 404, "Task not found")
		return
	}
	if !s.reserveAutomation(task.ID) {
		fail(w, 409, "Task running or worker limit reached")
		return
	}
	go s.executeAutomation(context.Background(), *task)
	jsonOut(w, 202, map[string]bool{"ok": true})
}
func (s *Server) reserveAutomation(id string) bool {
	s.automationMu.Lock()
	defer s.automationMu.Unlock()
	if s.automationRunning == nil {
		s.automationRunning = map[string]bool{}
	}
	if s.automationRunning[id] || len(s.automationRunning) >= 2 {
		return false
	}
	s.automationRunning[id] = true
	return true
}
func (s *Server) executeAutomation(parent context.Context, a Automation) {
	defer func() { s.automationMu.Lock(); delete(s.automationRunning, a.ID); s.automationMu.Unlock() }()
	ctx, cancel := context.WithTimeout(parent, 60*time.Second)
	defer cancel()
	status, output := "success", ""
	p, ok := s.findProfile(a.ServerID)
	if !ok {
		status = "error"
		output = "Server no longer exists"
	} else if p.Auth == "password" && s.sshCredential(p, "") == "" {
		status = "locked"
		output = "Unlock this SSH server to run tasks"
	} else {
		command, e := automationCommand(a)
		if e == nil {
			var out []byte
			out, e = s.runNative(ctx, p, "", command, "")
			output = string(out)
		}
		if e != nil {
			status = "error"
			output += "\n" + e.Error()
		}
	}
	if len(output) > 16000 {
		output = output[:16000] + "\n[output truncated]"
	}
	s.store.mu.Lock()
	for i, t := range s.store.data.Automations {
		if t.ID == a.ID {
			s.store.data.Automations[i].Status = status
			s.store.data.Automations[i].Output = output
			s.store.data.Automations[i].LastRun = time.Now()
			s.store.data.Automations[i].NextRun = time.Now().Add(time.Duration(a.Interval) * time.Second)
		}
	}
	err := s.store.saveLocked()
	s.store.mu.Unlock()
	if err != nil {
		s.store.log("automation_save_error", a.Name, "warning")
	}
	level := "success"
	if status != "success" {
		level = "warning"
	}
	s.store.log("automation_"+status, a.Name, level)
}
func (s *Server) automationScheduler(ctx context.Context) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case now := <-ticker.C:
			for _, a := range s.store.snapshot().Automations {
				if !a.Enabled || a.NextRun.IsZero() || now.Before(a.NextRun) {
					continue
				}
				// Missing credentials do not trigger repeated dialogs or failed command floods.
				p, ok := s.findProfile(a.ServerID)
				if !ok || len(p.HostKeys) == 0 || (p.Auth == "password" && s.sshCredential(p, "") == "") {
					continue
				}
				if s.reserveAutomation(a.ID) {
					go s.executeAutomation(ctx, a)
				}
			}
		}
	}
}
