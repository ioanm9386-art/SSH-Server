//go:build windows

package main

import "golang.org/x/sys/windows"

func commitDownload(temp, dest string, overwrite bool) error {
	from, e := windows.UTF16PtrFromString(temp)
	if e != nil {
		return e
	}
	to, e := windows.UTF16PtrFromString(dest)
	if e != nil {
		return e
	}
	var flags uint32
	if overwrite {
		flags = windows.MOVEFILE_REPLACE_EXISTING
	}
	return windows.MoveFileEx(from, to, flags)
}
