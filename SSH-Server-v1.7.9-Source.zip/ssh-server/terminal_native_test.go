package main

import (
	"context"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"errors"
	"golang.org/x/crypto/ssh"
	"io"
	"net"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestNativeTerminalAuthenticatesRequestsPTYAndResizes(t *testing.T) {
	_, key, e := ed25519.GenerateKey(rand.Reader)
	if e != nil {
		t.Fatal(e)
	}
	signer, e := ssh.NewSignerFromKey(key)
	if e != nil {
		t.Fatal(e)
	}
	cfg := &ssh.ServerConfig{PasswordCallback: func(_ ssh.ConnMetadata, password []byte) (*ssh.Permissions, error) {
		if string(password) != "test-only-password" {
			return nil, errors.New("wrong password")
		}
		return nil, nil
	}}
	otherKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	otherSigner, err := ssh.NewSignerFromKey(otherKey)
	if err != nil {
		t.Fatal(err)
	}
	cfg.AddHostKey(otherSigner)
	cfg.AddHostKey(signer)
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	defer ln.Close()
	pty := make(chan string, 1)
	resize := make(chan [2]uint32, 1)
	input := make(chan string, 1)
	go func() {
		conn, err := ln.Accept()
		if err != nil {
			return
		}
		defer conn.Close()
		server, channels, requests, err := ssh.NewServerConn(conn, cfg)
		if err != nil {
			return
		}
		defer server.Close()
		go ssh.DiscardRequests(requests)
		for c := range channels {
			channel, reqs, err := c.Accept()
			if err != nil {
				return
			}
			for req := range reqs {
				switch req.Type {
				case "pty-req":
					var msg struct {
						Term                      string
						Cols, Rows, Width, Height uint32
						Modes                     string
					}
					if ssh.Unmarshal(req.Payload, &msg) == nil {
						pty <- msg.Term
					}
					_ = req.Reply(true, nil)
				case "shell":
					_ = req.Reply(true, nil)
					_, _ = channel.Write([]byte("\x1b[32mREADY\x1b[0m\r\nabc\b \b"))
					go func() { b := make([]byte, 200); n, _ := channel.Read(b); input <- string(b[:n]) }()
				case "window-change":
					var msg struct{ Cols, Rows, Width, Height uint32 }
					if ssh.Unmarshal(req.Payload, &msg) == nil {
						resize <- [2]uint32{msg.Rows, msg.Cols}
					}
				default:
					_ = req.Reply(false, nil)
				}
			}
		}
	}()
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	number, _ := strconv.Atoi(port)
	p := Profile{ID: "native", Host: "127.0.0.1", Port: number, User: "qa", Auth: "password", HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}}
	st, e := openStore(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	s := &Server{store: st}
	s.sshCredential(p, "test-only-password")
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	session, e := s.openTerminal(ctx, p, "")
	if e != nil {
		t.Fatal(e)
	}
	defer session.closeTransport()
	select {
	case term := <-pty:
		if term != "xterm-256color" {
			t.Fatal(term)
		}
	case <-ctx.Done():
		t.Fatal("no PTY requested")
	}
	if e = session.NativeShell.WindowChange(44, 132); e != nil {
		t.Fatal(e)
	}
	select {
	case dimensions := <-resize:
		if dimensions != [2]uint32{44, 132} {
			t.Fatal(dimensions)
		}
	case <-ctx.Done():
		t.Fatal("no terminal resize request")
	}
	_, _ = io.WriteString(session.Stdin, "typo\x7f\x7fOK\r")
	select {
	case got := <-input:
		if got != "typo\x7f\x7fOK\r" {
			t.Fatal("terminal control bytes changed", got)
		}
	case <-ctx.Done():
		t.Fatal("terminal input not received")
	}
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		session.mu.Lock()
		out := session.buffer
		session.mu.Unlock()
		if strings.Contains(out, "\x1b[32mREADY") && strings.Contains(out, "abc\b \b") {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatal("ANSI/backspace output was stripped")
}
