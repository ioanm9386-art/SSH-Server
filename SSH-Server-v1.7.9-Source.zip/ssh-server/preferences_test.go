package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultEnglish(t *testing.T) {
	s, e := openStore(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	if s.data.Settings.Language != "en" {
		t.Fatal("new installations must default to English")
	}
}
func TestInstallLanguagePreservesOwnerAndServers(t *testing.T) {
	dir := t.TempDir()
	initial := Data{Schema: 1, Owner: &Owner{Name: "Existing Owner", PasswordHash: "unchanged"}, Settings: AppSettings{Language: "ro"}, Profiles: []Profile{{ID: "1", Name: "Nebula"}}}
	b, _ := json.Marshal(initial)
	os.WriteFile(filepath.Join(dir, "data.json"), b, 0600)
	choice := filepath.Join(dir, "install-language.json")
	os.WriteFile(choice, []byte(`{"language":"en"}`), 0600)
	s, e := openStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	if s.data.Settings.Language != "en" || s.data.Owner.PasswordHash != "unchanged" || s.data.Profiles[0].Name != "Nebula" {
		t.Fatal("owner or server data lost during language selection")
	}
	if _, e = os.Stat(choice); !os.IsNotExist(e) {
		t.Fatal("installer preference must be consumed once")
	}
	s.data.Settings.Language = "ro"
	s.saveLocked()
	s, e = openStore(dir)
	if e != nil || s.data.Settings.Language != "ro" {
		t.Fatal("later application language preferences must persist")
	}
}
