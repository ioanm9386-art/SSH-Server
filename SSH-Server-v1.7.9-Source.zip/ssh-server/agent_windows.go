//go:build windows

package main

import (
	"io"
	"os"
)

func openSSHAgent() (io.ReadWriteCloser, error) {
	return os.OpenFile(`\\.\pipe\openssh-ssh-agent`, os.O_RDWR, 0)
}
