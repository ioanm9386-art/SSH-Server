package main

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestLiveCamAcceptsProtocolsNotBrandsAndRedactsCredentials(t *testing.T) {
	for _, raw := range []string{"rtsp://user:private@192.168.1.50:554/channel1?token=hidden", "rtsps://camera.test/feed", "https://nvr.test/channel", "http://xvr.test/video"} {
		if _, e := validateCameraURL(raw); e != nil {
			t.Fatal(e)
		}
	}
	for _, raw := range []string{"file:///etc/passwd", "pipe:0", "concat:http://one|file:/secret", "rtsp://host/feed\n-i file:/secret"} {
		if _, e := validateCameraURL(raw); e == nil {
			t.Fatal("accepted unsafe source: " + raw)
		}
	}
	clean := safeSource("rtsp://user:private@192.168.1.50:554/channel1?token=hidden")
	if strings.Contains(clean, "private") || strings.Contains(clean, "user") || strings.Contains(clean, "hidden") {
		t.Fatal(clean)
	}
}
func TestLiveCamPersistsEncryptedSourceWithoutExposingIt(t *testing.T) {
	st, e := openStore(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	s := &Server{store: st}
	raw := `{"name":"Camera Beta","kind":"nvr","channel":"1","source":"rtsp://owner:camera-password@camera.test/channel1?token=secret"}`
	w := httptest.NewRecorder()
	s.liveCameras(w, httptest.NewRequest("POST", "/api/livecam", strings.NewReader(raw)))
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	persisted, _ := os.ReadFile(st.path)
	if bytes.Contains(persisted, []byte("camera-password")) || bytes.Contains(persisted, []byte("rtsp://")) {
		t.Fatal("camera secret saved in plaintext")
	}
	w = httptest.NewRecorder()
	s.liveCameras(w, httptest.NewRequest("GET", "/api/livecam", nil))
	if strings.Contains(w.Body.String(), "camera-password") || strings.Contains(w.Body.String(), "sourceSecret") || strings.Contains(w.Body.String(), "token=secret") {
		t.Fatal("secret returned by API")
	}
	reopened, e := openStore(st.dir)
	if e != nil || len(reopened.data.Cameras) != 1 {
		t.Fatal("camera migration failed", e)
	}
	var body map[string]any
	if e = json.Unmarshal(w.Body.Bytes(), &body); e != nil || body["beta"] != true {
		t.Fatal("missing beta status")
	}
}
func TestCameraRecordingRequiresExplicitConfirmation(t *testing.T) {
	s := &Server{}
	w := httptest.NewRecorder()
	s.cameraRecord(w, httptest.NewRequest("POST", "/api/livecam/record", strings.NewReader(`{"id":"x","confirmed":false}`)))
	if w.Code != 400 {
		t.Fatal(w.Code)
	}
}
func TestCameraSourceIsNotInterpolatedAsRemoteShellCode(t *testing.T) {
	source := "rtsp://user:p'$(touch /tmp/injected)@cam.test/channel"
	cmd := remoteRecordingCommand(source, "/home/owner/video archive", "abc123")
	if !strings.Contains(cmd, shellQuote(source)) || !strings.Contains(cmd, shellQuote("/home/owner/video archive")) || !strings.Contains(cmd, "read -r stop") {
		t.Fatal("unsafe remote command")
	}
}
func TestLiveCamProducesRealMJPEGFromHTTPVideo(t *testing.T) {
	binary, e := exec.LookPath("ffmpeg")
	if e != nil {
		t.Skip("FFmpeg not installed")
	}
	dir := t.TempDir()
	sample := filepath.Join(dir, "sample.mp4")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	out, e := exec.CommandContext(ctx, binary, "-v", "error", "-f", "lavfi", "-i", "color=c=blue:s=160x120:r=4", "-t", "1", "-c:v", "mpeg4", sample).CombinedOutput()
	if e != nil {
		t.Fatal(e, string(out))
	}
	data, e := os.ReadFile(sample)
	if e != nil {
		t.Fatal(e)
	}
	source := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "video/mp4")
		_, _ = w.Write(data)
	}))
	defer source.Close()
	secret, e := encryptSecret(source.URL + "/sample.mp4")
	if e != nil {
		t.Fatal(e)
	}
	st, e := openStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	st.data.Cameras = []LiveCamera{{ID: "testcam", Name: "test", Secret: secret}}
	st.data.Settings.FFmpegPath = binary
	s := &Server{store: st}
	w := httptest.NewRecorder()
	s.cameraStream(w, httptest.NewRequest("GET", "/api/livecam/stream?id=testcam", nil).WithContext(ctx))
	if w.Code != 200 || !strings.Contains(w.Header().Get("Content-Type"), "multipart/x-mixed-replace") || !bytes.Contains(w.Body.Bytes(), []byte{0xff, 0xd8}) {
		t.Fatalf("not a real JPEG stream: %d, %s", w.Code, w.Header())
	}
}

func TestCameraRecordingWritesPlayableVideoSegments(t *testing.T) {
	binary, e := exec.LookPath("ffmpeg")
	if e != nil {
		t.Skip("FFmpeg not installed")
	}
	dir := t.TempDir()
	sample := filepath.Join(dir, "sample.mp4")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if out, e := exec.CommandContext(ctx, binary, "-v", "error", "-f", "lavfi", "-i", "color=c=green:s=160x120:r=4", "-t", "1", "-c:v", "mpeg4", sample).CombinedOutput(); e != nil {
		t.Fatal(e, string(out))
	}
	data, e := os.ReadFile(sample)
	if e != nil {
		t.Fatal(e)
	}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "video/mp4")
		_, _ = w.Write(data)
	}))
	defer server.Close()
	secret, e := encryptSecret(server.URL + "/sample.mp4")
	if e != nil {
		t.Fatal(e)
	}
	st, e := openStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	st.data.Settings.FFmpegPath = binary
	st.data.Cameras = []LiveCamera{{ID: "record-test", Name: "test", Secret: secret}}
	s := &Server{store: st}
	destination := filepath.Join(dir, "recordings with spaces")
	request := `{"id":"record-test","directory":` + strconvQuote(destination) + `,"confirmed":true}`
	w := httptest.NewRecorder()
	s.cameraRecord(w, httptest.NewRequest("POST", "/api/livecam/record", strings.NewReader(request)))
	if w.Code != 202 {
		t.Fatal(w.Code, w.Body.String())
	}
	s.camerasMu.Lock()
	job := s.cameraJobs["record-test"]
	s.camerasMu.Unlock()
	select {
	case <-job.done:
	case <-ctx.Done():
		job.cancel()
		t.Fatal("recording did not finish")
	}
	files, e := filepath.Glob(filepath.Join(destination, "*.mkv"))
	if e != nil || len(files) != 1 {
		t.Fatal("no recording", e, files)
	}
	if out, e := exec.CommandContext(ctx, binary, "-v", "error", "-i", files[0], "-f", "null", "-").CombinedOutput(); e != nil {
		t.Fatal("recording is not decodable", e, string(out))
	}
}
func strconvQuote(v string) string { b, _ := json.Marshal(v); return string(b) }
