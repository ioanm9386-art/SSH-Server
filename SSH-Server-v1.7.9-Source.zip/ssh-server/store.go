package main

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base32"
	"encoding/base64"
	"encoding/binary"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Owner struct {
	Name           string   `json:"name"`
	Salt           string   `json:"salt"`
	PasswordHash   string   `json:"passwordHash"`
	TOTPSecret     string   `json:"totpSecret,omitempty"`
	TOTPEnabled    bool     `json:"totpEnabled"`
	RecoveryHashes []string `json:"recoveryHashes,omitempty"`
}
type AccessEndpoint struct {
	Name string `json:"name"`
	Host string `json:"host"`
	Port int    `json:"port"`
}
type Profile struct {
	FileBookmarks  []string            `json:"fileBookmarks,omitempty"`
	AgentInstalled bool                `json:"agentInstalled,omitempty"`
	Access         []AccessEndpoint    `json:"access,omitempty"`
	EndpointKeys   map[string][]string `json:"endpointKeys,omitempty"`
	StartDirectory string              `json:"startDirectory,omitempty"`
	ID             string              `json:"id"`
	Name           string              `json:"name"`
	Host           string              `json:"host"`
	Port           int                 `json:"port"`
	User           string              `json:"user"`
	Auth           string              `json:"auth"`
	KeyPath        string              `json:"keyPath,omitempty"`
	Group          string              `json:"group,omitempty"`
	Tags           []string            `json:"tags,omitempty"`
	Favorite       bool                `json:"favorite"`
	Description    string              `json:"description,omitempty"`
	HostKeys       []string            `json:"hostKeys,omitempty"`
	Added          time.Time           `json:"added"`
}
type JournalEntry struct {
	At     time.Time `json:"at"`
	Action string    `json:"action"`
	Detail string    `json:"detail"`
	Level  string    `json:"level"`
}
type AppSettings struct {
	FFmpegPath    string `json:"ffmpegPath,omitempty"`
	Language      string `json:"language"`
	Notifications bool   `json:"notifications"`
	Instance      string `json:"instance"`
}
type Metric struct {
	ServerID  string    `json:"serverId"`
	At        time.Time `json:"at"`
	CPU       float64   `json:"cpu"`
	RAM       float64   `json:"ram"`
	Disk      float64   `json:"disk"`
	Rx        uint64    `json:"rx"`
	Tx        uint64    `json:"tx"`
	Uptime    float64   `json:"uptime"`
	Processes int       `json:"processes"`
}
type Data struct {
	CameraArchives []ArchiveLocation         `json:"cameraArchives,omitempty"`
	EnergyConfigs  map[string]EnergyConfig   `json:"energyConfigs,omitempty"`
	EnergyHistory  map[string][]EnergySample `json:"energyHistory,omitempty"`
	Automations    []Automation              `json:"automations,omitempty"`
	Cameras        []LiveCamera              `json:"cameras"`
	Owner          *Owner                    `json:"owner"`
	Profiles       []Profile                 `json:"profiles"`
	Logs           []JournalEntry            `json:"logs"`
	Settings       AppSettings               `json:"settings"`
	History        map[string][]Metric       `json:"history"`
	Schema         int                       `json:"schema"`
}
type Store struct {
	mu          sync.Mutex
	path        string
	dir         string
	data        Data
	pendingTOTP string
}

func openStore(dir string) (*Store, error) {
	s := &Store{path: filepath.Join(dir, "data.json"), dir: dir}
	b, err := os.ReadFile(s.path)
	if err == nil {
		if e := json.Unmarshal(b, &s.data); e != nil {
			return nil, fmt.Errorf("Datele locale sunt corupte; nu le suprascriem: %w", e)
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	if s.data.Profiles == nil {
		s.data.Profiles = []Profile{}
	}
	if s.data.Logs == nil {
		s.data.Logs = []JournalEntry{}
	}
	if s.data.History == nil {
		s.data.History = map[string][]Metric{}
	}
	if s.data.Settings.Language == "" {
		s.data.Settings.Language = "en"
	}
	// Installer writes a one-time language choice without modifying Owner credentials.
	choicePath := filepath.Join(dir, "install-language.json")
	if raw, e := os.ReadFile(choicePath); e == nil {
		var choice struct {
			Language string `json:"language"`
		}
		if json.Unmarshal(raw, &choice) == nil && (choice.Language == "en" || choice.Language == "ro") {
			s.data.Settings.Language = choice.Language
			if err := s.saveLocked(); err != nil {
				return nil, err
			}
			_ = os.Remove(choicePath)
		}
	}
	if s.data.Schema == 0 {
		s.data.Schema = 1
	}
	return s, nil
}
func (s *Store) snapshot() Data {
	s.mu.Lock()
	defer s.mu.Unlock()
	b, _ := json.Marshal(s.data)
	var d Data
	_ = json.Unmarshal(b, &d)
	return d
}
func (s *Store) saveLocked() error {
	b, e := json.MarshalIndent(s.data, "", "  ")
	if e != nil {
		return e
	}
	tmp := s.path + ".tmp"
	if e = os.WriteFile(tmp, b, 0600); e != nil {
		return e
	}
	return os.Rename(tmp, s.path)
}
func (s *Store) log(action, detail, level string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.data.Logs) > 2500 {
		s.data.Logs = s.data.Logs[len(s.data.Logs)-2000:]
	}
	s.data.Logs = append(s.data.Logs, JournalEntry{At: time.Now(), Action: action, Detail: trimSpace(detail, 240), Level: level})
	_ = s.saveLocked()
}
func kdf(password string, salt []byte) []byte { // PBKDF2-HMAC-SHA256, 210k iterations, 32 bytes.
	const iterations = 210000
	mac := hmac.New(sha256.New, []byte(password))
	mac.Write(salt)
	var block [4]byte
	binary.BigEndian.PutUint32(block[:], 1)
	mac.Write(block[:])
	u := mac.Sum(nil)
	result := append([]byte{}, u...)
	for i := 1; i < iterations; i++ {
		mac = hmac.New(sha256.New, []byte(password))
		mac.Write(u)
		u = mac.Sum(nil)
		for j := range result {
			result[j] ^= u[j]
		}
	}
	return result
}
func makeOwner(name, password string) (*Owner, error) {
	if len([]rune(password)) < 14 || len(password) > 512 {
		return nil, fmt.Errorf("Parola trebuie să aibă cel puțin 14 caractere (maximum 512).")
	}
	if trimSpace(name, 70) == "" {
		name = "Owner"
	}
	salt := make([]byte, 16)
	_, _ = rand.Read(salt)
	return &Owner{Name: trimSpace(name, 70), Salt: base64.StdEncoding.EncodeToString(salt), PasswordHash: base64.StdEncoding.EncodeToString(kdf(password, salt))}, nil
}
func checkPassword(owner *Owner, password string) bool {
	if owner == nil {
		return false
	}
	salt, e := base64.StdEncoding.DecodeString(owner.Salt)
	if e != nil {
		return false
	}
	hash, e := base64.StdEncoding.DecodeString(owner.PasswordHash)
	if e != nil {
		return false
	}
	return subtle.ConstantTimeCompare(hash, kdf(password, salt)) == 1
}
func totpCode(secret string, t time.Time) string {
	raw, e := base32.StdEncoding.WithPadding(base32.NoPadding).DecodeString(strings.ToUpper(strings.ReplaceAll(secret, " ", "")))
	if e != nil {
		return ""
	}
	key := uint64(t.Unix() / 30)
	var msg [8]byte
	binary.BigEndian.PutUint64(msg[:], key)
	h := hmac.New(sha1.New, raw)
	_, _ = h.Write(msg[:])
	hash := h.Sum(nil)
	o := int(hash[len(hash)-1] & 15)
	n := binary.BigEndian.Uint32(hash[o:o+4]) & 0x7fffffff
	return fmt.Sprintf("%06d", n%1000000)
}
func totpValid(secret, code string) bool {
	if len(code) != 6 {
		return false
	}
	for _, r := range code {
		if r < '0' || r > '9' {
			return false
		}
	}
	for i := -1; i <= 1; i++ {
		if subtle.ConstantTimeCompare([]byte(totpCode(secret, time.Now().Add(time.Duration(i)*30*time.Second))), []byte(code)) == 1 {
			return true
		}
	}
	return false
}
func ownerVerified(owner *Owner, password, totp string) bool {
	if !checkPassword(owner, password) {
		return false
	}
	if owner.TOTPEnabled {
		sec, e := decryptSecret(owner.TOTPSecret)
		if e != nil || !totpValid(sec, totp) {
			return false
		}
	}
	return true
}
func (s *Server) setup(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Name, Password string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	o, e := makeOwner(a.Name, a.Password)
	if e != nil {
		fail(w, 400, e.Error())
		return
	}
	s.store.mu.Lock()
	if s.store.data.Owner != nil {
		s.store.mu.Unlock()
		fail(w, 409, "Owner este deja configurat.")
		return
	}
	s.store.data.Owner = o
	e = s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Nu am putut salva configurarea.")
		return
	}
	s.store.log("owner_setup", "Profil Owner inițializat local", "success")
	s.makeAutomaticBackup()
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) verifyOwner(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Password, TOTP string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	d := s.store.snapshot()
	if !ownerVerified(d.Owner, a.Password, a.TOTP) {
		fail(w, 403, "Parola sau codul TOTP nu sunt corecte.")
		return
	}
	jsonOut(w, 200, map[string]bool{"ok": true})
}

var hostRx = regexp.MustCompile(`^[a-zA-Z0-9_.:\-]+$`)

func validHost(h string) bool {
	if len(h) == 0 || len(h) > 250 {
		return false
	}
	if strings.HasPrefix(h, "-") || strings.Contains(h, "..") {
		return false
	}
	return hostRx.MatchString(h)
}
func (s *Server) profiles(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
		jsonOut(w, 200, map[string]any{"profiles": s.store.snapshot().Profiles})
	case "POST", "PUT":
		var a Profile
		if body(r, &a) != nil {
			fail(w, 400, "Date invalide.")
			return
		}
		if len(a.FileBookmarks) > 20 {
			fail(w, 400, "Maximum 20 bookmarked folders")
			return
		}
		for _, bookmark := range a.FileBookmarks {
			if !safeRemote(bookmark) || !strings.HasPrefix(bookmark, "/") {
				fail(w, 400, "Invalid bookmarked directory")
				return
			}
		}
		if len(a.Access) > 3 {
			fail(w, 400, "Maximum three access addresses")
			return
		}
		for _, ep := range a.Access {
			if !validHost(ep.Host) || ep.Port < 1 || ep.Port > 65535 || (ep.Name != "lan" && ep.Name != "vpn" && ep.Name != "external") {
				fail(w, 400, "Invalid access address")
				return
			}
		}
		a.Name = trimSpace(a.Name, 72)
		a.Host = trimSpace(a.Host, 250)
		a.User = trimSpace(a.User, 70)
		a.Group = trimSpace(a.Group, 45)
		a.Description = trimSpace(a.Description, 500)
		if a.StartDirectory != "" && (!safeRemote(a.StartDirectory) || !strings.HasPrefix(a.StartDirectory, "/")) {
			fail(w, 400, "Select an absolute remote starting directory")
			return
		}
		if a.Name == "" || !validHost(a.Host) || a.User == "" || a.Port < 1 || a.Port > 65535 || strings.HasPrefix(a.User, "-") {
			fail(w, 400, "Verifică numele, gazda, portul și utilizatorul SSH.")
			return
		}
		if a.Auth != "password" && a.Auth != "key" && a.Auth != "agent" {
			a.Auth = "agent"
		}
		if a.Auth == "key" && strings.TrimSpace(a.KeyPath) == "" {
			fail(w, 400, "Selectează calea către cheia privată SSH.")
			return
		}
		if len(a.Tags) > 10 {
			a.Tags = a.Tags[:10]
		}
		for i := range a.Tags {
			a.Tags[i] = trimSpace(a.Tags[i], 24)
		}
		s.store.mu.Lock()
		found := -1
		for i, p := range s.store.data.Profiles {
			if p.ID == a.ID && a.ID != "" {
				found = i
				break
			}
		}
		action := "server_added"
		if found >= 0 {
			previous := s.store.data.Profiles[found]
			a.Added = previous.Added
			a.EndpointKeys = previous.EndpointKeys
			if a.EndpointKeys == nil {
				a.EndpointKeys = map[string][]string{}
			}
			if len(previous.HostKeys) > 0 {
				a.EndpointKeys[previous.Host+":"+strconv.Itoa(previous.Port)] = previous.HostKeys
			}
			if previous.Host == a.Host && previous.Port == a.Port {
				a.HostKeys = previous.HostKeys
			} else {
				a.HostKeys = a.EndpointKeys[a.Host+":"+strconv.Itoa(a.Port)]
			}
			s.store.data.Profiles[found] = a
			action = "server_updated"
		} else {
			if len(s.store.data.Profiles) >= 250 {
				s.store.mu.Unlock()
				fail(w, 400, "Limită locală de servere atinsă.")
				return
			}
			a.EndpointKeys = nil
			a.ID = randHex(8)
			a.Added = time.Now()
			a.HostKeys = nil
			s.store.data.Profiles = append(s.store.data.Profiles, a)
		}
		e := s.store.saveLocked()
		s.store.mu.Unlock()
		if e != nil {
			fail(w, 500, "Eroare la salvare.")
			return
		}
		s.store.log(action, a.Name, "info")
		jsonOut(w, 200, map[string]any{"ok": true, "profile": a})
	case "DELETE":
		id := r.URL.Query().Get("id")
		s.store.mu.Lock()
		removed := ""
		newP := []Profile{}
		for _, p := range s.store.data.Profiles {
			if p.ID == id {
				removed = p.Name
			} else {
				newP = append(newP, p)
			}
		}
		s.store.data.Profiles = newP
		e := s.store.saveLocked()
		s.store.mu.Unlock()
		if removed == "" {
			fail(w, 404, "Serverul nu a fost găsit.")
			return
		}
		if e != nil {
			fail(w, 500, "Eroare la salvare.")
			return
		}
		s.store.log("server_removed", removed, "warning")
		jsonOut(w, 200, map[string]bool{"ok": true})
	default:
		fail(w, 405, "Metodă invalidă.")
	}
}
func (s *Server) findProfile(id string) (Profile, bool) {
	d := s.store.snapshot()
	for _, p := range d.Profiles {
		if p.ID == id {
			return p, true
		}
	}
	return Profile{}, false
}
func (s *Server) journal(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	d := s.store.snapshot()
	entries, err := filterJournal(d.Logs, r.URL.Query())
	if err != nil {
		fail(w, 400, err.Error())
		return
	}
	jsonOut(w, 200, map[string]any{"entries": entries})
}
func (s *Server) exportJournal(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	entries, err := filterJournal(s.store.snapshot().Logs, r.URL.Query())
	if err != nil {
		fail(w, 400, err.Error())
		return
	}
	w.Header().Set("Content-Type", "text/csv; charset=utf-8")
	w.Header().Set("Content-Disposition", "attachment; filename=ssh-server-jurnal.csv")
	c := csv.NewWriter(w)
	_ = c.Write([]string{"Data", "Actiune", "Detalii", "Nivel"})
	for _, a := range entries {
		_ = c.Write([]string{a.At.Format(time.RFC3339), a.Action, a.Detail, a.Level})
	}
	c.Flush()
}
func (s *Server) settings(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		d := s.store.snapshot()
		jsonOut(w, 200, map[string]any{"settings": d.Settings, "owner": ownerName(d), "totpEnabled": d.Owner != nil && d.Owner.TOTPEnabled, "dataDir": s.store.dir})
		return
	}
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a AppSettings
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	if a.Language != "ro" && a.Language != "en" {
		fail(w, 400, "Limba trebuie să fie română sau engleză.")
		return
	}
	s.store.mu.Lock()
	s.store.data.Settings.Language = a.Language
	s.store.data.Settings.Notifications = a.Notifications
	e := s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Eroare la salvare.")
		return
	}
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) totpSetup(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Password string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	d := s.store.snapshot()
	if d.Owner == nil || d.Owner.TOTPEnabled || !checkPassword(d.Owner, a.Password) {
		fail(w, 403, "Confirmarea parolei a eșuat sau TOTP este deja activ.")
		return
	}
	random := make([]byte, 20)
	_, _ = rand.Read(random)
	secret := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(random)
	s.store.mu.Lock()
	s.store.pendingTOTP = secret
	s.store.mu.Unlock()
	jsonOut(w, 200, map[string]any{"secret": secret, "uri": "otpauth://totp/SSH%20Server:" + urlEncode(d.Owner.Name) + "?secret=" + secret + "&issuer=SSH%20Server&algorithm=SHA1&digits=6&period=30"})
}
func urlEncode(s string) string {
	return strings.ReplaceAll(strings.ReplaceAll(s, " ", "%20"), "&", "%26")
}
func (s *Server) totpEnable(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Password, Code string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	o := s.store.data.Owner
	if o == nil || o.TOTPEnabled || !checkPassword(o, a.Password) || !totpValid(s.store.pendingTOTP, a.Code) {
		fail(w, 403, "Parola sau codul de confirmare TOTP sunt invalide.")
		return
	}
	secret, err := encryptSecret(s.store.pendingTOTP)
	if err != nil {
		fail(w, 500, "Criptarea TOTP nu a reușit.")
		return
	}
	o.TOTPSecret = secret
	o.TOTPEnabled = true
	codes := []string{}
	hashes := []string{}
	for i := 0; i < 10; i++ {
		b := make([]byte, 10)
		_, _ = rand.Read(b)
		c := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(b)
		c = c[:8] + "-" + c[8:16]
		codes = append(codes, c)
		h := sha256.Sum256([]byte(c))
		hashes = append(hashes, fmt.Sprintf("%x", h[:]))
	}
	o.RecoveryHashes = hashes
	s.store.pendingTOTP = ""
	if e := s.store.saveLocked(); e != nil {
		fail(w, 500, "Eroare la salvare.")
		return
	}
	jsonOut(w, 200, map[string]any{"ok": true, "recoveryCodes": codes})
}
func (s *Server) totpDisable(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Password, Code string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	s.store.mu.Lock()
	o := s.store.data.Owner
	if o == nil || !ownerVerified(o, a.Password, a.Code) {
		s.store.mu.Unlock()
		fail(w, 403, "Confirmarea a eșuat.")
		return
	}
	o.TOTPEnabled = false
	o.TOTPSecret = ""
	o.RecoveryHashes = nil
	e := s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Eroare la salvare.")
		return
	}
	s.store.log("totp_disabled", "TOTP dezactivat de Owner", "warning")
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) changePassword(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Old, New, Code string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	d := s.store.snapshot()
	if !ownerVerified(d.Owner, a.Old, a.Code) {
		fail(w, 403, "Confirmarea parolei/TOTP a eșuat.")
		return
	}
	newOwner, e := makeOwner(d.Owner.Name, a.New)
	if e != nil {
		fail(w, 400, e.Error())
		return
	}
	s.store.mu.Lock()
	if s.store.data.Owner != nil {
		newOwner.TOTPEnabled = s.store.data.Owner.TOTPEnabled
		newOwner.TOTPSecret = s.store.data.Owner.TOTPSecret
		newOwner.RecoveryHashes = s.store.data.Owner.RecoveryHashes
		s.store.data.Owner = newOwner
	}
	e = s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Eroare la salvare.")
		return
	}
	s.store.log("password_changed", "Parola locală Owner a fost schimbată", "success")
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) makeAutomaticBackup() {
	d := s.store.snapshot()
	if d.Owner == nil {
		return
	}
	backupDir := filepath.Join(s.store.dir, "backups")
	_ = os.MkdirAll(backupDir, 0700)
	f := filepath.Join(backupDir, "ssh-server-auto-"+time.Now().Format("2006-01-02")+".json")
	if !exists(f) {
		_ = copyFile(s.store.path, f)
	}
	list, _ := filepath.Glob(filepath.Join(backupDir, "ssh-server-auto-*.json"))
	sort.Strings(list)
	if len(list) > 10 {
		for _, v := range list[:len(list)-10] {
			_ = os.Remove(v)
		}
	}
}
func (s *Server) backupCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	backupDir := filepath.Join(s.store.dir, "backups")
	_ = os.MkdirAll(backupDir, 0700)
	file := "ssh-server-manual-" + time.Now().Format("20060102-150405") + ".json"
	if e := copyFile(s.store.path, filepath.Join(backupDir, file)); e != nil {
		fail(w, 500, "Backup indisponibil.")
		return
	}
	s.store.log("backup_created", file, "success")
	jsonOut(w, 200, map[string]string{"file": file})
}
func (s *Server) backupList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	files, _ := os.ReadDir(filepath.Join(s.store.dir, "backups"))
	names := []string{}
	for _, f := range files {
		if !f.IsDir() && strings.HasPrefix(f.Name(), "ssh-server-") && strings.HasSuffix(f.Name(), ".json") {
			names = append(names, f.Name())
		}
	}
	sort.Sort(sort.Reverse(sort.StringSlice(names)))
	jsonOut(w, 200, map[string]any{"files": names})
}
func (s *Server) backupRestore(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ File, Password, Code string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	d := s.store.snapshot()
	if !ownerVerified(d.Owner, a.Password, a.Code) {
		fail(w, 403, "Confirmă parola Owner și TOTP.")
		return
	}
	if filepath.Base(a.File) != a.File || !strings.HasPrefix(a.File, "ssh-server-") || !strings.HasSuffix(a.File, ".json") {
		fail(w, 400, "Backup invalid.")
		return
	}
	b, e := os.ReadFile(filepath.Join(s.store.dir, "backups", a.File))
	if e != nil {
		fail(w, 404, "Fișierul de backup nu există.")
		return
	}
	var loaded Data
	if json.Unmarshal(b, &loaded) != nil || loaded.Owner == nil || loaded.Schema != 1 {
		fail(w, 400, "Formatul de backup nu este compatibil.")
		return
	}
	s.store.mu.Lock()
	before := s.store.path + ".pre-restore-" + time.Now().Format("20060102-150405")
	_ = copyFile(s.store.path, before)
	s.store.data = loaded
	e = s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Restaurarea a eșuat.")
		return
	}
	s.store.log("backup_restored", a.File, "warning")
	jsonOut(w, 200, map[string]any{"ok": true, "restartRecommended": true})
}
func (s *Server) monitorHistory(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	d := s.store.snapshot()
	id := r.URL.Query().Get("id")
	jsonOut(w, 200, map[string]any{"samples": d.History[id]})
}
func (s *Server) saveHistory(m Metric) {
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	list := s.store.data.History[m.ServerID]
	if len(list) > 0 && m.At.Sub(list[len(list)-1].At) < time.Minute {
		return
	}
	cutoff := time.Now().Add(-30 * 24 * time.Hour)
	filter := list[:0]
	for _, v := range list {
		if v.At.After(cutoff) {
			filter = append(filter, v)
		}
	}
	filter = append(filter, m)
	s.store.data.History[m.ServerID] = filter
	_ = s.store.saveLocked()
}
func copyReader(dst io.Writer, src io.Reader) { _, _ = io.Copy(dst, src) }
func parseInt(s string) int                   { n, _ := strconv.Atoi(s); return n }

// Recovery codes are single-use. Owner password is also required to disable TOTP.
func (s *Server) totpRecover(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Metodă invalidă.")
		return
	}
	var a struct{ Password, Recovery string }
	if body(r, &a) != nil {
		fail(w, 400, "Date invalide.")
		return
	}
	s.store.mu.Lock()
	o := s.store.data.Owner
	if o == nil || !o.TOTPEnabled || !checkPassword(o, a.Password) {
		s.store.mu.Unlock()
		fail(w, 403, "Confirmare invalidă.")
		return
	}
	hash := sha256.Sum256([]byte(strings.ToUpper(strings.TrimSpace(a.Recovery))))
	found := -1
	for i, h := range o.RecoveryHashes {
		expected, e := hex.DecodeString(h)
		if e == nil && subtle.ConstantTimeCompare(hash[:], expected) == 1 {
			found = i
		}
	}
	if found < 0 {
		s.store.mu.Unlock()
		fail(w, 403, "Cod de recuperare invalid sau deja folosit.")
		return
	}
	o.TOTPEnabled = false
	o.TOTPSecret = ""
	o.RecoveryHashes = nil
	e := s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Nu pot salva restaurarea.")
		return
	}
	s.store.log("totp_recovered", "TOTP dezactivat folosind un cod de recuperare", "warning")
	jsonOut(w, 200, map[string]bool{"ok": true})
}
