//go:build windows

package main

import (
	"context"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"os/exec"
	"strings"
	"unicode/utf16"
)

// PowerShell is launched in STA with a static encoded script, never with a user path
// interpolated as PowerShell code. User input is carried as base64 UTF-8 data.
func pickerScript(kind, initial string) string {
	initial64 := base64.StdEncoding.EncodeToString([]byte(initial))
	return `$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
$initial=[System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('` + initial64 + `'))
$kind='` + kind + `'
$owner=New-Object System.Windows.Forms.Form
$owner.TopMost=$true
$owner.ShowInTaskbar=$false
$owner.StartPosition='CenterScreen'
$owner.Size=New-Object System.Drawing.Size(1,1)
$owner.Opacity=0
$owner.Show()
$owner.Activate()
try {
 if($kind -eq 'folder') {
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description='SSH Server - Select a local folder for transfers'
  $dialog.ShowNewFolderButton=$true
  if([IO.Directory]::Exists($initial)) {$dialog.SelectedPath=$initial}
 } else {
  $dialog=New-Object System.Windows.Forms.OpenFileDialog
  $dialog.Title='SSH Server - Select a private SSH key'
  if($kind -eq 'ffmpeg') {$dialog.Title='LiveCam beta - Select ffmpeg.exe'}
  $dialog.Filter='Toate fisierele (*.*)|*.*'
  $dialog.CheckFileExists=$true
  $dialog.Multiselect=$false
  $dialog.AutoUpgradeEnabled=$true
  if([IO.File]::Exists($initial)) {$dialog.FileName=$initial;$dialog.InitialDirectory=[IO.Path]::GetDirectoryName($initial)}
 }
 try {
  $result=$dialog.ShowDialog($owner)
  $path=''
  if($result -eq [System.Windows.Forms.DialogResult]::OK) {
   if($kind -eq 'folder') {$path=$dialog.SelectedPath} else {$path=$dialog.FileName}
  }
  [Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
  [Console]::Write((ConvertTo-Json -InputObject @{path=$path} -Compress))
 } finally {$dialog.Dispose()}
} finally {$owner.Close();$owner.Dispose()}
`
}
func pickWindowsPath(ctx context.Context, kind, initial string) (string, error) {
	code := utf16.Encode([]rune(pickerScript(kind, initial)))
	buf := make([]byte, len(code)*2)
	for i, r := range code {
		binary.LittleEndian.PutUint16(buf[2*i:], r)
	}
	cmd := exec.CommandContext(ctx, "powershell.exe", "-NoProfile", "-STA", "-NonInteractive", "-WindowStyle", "Hidden", "-EncodedCommand", base64.StdEncoding.EncodeToString(buf))
	hideProcessWindow(cmd)
	output, err := cmd.Output()
	if err != nil {
		if ctx.Err() != nil {
			return "", errors.New("selecția a expirat sau a fost întreruptă")
		}
		return "", errors.New("Windows PowerShell / selectorul de fișiere nu este disponibil")
	}
	var result struct {
		Path string `json:"path"`
	}
	if err = json.Unmarshal([]byte(strings.TrimPrefix(strings.TrimSpace(string(output)), "\ufeff")), &result); err != nil {
		return "", errors.New("răspuns invalid din selector")
	}
	return result.Path, nil
}
