package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"encoding/pem"
	"golang.org/x/crypto/ssh"
	"io"
	"net"
	"net/http/httptest"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func commandFixture174(t *testing.T) (*Server, Profile, <-chan string) {
	t.Helper()
	_, key, _ := ed25519.GenerateKey(rand.Reader)
	signer, _ := ssh.NewSignerFromKey(key)
	cfg := &ssh.ServerConfig{NoClientAuth: true}
	cfg.AddHostKey(signer)
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	var mu sync.Mutex
	var conns []net.Conn
	t.Cleanup(func() {
		ln.Close()
		mu.Lock()
		defer mu.Unlock()
		for _, c := range conns {
			c.Close()
		}
	})
	commands := make(chan string, 50)
	go func() {
		for {
			c, e := ln.Accept()
			if e != nil {
				return
			}
			mu.Lock()
			conns = append(conns, c)
			mu.Unlock()
			go func() {
				defer c.Close()
				_, chs, reqs, e := ssh.NewServerConn(c, cfg)
				if e != nil {
					return
				}
				go ssh.DiscardRequests(reqs)
				for incoming := range chs {
					ch, requests, e := incoming.Accept()
					if e != nil {
						return
					}
					go func() {
						defer ch.Close()
						for req := range requests {
							if req.Type != "exec" {
								req.Reply(false, nil)
								continue
							}
							var msg struct{ Command string }
							ssh.Unmarshal(req.Payload, &msg)
							commands <- msg.Command
							req.Reply(true, nil)
							if msg.Command == sampler {
								io.WriteString(ch, "SAMPLE 1000 200 100 40 1000 250 100 200 1800 12\n")
								time.Sleep(30 * time.Millisecond)
							} else {
								io.WriteString(ch, "actual fixture command result\n")
							}
							ch.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{0}))
							return
						}
					}()
				}
			}()
		}
	}()
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	n, _ := strconv.Atoi(port)
	st, _ := openStore(t.TempDir())
	p := Profile{ID: "native174", Name: "Fixture", Host: "127.0.0.1", Port: n, User: "qa", Auth: "agent", HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}}
	// NoClientAuth still needs a supported auth configuration; use an unencrypted fixture key.
	p.Auth = "key"
	p.KeyPath = t.TempDir() + "/fixture-key"
	raw, _ := ssh.MarshalPrivateKey(key, "")
	if e := writeFixtureKey174(p.KeyPath, raw); e != nil {
		t.Fatal(e)
	}
	st.data.Profiles = []Profile{p}
	s := &Server{store: st, active: map[string]*Metric{}, cpuPrev: map[string][2]uint64{}, monitors: map[string]*Monitor{}}
	return s, p, commands
}
func TestMonitorNativeReconnectAndCancel174(t *testing.T) {
	s, p, commands := commandFixture174(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	m := &Monitor{ID: p.ID, running: true, cancel: cancel}
	s.monitors[p.ID] = m
	done := make(chan struct{})
	go func() { s.runMonitor(ctx, m, p, ""); close(done) }()
	for i := 0; i < 2; i++ {
		select {
		case got := <-commands:
			if got != sampler {
				t.Fatal(got)
			}
		case <-time.After(4 * time.Second):
			t.Fatal("did not reconnect")
		}
	}
	s.mu.Lock()
	metric := s.active[p.ID]
	s.mu.Unlock()
	if metric == nil || metric.RAM != 60 || metric.Disk != 25 || metric.Processes != 12 {
		t.Fatalf("bad metrics: %+v", metric)
	}
	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("cancellation blocked")
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.running || m.connected {
		t.Fatal("monitor not stopped")
	}
}
func TestAutomationsExecutePersistAndRequireOwner174(t *testing.T) {
	s, p, commands := commandFixture174(t)
	owner, _ := makeOwner("Owner", "test-owner-password-174")
	s.store.data.Owner = owner
	request := func(method string, a automationRequest) *httptest.ResponseRecorder {
		raw, _ := json.Marshal(a)
		w := httptest.NewRecorder()
		s.automationsEndpoint(w, httptest.NewRequest(method, "/api/automations", strings.NewReader(string(raw))))
		return w
	}
	a := automationRequest{Automation: Automation{ServerID: p.ID, Name: "Disk report", Kind: "disk", Interval: 60}, OwnerPassword: "wrong"}
	if w := request("POST", a); w.Code != 403 {
		t.Fatal(w.Code)
	}
	a.OwnerPassword = "test-owner-password-174"
	if w := request("POST", a); w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	task := s.store.snapshot().Automations[0]
	if !s.reserveAutomation(task.ID) {
		t.Fatal("reserve")
	}
	if s.reserveAutomation(task.ID) {
		t.Fatal("duplicate allowed")
	}
	s.executeAutomation(context.Background(), task)
	select {
	case got := <-commands:
		if got != "LC_ALL=C df -hT" {
			t.Fatal(got)
		}
	default:
		t.Fatal("task did not use SSH")
	}
	reopened, e := openStore(s.store.dir)
	if e != nil {
		t.Fatal(e)
	}
	got := reopened.snapshot().Automations[0]
	if got.Status != "success" || !strings.Contains(got.Output, "actual fixture") || got.LastRun.IsZero() {
		t.Fatalf("%+v", got)
	}
	a.ID = task.ID
	a.Kind = "shell"
	if w := request("POST", a); w.Code != 400 {
		t.Fatal("unsupported preset accepted", w.Code)
	}
	if w := request("DELETE", automationRequest{Automation: Automation{ID: task.ID}, OwnerPassword: a.OwnerPassword}); w.Code != 200 {
		t.Fatal(w.Code)
	}
	if len(s.store.snapshot().Automations) != 0 || len(s.store.snapshot().Profiles) != 1 {
		t.Fatal("delete altered profiles")
	}
}
func TestJournalMinuteAndTimezone174(t *testing.T) {
	at, _ := time.Parse(time.RFC3339, "2026-11-12T13:45:00Z")
	entries := []JournalEntry{{At: at.Add(-time.Second), Action: "skip"}, {At: at, Action: "ssh", Level: "info"}, {At: at.Add(59 * time.Second), Action: "ssh", Level: "info"}, {At: at.Add(time.Minute), Action: "end", Level: "info"}}
	q := url.Values{"from": {"2026-11-12T15:45:00+02:00"}, "to": {"2026-11-12T15:46:00+02:00"}, "search": {"SSH"}}
	got, e := filterJournal(entries, q)
	if e != nil || len(got) != 2 {
		t.Fatal(got, e)
	}
	q.Set("to", "bad")
	if _, e = filterJournal(entries, q); e == nil {
		t.Fatal("invalid time accepted")
	}
}
func writeFixtureKey174(path string, block *pem.Block) error {
	return os.WriteFile(path, pem.EncodeToMemory(block), 0600)
}
