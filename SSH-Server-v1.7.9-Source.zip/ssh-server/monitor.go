package main

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Monitor struct {
	ID        string
	cancel    context.CancelFunc
	started   time.Time
	mu        sync.Mutex
	err       string
	running   bool
	connected bool
}

const sampler = `while :; do c=$(awk 'NR==1 {t=0;for(i=2;i<=9;i++)t+=$i;printf "%.0f %.0f", t,$5+$6}' /proc/stat); m=$(awk '/MemTotal:/ {total=$2} /MemAvailable:/ {avail=$2} END {print total,avail}' /proc/meminfo); d=$(df -P -k / | awk 'END {print $2,$3}'); n=$(awk -F '[: ]+' 'NR>2 {if (NF>12 && $2!="lo") {rx+=$3;tx+=$11}} END {printf "%.0f %.0f",rx+0,tx+0}' /proc/net/dev); u=$(awk '{print int($1)}' /proc/uptime); p=$(ps -e --no-headers | wc -l); echo "SAMPLE $c $m $d $n $u $p"; sleep 1; done`

func (s *Server) monitorStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID, Password string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	s.mu.Lock()
	if old := s.monitors[a.ID]; old != nil {
		old.mu.Lock()
		running := old.running
		old.mu.Unlock()
		if running {
			s.mu.Unlock()
			jsonOut(w, 200, map[string]bool{"ok": true})
			return
		}

	}
	ctx, cancel := context.WithCancel(context.Background())
	m := &Monitor{ID: a.ID, cancel: cancel, started: time.Now(), running: true}
	s.monitors[a.ID] = m
	s.mu.Unlock()
	go s.runMonitor(ctx, m, p, a.Password)
	jsonOut(w, 202, map[string]bool{"ok": true})
}
func (s *Server) runMonitor(ctx context.Context, m *Monitor, p Profile, password string) {
	defer func() { m.mu.Lock(); m.running = false; m.connected = false; m.mu.Unlock() }()
	delay := time.Second
	for ctx.Err() == nil {
		err := s.monitorConnection(ctx, m, p, password)
		if ctx.Err() != nil {
			return
		}
		m.mu.Lock()
		m.connected = false
		m.err = fmt.Sprintf("Connection interrupted; reconnecting in %s: %v", delay, err)
		m.mu.Unlock()
		select {
		case <-ctx.Done():
			return
		case <-time.After(delay):
		}
		if delay < 30*time.Second {
			delay *= 2
			if delay > 30*time.Second {
				delay = 30 * time.Second
			}
		}
		if current, ok := s.findProfile(p.ID); ok {
			p = current
		} else {
			return
		}
	}
}
func (s *Server) monitorConnection(ctx context.Context, m *Monitor, p Profile, password string) error {
	client, agent, e := s.dialSSH(ctx, p, password)
	if e != nil {
		return e
	}
	defer client.Close()
	if agent != nil {
		defer agent.Close()
	}
	stop := context.AfterFunc(ctx, func() { client.Close() })
	defer stop()
	watchdog := time.AfterFunc(20*time.Second, func() { client.Close() })
	defer watchdog.Stop()
	session, e := client.NewSession()
	if e != nil {
		return e
	}
	defer session.Close()
	stdout, e := session.StdoutPipe()
	if e != nil {
		return e
	}
	session.Stderr = io.Discard
	if e = session.Start(sampler); e != nil {
		return e
	}
	// Bound silent, half-open transports. Fresh samples extend the watchdog.
	sc := bufio.NewScanner(stdout)
	sc.Buffer(make([]byte, 0, 2048), 10000)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if !strings.HasPrefix(line, "SAMPLE ") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 11 {
			continue
		}
		vals := make([]uint64, 0, 10)
		valid := true
		for _, f := range fields[1:11] {
			v, err := strconv.ParseUint(f, 10, 64)
			if err != nil {
				valid = false
				break
			}
			vals = append(vals, v)
		}
		if !valid {
			continue
		}
		mtr := Metric{ServerID: p.ID, At: time.Now(), RAM: percent(safeSubtract(vals[2], vals[3]), vals[2]), Disk: percent(vals[5], vals[4]), Rx: vals[6], Tx: vals[7], Uptime: float64(vals[8]), Processes: int(vals[9])}
		if len(fields) >= 12 {
			v, _ := strconv.Atoi(fields[11])
			mtr.Processes = v
		}
		s.mu.Lock()
		prev := s.cpuPrev[p.ID]
		if prev[0] > 0 && vals[0] > prev[0] {
			totalDelta := vals[0] - prev[0]
			idleDelta := safeSubtract(vals[1], prev[1])
			if idleDelta <= totalDelta {
				mtr.CPU = 100 * float64(totalDelta-idleDelta) / float64(totalDelta)
			}
		}
		s.cpuPrev[p.ID] = [2]uint64{vals[0], vals[1]}
		s.active[p.ID] = &mtr
		s.mu.Unlock()
		watchdog.Reset(20 * time.Second)
		m.mu.Lock()
		m.connected = true
		m.err = ""
		m.mu.Unlock()
		s.saveHistory(mtr)
	}
	if e = sc.Err(); e != nil {
		return e
	}
	if e = session.Wait(); e != nil {
		return e
	}
	return errors.New("remote sampler closed")
}

func safeSubtract(a, b uint64) uint64 {
	if a > b {
		return a - b
	}
	return 0
}
func percent(used, total uint64) float64 {
	if total == 0 {
		return 0
	}
	n := 100 * float64(used) / float64(total)
	if n > 100 {
		return 100
	}
	if n < 0 {
		return 0
	}
	return n
}
func (s *Server) monitorStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	s.mu.Lock()
	m := s.monitors[a.ID]
	delete(s.monitors, a.ID)
	delete(s.active, a.ID)
	s.mu.Unlock()
	if m != nil {
		m.cancel()
	}
	jsonOut(w, 200, map[string]bool{"ok": true})
}
func (s *Server) monitorState(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	id := r.URL.Query().Get("id")
	s.mu.Lock()
	m := s.monitors[id]
	state := s.active[id]
	s.mu.Unlock()
	status := "stopped"
	err := ""
	if m != nil {
		m.mu.Lock()
		if m.running {
			status = "reconnecting"
			if m.connected {
				status = "running"
			}
			err = m.err
		} else if m.err != "" {
			status = "error"
			err = m.err
		}
		m.mu.Unlock()
	}
	jsonOut(w, 200, map[string]any{"status": status, "error": err, "metric": state})
}
func (s *Server) monitorProcesses(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	id := r.URL.Query().Get("id")
	p, ok := s.findProfile(id)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	password := r.Header.Get("X-SSH-Password")

	ctx, cancel := context.WithTimeout(r.Context(), 12*time.Second)
	defer cancel()
	out, e := s.runNative(ctx, p, password, "LC_ALL=C ps -eo pid=,comm=,%cpu=,%mem= --sort=-%cpu | head -n 35", "")
	if e != nil {
		fail(w, 412, e.Error())
		return
	}
	if e != nil {
		fail(w, 502, "Procese indisponibile prin SSH.")
		return
	}
	rows := []map[string]string{}
	for _, line := range strings.Split(string(out), "\n") {
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		rows = append(rows, map[string]string{"pid": fields[0], "command": strings.Join(fields[1:len(fields)-2], " "), "cpu": fields[len(fields)-2], "ram": fields[len(fields)-1]})
	}
	jsonOut(w, 200, map[string]any{"processes": rows})
}
