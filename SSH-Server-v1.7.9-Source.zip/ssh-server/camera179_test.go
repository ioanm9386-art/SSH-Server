package main

import (
	"bytes"
	"context"
	"crypto/md5"
	"crypto/sha1"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func fixtureONVIF179(t *testing.T, media2 bool) (CameraConnection179, *atomic.Int32) {
	t.Helper()
	var calls atomic.Int32
	var base string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		raw, _ := io.ReadAll(r.Body)
		body := string(raw)
		if r.Header.Get("Authorization") == "" {
			w.Header().Set("WWW-Authenticate", `Digest realm="camera", nonce="fixture-nonce", qop="auth", algorithm=MD5`)
			w.WriteHeader(401)
			return
		}
		auth := r.Header.Get("Authorization")
		if !strings.Contains(auth, `username="viewer"`) || !strings.Contains(auth, `nonce="fixture-nonce"`) || strings.Contains(auth, "DEVICE-PASS") {
			t.Error("bad HTTP digest")
		}
		fields := map[string]string{}
		for _, m := range regexp.MustCompile(`([a-z]+)="([^"]*)"`).FindAllStringSubmatch(auth, -1) {
			fields[m[1]] = m[2]
		}
		hash := func(text string) string { sum := md5.Sum([]byte(text)); return hex.EncodeToString(sum[:]) }
		expected := hash(hash("viewer:camera:DEVICE-PASS") + ":fixture-nonce:00000001:" + fields["cnonce"] + ":auth:" + hash("POST:"+r.URL.RequestURI()))
		if fields["response"] != expected {
			t.Error("HTTP digest response does not match device-side calculation")
		}
		if strings.Contains(body, "DEVICE-PASS") {
			t.Error("plaintext password in SOAP")
		}
		if !strings.Contains(body, "GetSystemDateAndTime") {
			n, e := parseXML179(raw)
			if e != nil {
				t.Error(e)
			} else {
				nonce, _ := base64.StdEncoding.DecodeString(n.value("Nonce"))
				hash := sha1.New()
				hash.Write(nonce)
				hash.Write([]byte(n.value("Created")))
				hash.Write([]byte("DEVICE-PASS"))
				if base64.StdEncoding.EncodeToString(hash.Sum(nil)) != n.value("Password") {
					t.Error("invalid WS-Security digest")
				}
			}
		}
		response := ""
		switch {
		case strings.Contains(body, "GetSystemDateAndTime"):
			now := time.Now().UTC()
			response = fmt.Sprintf("<GetSystemDateAndTimeResponse><UTCDateTime><Time><Hour>%d</Hour><Minute>%d</Minute><Second>%d</Second></Time><Date><Year>%d</Year><Month>%d</Month><Day>%d</Day></Date></UTCDateTime></GetSystemDateAndTimeResponse>", now.Hour(), now.Minute(), now.Second(), now.Year(), now.Month(), now.Day())
		case strings.Contains(body, "GetDeviceInformation"):
			response = "<GetDeviceInformationResponse><Manufacturer>Fixture Maker</Manufacturer><Model>Model Test</Model><SerialNumber>REAL-SERIAL-179</SerialNumber><FirmwareVersion>1.0</FirmwareVersion></GetDeviceInformationResponse>"
		case strings.Contains(body, "GetCapabilities"):
			response = "<GetCapabilitiesResponse><Capabilities><Media><XAddr>" + base + "/media</XAddr></Media></Capabilities></GetCapabilitiesResponse>"
			if media2 {
				response = "<GetCapabilitiesResponse/>"
			}
		case strings.Contains(body, "GetServices"):
			response = "<GetServicesResponse><Service><Namespace>" + media2NS179 + "</Namespace><XAddr>" + base + "/media2</XAddr></Service></GetServicesResponse>"
		case strings.Contains(body, "GetProfiles"):
			if media2 && !strings.Contains(body, media2NS179) {
				t.Error("Media2 namespace missing")
			}
			response = `<GetProfilesResponse><Profiles token="profile-one"><Name>Front door &amp; gate</Name><VideoEncoderConfiguration><Encoding>H264</Encoding><Resolution><Width>1920</Width><Height>1080</Height></Resolution></VideoEncoderConfiguration></Profiles></GetProfilesResponse>`
		case strings.Contains(body, "GetStreamUri"):
			if media2 && !strings.Contains(body, "RtspUnicast") {
				t.Error("incorrect Media2 transport")
			}
			response = "<GetStreamUriResponse><MediaUri><Uri>rtsp://127.0.0.1:554/fixture?channel=1&amp;token=protected</Uri></MediaUri></GetStreamUriResponse>"
		default:
			t.Error("unexpected ONVIF call")
			w.WriteHeader(400)
			return
		}
		w.Header().Set("Content-Type", "application/soap+xml")
		io.WriteString(w, `<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body>`+response+`</s:Body></s:Envelope>`)
	}))
	base = server.URL
	t.Cleanup(server.Close)
	host, port, _ := net.SplitHostPort(strings.TrimPrefix(base, "http://"))
	n, _ := strconv.Atoi(port)
	return CameraConnection179{Host: host, Port: 554, ONVIFPort: n, Username: "viewer", Password: "DEVICE-PASS", DevicePath: "/onvif/device_service", Channel: 1, ProfileToken: "profile-one"}, &calls
}
func TestONVIF179DigestProfilesStreamAndMedia2(t *testing.T) {
	for _, media2 := range []bool{false, true} {
		t.Run(fmt.Sprint(media2), func(t *testing.T) {
			c, calls := fixtureONVIF179(t, media2)
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			r, e := readONVIF179(ctx, c, true)
			if e != nil {
				t.Fatal(e)
			}
			if r.Serial != "REAL-SERIAL-179" || len(r.Profiles) != 1 || r.Profiles[0].Width != "1920" || !strings.Contains(r.Source, "viewer:DEVICE-PASS@127.0.0.1") {
				t.Fatalf("bad result: %+v", r)
			}
			if calls.Load() < 8 {
				t.Fatal("authentication challenge was not exercised")
			}
		})
	}
}
func TestCamera179PersistsConnectionEncryptsPasswordAndKeepsSource(t *testing.T) {
	c, _ := fixtureONVIF179(t, false)
	st, _ := openStore(t.TempDir())
	s := &Server{store: st}
	a := CameraSaveRequest179{Name: "Door", Kind: "camera", Brand: "axis", Method: "onvif", Connection: &c}
	raw, _ := json.Marshal(a)
	w := httptest.NewRecorder()
	s.liveCameras(w, httptest.NewRequest("POST", "/api/livecam", bytes.NewReader(raw)))
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	saved := s.store.snapshot().Cameras[0]
	disk, _ := os.ReadFile(st.path)
	for _, secret := range []string{"DEVICE-PASS", "rtsp://", "fixture?channel"} {
		if bytes.Contains(disk, []byte(secret)) {
			t.Fatal("plaintext data in store")
		}
	}
	w = httptest.NewRecorder()
	s.liveCameras(w, httptest.NewRequest("GET", "/api/livecam", nil))
	if strings.Contains(w.Body.String(), "DEVICE-PASS") || strings.Contains(w.Body.String(), "protected") || strings.Contains(w.Body.String(), "connectionSecret") {
		t.Fatal("secret exposed")
	}
	if !strings.Contains(w.Body.String(), `"username":"viewer"`) {
		t.Fatal("sanitized edit metadata missing")
	}
	a = CameraSaveRequest179{ID: saved.ID, Name: "Renamed", Kind: "camera", KeepExisting: true, Brand: "generic", Method: "sn"}
	raw, _ = json.Marshal(a)
	w = httptest.NewRecorder()
	s.liveCameras(w, httptest.NewRequest("POST", "/api/livecam", bytes.NewReader(raw)))
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	edited, _ := s.findCamera(saved.ID)
	if edited.Secret != saved.Secret || edited.ConnectionSecret != saved.ConnectionSecret || edited.Method != "onvif" || edited.Brand != "axis" {
		t.Fatal("metadata-only edit changed connection")
	}
}
func TestCamera179TemplatesCredentialEscapingAndCloudRefusal(t *testing.T) {
	if len(brands179()) != 13 {
		t.Fatal("13 dedicated profiles expected")
	}
	for _, b := range brands179() {
		if b.CloudSN {
			t.Fatal("unimplemented cloud advertised")
		}
		for _, template := range b.Templates {
			c := CameraConnection179{Host: "192.168.1.20", Port: 554, Username: "a@b", Password: "p:#?@&", Channel: 2, Template: template.ID, Substream: true}
			raw, e := templateSource179(b.ID, "camera", c)
			if e != nil {
				t.Fatal(e)
			}
			u, e := validateCameraURL(raw)
			if e != nil {
				t.Fatal(e)
			}
			password, _ := u.User.Password()
			if u.User.Username() != "a@b" || password != c.Password || strings.Contains(raw, "{") {
				t.Fatal(raw)
			}
		}
	}
	for _, id := range []string{"bosch", "ezviz", "imou", "tiandy", "generic"} {
		_, e := templateSource179(id, "camera", CameraConnection179{Host: "camera", Port: 554, Channel: 1, Template: "guessed"})
		if e == nil {
			t.Fatal("unverified path invented")
		}
	}
	_, _, e := prepareConnection179(context.Background(), CameraSaveRequest179{Method: "sn", Brand: "hikvision"}, LiveCamera{}, false)
	if e == nil || !strings.Contains(e.Error(), "Cloud SN") {
		t.Fatal("cloud placeholder accepted")
	}
}
func TestCamera179RejectsPasswordReuseForChangedRTSPHost(t *testing.T) {
	saved := CameraConnection179{Host: "first.test", Username: "user", Password: "SAVED-SECRET"}
	raw, _ := json.Marshal(saved)
	secret, _ := encryptSecret(string(raw))
	_, _, e := prepareConnection179(context.Background(), CameraSaveRequest179{Method: "rtsp", Brand: "generic", Kind: "camera", Source: "rtsp://second.test/live", Connection: &CameraConnection179{Host: "first.test", Username: "user", KeepPassword: true}}, LiveCamera{ConnectionSecret: secret}, true)
	if e == nil {
		t.Fatal("saved credentials forwarded to changed host")
	}
}
func TestONVIF179RejectsCrossHostEndpointRedirectAndOversizedXML(t *testing.T) {
	conn := CameraConnection179{Host: "127.0.0.1"}
	for _, u := range []string{"http://other.test/media", "http://user:pass@127.0.0.1/media", "file:///secret"} {
		if _, e := sameDeviceEndpoint179(u, conn); e == nil {
			t.Fatal(u)
		}
	}
	conn.HTTPS = true
	if _, e := sameDeviceEndpoint179("http://127.0.0.1/media", conn); e == nil {
		t.Fatal("TLS downgrade")
	}
	if _, e := parseXML179([]byte(strings.Repeat("<a>", 100) + strings.Repeat("</a>", 100))); e == nil {
		t.Fatal("XML depth not limited")
	}
	digest, e := digestAuth179(`Digest realm="camera", nonce="a", qop="auth", algorithm=SHA-256`, "POST", "/onvif", "viewer", "pass")
	if e != nil || !regexp.MustCompile(`response="[a-f0-9]{64}"`).MatchString(digest) {
		t.Fatal(digest, e)
	}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Location", "http://other.test/steal")
		w.WriteHeader(302)
	}))
	defer server.Close()
	host, port, _ := net.SplitHostPort(strings.TrimPrefix(server.URL, "http://"))
	n, _ := strconv.Atoi(port)
	c := CameraConnection179{Host: host, ONVIFPort: n, Port: 554, Channel: 1, DevicePath: "/onvif/device_service", Username: "viewer", Password: "secret"}
	client := newONVIF179(c)
	if _, e := client.soap(context.Background(), server.URL, deviceNS179, "GetDeviceInformation", "", true); e == nil {
		t.Fatal("redirect accepted")
	}
}
