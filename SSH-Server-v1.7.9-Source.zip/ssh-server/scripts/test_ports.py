import unittest
from unittest.mock import patch
import ports
FW='Status: active\n\n[ 1] 22/tcp ALLOW IN Anywhere\n[ 2] 8001/tcp DENY IN Anywhere # SSHServer-0123456789abcdef\n[ 3] 8001/tcp (v6) DENY IN Anywhere (v6) # SSHServer-0123456789abcdef\n'
UPNP="""List of UPNP devices found on the network :
 desc: http://192.168.1.1:5000/rootDesc.xml
Found valid IGD : http://192.168.1.1:5000/ctl/IPConn
ExternalIPAddress = 1.2.3.4
 i protocol exPort->inAddr:inPort description remoteHost leaseTime
 0 TCP 8001->192.168.1.10:80 'SSHServer-0123456789abcdef' '' 3600
 1 UDP 53->192.168.1.20:53 'Existing router rule' '' 0
"""
class PortTests(unittest.TestCase):
 def test_validation(self):
  for value in ['0','65536','22;reboot','1-100','1.2',True,None]:
   with self.assertRaises(ValueError):ports.port(value)
  self.assertEqual(ports.port('65535'),65535)
  self.assertEqual(ports.protocols('both'),['tcp','udp'])
  self.assertEqual(ports.source('192.168.1.25/24'),'192.168.1.0/24')
  with self.assertRaises(ValueError):ports.protocols('tcp;reboot')
 def test_parse_only_owned_firewall(self):
  rows=ports.parse_fw(FW);self.assertEqual(len(rows),2);self.assertEqual(rows[0]['port'],8001);self.assertEqual(rows[0]['action'],'deny')
 def test_protect_ssh_and_inactive_firewall(self):
  with patch('ports.os.geteuid',return_value=0),patch('ports.firewall_state',return_value={'active':False,'rules':[]}),patch('ports.run') as run:
   with self.assertRaisesRegex(ValueError,'inactive'):ports.firewall('add',{'port':8000,'protocol':'tcp','verb':'allow'})
   run.assert_not_called()
  with patch('ports.os.geteuid',return_value=0),patch('ports.firewall_state',return_value={'active':True,'rules':[]}),patch('ports.protected',return_value={2222}),patch('ports.run') as run:
   with self.assertRaisesRegex(ValueError,'protected'):ports.firewall('add',{'port':2222,'protocol':'tcp','verb':'deny'})
   run.assert_not_called()
 def test_fw_both_protocols_verified(self):
  label='SSHServer-0123456789abcdef';empty={'active':True,'rules':[],'raw':'Status: active'};final={'active':True,'rules':[{'id':label,'port':8001,'protocol':'tcp'},{'id':label,'port':8001,'protocol':'udp'}]}
  with patch('ports.os.geteuid',return_value=0),patch('ports.firewall_state',side_effect=[empty,final]),patch('ports.protected',return_value={22}),patch('ports.secrets.token_hex',return_value='0123456789abcdef'),patch('ports.run',return_value='ok') as run:
   r=ports.firewall('add',{'port':8001,'protocol':'both','verb':'allow','source':'192.168.1.0/24'});self.assertEqual(r['createdId'],label);self.assertEqual(run.call_count,2);self.assertEqual(run.call_args_list[0].args[0],['ufw','insert','1','allow','in','proto','tcp','from','192.168.1.0/24','to','any','port','8001','comment',label]);self.assertIn('udp',run.call_args_list[1].args[0])
 def test_fw_partial_failure_rolls_back_only_own_id(self):
  with patch('ports.os.geteuid',return_value=0),patch('ports.firewall_state',return_value={'active':True,'rules':[],'raw':'Status: active'}),patch('ports.protected',return_value={22}),patch('ports.secrets.token_hex',return_value='0123456789abcdef'),patch('ports.run',side_effect=['ok',ValueError('UDP rejected')]),patch('ports.remove_fw') as rollback:
   with self.assertRaisesRegex(ValueError,'UDP rejected'):ports.firewall('add',{'port':8001,'protocol':'both','verb':'deny'})
   rollback.assert_called_once_with('SSHServer-0123456789abcdef')
 def test_existing_ufw_not_overwritten(self):
  with patch('ports.os.geteuid',return_value=0),patch('ports.firewall_state',return_value={'active':True,'rules':ports.parse_fw(FW),'raw':FW}),patch('ports.protected',return_value={22}),patch('ports.run') as run:
   with self.assertRaisesRegex(ValueError,'already'):ports.firewall('add',{'port':8001,'protocol':'tcp','verb':'allow'})
   run.assert_not_called()
 def test_router_parse_existing_and_owned(self):
  data=ports.parse_router(UPNP);self.assertTrue(data['gateway']);self.assertEqual(data['deviceCount'],1);self.assertEqual(len(data['rules']),2);self.assertTrue(data['rules'][0]['managed']);self.assertFalse(data['rules'][1]['managed'])
 def test_router_reject_foreign_target_and_overwrite(self):
  with patch('ports.local_ips',return_value=['192.168.1.10']),patch('ports.run') as run:
   with self.assertRaisesRegex(ValueError,'assigned'):ports.router_state('192.168.1.20')
   run.assert_not_called()
  with patch('ports.router_state',return_value=ports.parse_router(UPNP)),patch('ports.run') as run:
   with self.assertRaisesRegex(ValueError,'already mapped'):ports.router('add',{'internalIP':'192.168.1.10','externalPort':8001,'internalPort':80,'protocol':'tcp','lease':3600})
   run.assert_not_called()
 def test_router_apply_verified(self):
  state=ports.parse_router(UPNP);state['rules']=[];final=ports.parse_router(UPNP)
  with patch('ports.router_state',side_effect=[state,final]),patch('ports.secrets.token_hex',return_value='0123456789abcdef'),patch('ports.run',return_value='ok') as run:
   r=ports.router('add',{'internalIP':'192.168.1.10','externalPort':8001,'internalPort':80,'protocol':'tcp','lease':3600});self.assertTrue(r['createdId']);self.assertEqual(run.call_args.args[0],['upnpc','-m','192.168.1.10','-e','SSHServer-0123456789abcdef','-a','192.168.1.10','80','8001','TCP','3600'])
 def test_router_delete_refuses_foreign_rule(self):
  with patch('ports.router_state',return_value=ports.parse_router(UPNP)),patch('ports.run') as run:
   with self.assertRaises(ValueError):ports.router('delete',{'internalIP':'192.168.1.10','ruleId':'Existing router rule','protocol':'udp'})
   run.assert_not_called()
 def test_router_delete_does_not_remove_changed_remote_restriction(self):
  with patch('ports.router_state'),patch('ports.run') as run:
   with self.assertRaises(ValueError):ports.remove_router('192.168.1.10',{'remoteHost':'1.1.1.1'})
   run.assert_not_called()
 def test_router_refuses_ignored_expiry_and_cleans_up(self):
  state=ports.parse_router(UPNP);state['rules']=[];final=ports.parse_router(UPNP);final['rules'][0]['lease']=0
  with patch('ports.router_state',side_effect=[state,final,final]),patch('ports.secrets.token_hex',return_value='0123456789abcdef'),patch('ports.run',return_value='ok'),patch('ports.remove_router') as rollback:
   with self.assertRaisesRegex(ValueError,'expiry'):ports.router('add',{'internalIP':'192.168.1.10','externalPort':8001,'internalPort':80,'protocol':'tcp','lease':3600})
   rollback.assert_called_once()
 def test_delete_only_owned_ufw_numbers(self):
  states=[{'rules':ports.parse_fw(FW)},{'rules':ports.parse_fw(FW.replace('[ 3] 8001/tcp (v6) DENY IN Anywhere (v6) # SSHServer-0123456789abcdef\n',''))},{'rules':[]}]
  with patch('ports.firewall_state',side_effect=states),patch('ports.run') as run:
   self.assertEqual(ports.remove_fw('SSHServer-0123456789abcdef'),2)
   self.assertEqual([call.args[0] for call in run.call_args_list],[['ufw','--force','delete','3'],['ufw','--force','delete','2']])
