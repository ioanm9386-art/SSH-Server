package main

import (
	"bufio"
	"context"
	"errors"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

type LiveCamera struct {
	Brand            string `json:"brand,omitempty"`
	Method           string `json:"method,omitempty"`
	ConnectionSecret string `json:"connectionSecret,omitempty"`

	Group   string    `json:"group,omitempty"`
	ID      string    `json:"id"`
	Name    string    `json:"name"`
	Kind    string    `json:"kind"`
	Channel string    `json:"channel"`
	Secret  string    `json:"sourceSecret"`
	Added   time.Time `json:"added"`
}
type CameraJob struct {
	ServerID    string `json:"serverId"`
	done        chan struct{}
	mu          sync.Mutex
	cancel      context.CancelFunc
	input       io.WriteCloser
	Status      string    `json:"status"`
	Error       string    `json:"error,omitempty"`
	Started     time.Time `json:"started"`
	Target      string    `json:"target"`
	Destination string    `json:"destination"`
}

func validateCameraURL(raw string) (*url.URL, error) {
	if len(raw) > 4096 || strings.ContainsAny(raw, "\x00\r\n") {
		return nil, errors.New("Invalid video source URL")
	}
	u, e := url.Parse(raw)
	if e != nil || u.Hostname() == "" {
		return nil, errors.New("Enter a full RTSP or HTTP(S) stream URL")
	}
	switch u.Scheme {
	case "rtsp", "rtsps", "http", "https":
	default:
		return nil, errors.New("Only RTSP and HTTP(S) video sources are supported in beta")
	}
	return u, nil
}
func safeSource(raw string) string {
	u, e := validateCameraURL(raw)
	if e != nil {
		return "Invalid source"
	}
	u.User = nil
	u.RawQuery = ""
	u.Fragment = ""
	return u.String()
}
func (s *Server) findCamera(id string) (LiveCamera, bool) {
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	for _, c := range s.store.data.Cameras {
		if c.ID == id {
			return c, true
		}
	}
	return LiveCamera{}, false
}
func (s *Server) ffmpegBinary() string {
	configured := s.store.snapshot().Settings.FFmpegPath
	if configured != "" {
		if st, e := os.Stat(configured); e == nil && st.Mode().IsRegular() {
			return configured
		}
		return ""
	}
	if p, e := exec.LookPath("ffmpeg"); e == nil {
		return p
	}
	return ""
}
func (s *Server) cameraSettings(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ Path string }
	if body(r, &a) != nil || len(a.Path) > 4096 {
		fail(w, 400, "Invalid FFmpeg path")
		return
	}
	if a.Path != "" {
		if !filepath.IsAbs(a.Path) || !strings.EqualFold(filepath.Base(a.Path), "ffmpeg.exe") && !strings.EqualFold(filepath.Base(a.Path), "ffmpeg") {
			fail(w, 400, "Select the ffmpeg executable")
			return
		}
		st, e := os.Stat(a.Path)
		if e != nil || !st.Mode().IsRegular() {
			fail(w, 400, "FFmpeg file not found")
			return
		}
	}
	s.store.mu.Lock()
	s.store.data.Settings.FFmpegPath = a.Path
	e := s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Cannot save video engine settings")
		return
	}
	jsonOut(w, 200, map[string]any{"ok": true, "ffmpegAvailable": s.ffmpegBinary() != ""})
}
func (s *Server) liveCameras(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		cameras := s.store.snapshot().Cameras
		rows := []map[string]any{}
		for _, c := range cameras {
			source := ""
			if raw, e := decryptSecret(c.Secret); e == nil {
				source = safeSource(raw)
			}
			row := map[string]any{"id": c.ID, "name": c.Name, "kind": c.Kind, "channel": c.Channel, "group": c.Group, "brand": c.Brand, "method": c.Method, "connection": connectionView179(c), "source": source, "added": c.Added, "recording": false}
			s.camerasMu.Lock()
			job := s.cameraJobs[c.ID]
			s.camerasMu.Unlock()
			if job != nil {
				job.mu.Lock()
				row["recording"] = (job.Status == "recording" || job.Status == "starting")
				row["job"] = map[string]any{"status": job.Status, "error": job.Error, "target": job.Target, "destination": job.Destination, "started": job.Started, "serverId": job.ServerID}
				job.mu.Unlock()
			}
			rows = append(rows, row)
		}
		jsonOut(w, 200, map[string]any{"cameras": rows, "beta": true, "ffmpegAvailable": s.ffmpegBinary() != "", "liveLimit": 4, "recordingScope": "local instance or Linux SSH destination"})
		return
	}
	if r.Method == "DELETE" {
		id := r.URL.Query().Get("id")
		if _, ok := s.findCamera(id); !ok {
			fail(w, 404, "Camera not found")
			return
		}
		s.stopCamera(id)
		s.store.mu.Lock()
		out := []LiveCamera{}
		for _, c := range s.store.data.Cameras {
			if c.ID != id {
				out = append(out, c)
			}
		}
		s.store.data.Cameras = out
		e := s.store.saveLocked()
		s.store.mu.Unlock()
		if e != nil {
			fail(w, 500, "Cannot save camera changes")
			return
		}
		jsonOut(w, 200, map[string]bool{"ok": true})
		return
	}
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a CameraSaveRequest179
	if body(r, &a) != nil || trimSpace(a.Name, 80) == "" {
		fail(w, 400, "Camera name required")
		return
	}
	old, exists := s.findCamera(a.ID)
	if a.ID != "" && !exists {
		fail(w, 404, "Camera not found")
		return
	}
	if a.Kind != "camera" && a.Kind != "nvr" && a.Kind != "dvr" && a.Kind != "xvr" {
		fail(w, 400, "Invalid device type")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
	defer cancel()
	raw, connectionSecret, e := prepareConnection179(ctx, a, old, exists)
	if e != nil {
		status := 400
		if a.Method == "sn" {
			status = 501
		}
		fail(w, status, e.Error())
		return
	}
	a.Source = raw
	c := LiveCamera{ID: a.ID, Name: trimSpace(a.Name, 80), Kind: a.Kind, Group: trimSpace(a.Group, 60), Channel: trimSpace(a.Channel, 40), Added: time.Now(), Brand: a.Brand, Method: a.Method, ConnectionSecret: connectionSecret}
	if a.KeepExisting || a.Method == "" {
		c.Brand = old.Brand
		c.Method = old.Method
	}

	if exists {
		c.Secret = old.Secret
		c.Added = old.Added
	} else {
		c.ID = randHex(8)
	}
	if a.Source != "" {
		if _, e := validateCameraURL(a.Source); e != nil {
			fail(w, 400, e.Error())
			return
		}
		encrypted, e := encryptSecret(a.Source)
		if e != nil {
			fail(w, 500, "Cannot protect camera credentials")
			return
		}
		c.Secret = encrypted
	}
	if c.Secret == "" {
		fail(w, 400, "A video stream URL is required")
		return
	}
	if a.Source != "" {
		s.stopCamera(c.ID)
	}
	s.store.mu.Lock()
	if !exists && len(s.store.data.Cameras) >= 100 {
		s.store.mu.Unlock()
		fail(w, 400, "Beta limit: 100 saved camera channels")
		return
	}
	if exists {
		for i := range s.store.data.Cameras {
			if s.store.data.Cameras[i].ID == c.ID {
				s.store.data.Cameras[i] = c
			}
		}
	} else {
		s.store.data.Cameras = append(s.store.data.Cameras, c)
	}
	e = s.store.saveLocked()
	s.store.mu.Unlock()
	if e != nil {
		fail(w, 500, "Cannot save camera")
		return
	}
	s.store.log("livecam_saved", c.Name, "info")
	jsonOut(w, 200, map[string]any{"ok": true, "id": c.ID})
}
func cameraInputArgs(source string) []string {
	args := []string{"-hide_banner", "-loglevel", "error", "-protocol_whitelist", "tcp,udp,rtp,rtsp,http,https,tls,crypto,httpproxy"}
	if strings.HasPrefix(source, "rtsp://") || strings.HasPrefix(source, "rtsps://") {
		args = append(args, "-rtsp_transport", "tcp", "-timeout", "10000000")
	} else {
		args = append(args, "-rw_timeout", "10000000")
	}
	return append(args, "-i", source)
}
func (s *Server) cameraStream(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	c, ok := s.findCamera(r.URL.Query().Get("id"))
	if !ok {
		fail(w, 404, "Camera not found")
		return
	}
	engine := s.ffmpegBinary()
	if engine == "" {
		fail(w, 412, "FFmpeg is required for LiveCam beta. Select ffmpeg.exe in LiveCam.")
		return
	}
	source, e := decryptSecret(c.Secret)
	if e != nil {
		fail(w, 500, "Camera credentials cannot be unlocked on this Windows account")
		return
	}
	s.camerasMu.Lock()
	if s.activeLive >= 4 {
		s.camerasMu.Unlock()
		fail(w, 429, "Beta limit: 4 simultaneous live views")
		return
	}
	s.activeLive++
	s.camerasMu.Unlock()
	defer func() { s.camerasMu.Lock(); s.activeLive--; s.camerasMu.Unlock() }()
	ctx, cancel := context.WithCancel(r.Context())
	defer cancel()
	args := append(cameraInputArgs(source), "-an", "-vf", "scale=960:-2,fps=8", "-threads", "2", "-c:v", "mjpeg", "-q:v", "5", "-f", "mpjpeg", "pipe:1")
	cmd := exec.CommandContext(ctx, engine, args...)
	hideProcessWindow(cmd)
	out, e := cmd.StdoutPipe()
	if e != nil {
		fail(w, 500, "Cannot start video stream")
		return
	}
	cmd.Stderr = io.Discard
	if e = cmd.Start(); e != nil {
		fail(w, 502, "Cannot start FFmpeg")
		return
	}
	defer func() { cancel(); _ = cmd.Wait() }()
	// Do not report HTTP 200 until a real video frame starts to arrive.
	first := make([]byte, 8192)
	n, e := out.Read(first)
	if n == 0 && e != nil {
		fail(w, 502, "No video received. Check source URL, credentials, network and codec.")
		return
	}
	w.Header().Set("Content-Type", "multipart/x-mixed-replace; boundary=ffmpeg")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(200)
	_, _ = w.Write(first[:n])
	if f, ok := w.(http.Flusher); ok {
		f.Flush()
	}
	_, _ = io.Copy(w, out)
}
func recordingArgs(source, destination string) []string {
	return append(cameraInputArgs(source), "-progress", "pipe:1", "-map", "0:v:0", "-map", "0:a?", "-c", "copy", "-f", "segment", "-segment_time", "300", "-reset_timestamps", "1", "-strftime", "1", destination)
}
func remoteRecordingCommand(source, dir, id string) string {
	dest := strings.TrimSuffix(dir, "/") + "/" + id + "-%Y%m%d-%H%M%S.mkv"
	args := append([]string{"ffmpeg", "-nostdin"}, recordingArgs(source, dest)...)
	quoted := make([]string, len(args))
	for i, a := range args {
		quoted[i] = shellQuote(a)
	}
	// The stdin watcher stops recording on Stop, application exit, or SSH EOF.
	return "command -v ffmpeg >/dev/null || { echo 'FFmpeg is not installed on destination server' >&2;exit 127; }; mkdir -p -- " + shellQuote(dir) + " || exit 1; " + strings.Join(quoted, " ") + " & p=$!; trap 'kill -INT \"$p\" 2>/dev/null' HUP INT TERM; ( read -r stop; kill -INT \"$p\" 2>/dev/null ) <&0 & watcher=$!; wait \"$p\"; result=$?; kill \"$watcher\" 2>/dev/null; exit \"$result\""
}
func (s *Server) cameraRecord(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct {
		ID, ServerID, Directory string
		Confirmed               bool
	}
	if body(r, &a) != nil || !a.Confirmed {
		fail(w, 400, "Confirm the recording destination before starting")
		return
	}
	c, ok := s.findCamera(a.ID)
	if !ok {
		fail(w, 404, "Camera not found")
		return
	}
	source, e := decryptSecret(c.Secret)
	if e != nil {
		fail(w, 500, "Camera credentials unavailable")
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	var cmd *exec.Cmd
	target := "This Windows instance"
	dir := a.Directory
	if a.ServerID != "" {
		p, found := s.findProfile(a.ServerID)
		if !found || !safeRemote(dir) || !strings.HasPrefix(dir, "/") {
			cancel()
			fail(w, 400, "Select a Linux server and an absolute recording directory")
			return
		}
		if p.Auth == "password" && s.sshCredential(p, "") == "" {
			cancel()
			fail(w, 412, "Unlock this server once from SSH Connections before recording; an open terminal is not required")
			return
		}
		cmd, e = s.sshCmd(ctx, p, "", false, remoteRecordingCommand(source, dir, c.ID))
		target = p.Name
	} else {
		engine := s.ffmpegBinary()
		if engine == "" {
			cancel()
			fail(w, 412, "Select FFmpeg before recording on this instance")
			return
		}
		if dir == "" {
			dir = filepath.Join(s.store.dir, "recordings", c.ID)
		}
		if !filepath.IsAbs(dir) {
			cancel()
			fail(w, 400, "Select an absolute local recording directory")
			return
		}
		if e = os.MkdirAll(dir, 0700); e != nil {
			cancel()
			fail(w, 403, "Cannot create recording directory")
			return
		}
		cmd = exec.CommandContext(ctx, engine, recordingArgs(source, filepath.Join(dir, c.ID+"-%Y%m%d-%H%M%S.mkv"))...)
		hideProcessWindow(cmd)
	}
	if e != nil {
		cancel()
		fail(w, 412, e.Error())
		return
	}
	s.camerasMu.Lock()
	if s.cameraJobs == nil {
		s.cameraJobs = map[string]*CameraJob{}
	}
	if old := s.cameraJobs[a.ID]; old != nil {
		old.mu.Lock()
		running := (old.Status == "recording" || old.Status == "starting")
		old.mu.Unlock()
		if running {
			s.camerasMu.Unlock()
			cancel()
			fail(w, 409, "Recording is already active")
			return
		}
	}
	active := 0
	for _, j := range s.cameraJobs {
		j.mu.Lock()
		if j.Status == "recording" || j.Status == "starting" {
			active++
		}
		j.mu.Unlock()
	}
	if active >= 4 {
		s.camerasMu.Unlock()
		cancel()
		fail(w, 429, "Beta limit: 4 simultaneous recordings")
		return
	}
	input, e := cmd.StdinPipe()
	if e != nil {
		s.camerasMu.Unlock()
		cancel()
		fail(w, 500, "Cannot control recording process")
		return
	}
	// Never log raw FFmpeg output: it may contain stream usernames/passwords.
	output, e := cmd.StdoutPipe()
	if e != nil {
		s.camerasMu.Unlock()
		cancel()
		fail(w, 500, "Cannot read recording progress")
		return
	}
	cmd.Stderr = io.Discard
	if e = cmd.Start(); e != nil {
		s.camerasMu.Unlock()
		cancel()
		fail(w, 502, "Cannot start recording engine")
		return
	}
	if e = s.rememberArchive(c.ID, a.ServerID, dir); e != nil {
		s.camerasMu.Unlock()
		cancel()
		cmd.Process.Kill()
		cmd.Wait()
		fail(w, 500, "Could not register recording archive")
		return
	}
	job := &CameraJob{ServerID: a.ServerID, cancel: cancel, input: input, done: make(chan struct{}), Status: "starting", Started: time.Now(), Target: target, Destination: dir}
	s.cameraJobs[a.ID] = job
	s.camerasMu.Unlock()
	go func() {
		defer close(job.done)
		sc := bufio.NewScanner(output)
		for sc.Scan() {
			if strings.HasPrefix(sc.Text(), "frame=") {
				frame, _ := strconv.Atoi(strings.TrimSpace(strings.TrimPrefix(sc.Text(), "frame=")))
				if frame > 0 {
					job.mu.Lock()
					if job.Status == "starting" {
						job.Status = "recording"
					}
					job.mu.Unlock()
				}
			}
		}
		err := cmd.Wait()
		cancel()
		job.mu.Lock()
		if job.Status == "recording" || job.Status == "starting" {
			if err != nil {
				job.Status = "error"
				job.Error = "Recording stopped: check FFmpeg, source credentials, destination permissions and free disk space"
			} else {
				job.Status = "stopped"
			}
		}
		job.mu.Unlock()
	}()
	s.store.log("livecam_recording_started", c.Name+" → "+target, "info")
	jsonOut(w, 202, map[string]any{"ok": true, "status": "starting", "destination": dir, "target": target})
}
func (s *Server) stopCamera(id string) {
	s.camerasMu.Lock()
	job := s.cameraJobs[id]
	s.camerasMu.Unlock()
	if job == nil {
		return
	}
	job.mu.Lock()
	if job.Status != "recording" && job.Status != "starting" {
		job.mu.Unlock()
		return
	}
	job.Status = "stopped"
	_, _ = io.WriteString(job.input, "q\n")
	_ = job.input.Close()
	job.mu.Unlock()
	time.AfterFunc(4*time.Second, job.cancel)
}
func (s *Server) stopAllCameras() {
	s.camerasMu.Lock()
	ids := []string{}
	jobs := []*CameraJob{}
	for id, j := range s.cameraJobs {
		ids = append(ids, id)
		jobs = append(jobs, j)
	}
	s.camerasMu.Unlock()
	for _, id := range ids {
		s.stopCamera(id)
	}
	timer := time.NewTimer(2200 * time.Millisecond)
	defer timer.Stop()
	for _, j := range jobs {
		select {
		case <-j.done:
		case <-timer.C:
			for _, remaining := range jobs {
				remaining.cancel()
			}
			return
		}
	}
}

func (s *Server) cameraStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a struct{ ID string }
	if body(r, &a) != nil {
		fail(w, 400, "Invalid camera request")
		return
	}
	s.stopCamera(a.ID)
	jsonOut(w, 200, map[string]bool{"ok": true})
}
