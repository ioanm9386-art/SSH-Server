import urllib.request,urllib.parse,base64,ipaddress,re

def update(c):
    provider=c.get('provider');host=c.get('hostname','').lower().strip()
    if not re.fullmatch(r'[a-z0-9][a-z0-9.\-]{0,250}',host):raise ValueError('Invalid hostname')
    if provider=='duckdns':
        name=host.removesuffix('.duckdns.org')
        if '.' in name:raise ValueError('Use one DuckDNS subdomain')
        token=c.get('token','')
        if not token:raise ValueError('DuckDNS token required')
        url='https://www.duckdns.org/update?'+urllib.parse.urlencode({'domains':name,'token':token,'ip':''})
        request=urllib.request.Request(url,headers={'User-Agent':'SSH-Server/1.7.2'})
    elif provider=='noip':
        # No-IP requires a DDNS key, not an arbitrary third-party API endpoint.
        key=c.get('username','')+':'+c.get('password','')
        url='https://dynupdate.no-ip.com/nic/update?'+urllib.parse.urlencode({'hostname':host})
        request=urllib.request.Request(url,headers={'User-Agent':'SSH-Server/1.7.2','Authorization':'Basic '+base64.b64encode(key.encode()).decode()})
    else:raise ValueError('Unsupported DDNS provider')
    try:
        with urllib.request.urlopen(request,timeout=20) as response:result=response.read(1000).decode().strip()
    except Exception:raise ValueError('DDNS request failed. Check provider credentials and connectivity.')
    if provider=='duckdns' and result=='OK':return 'Updated'
    if provider=='noip' and result.split(' ')[0] in ('good','nochg'):return 'Updated' if result.startswith('good') else 'No change'
    raise ValueError('DDNS provider rejected the update. Check hostname and credentials.')
