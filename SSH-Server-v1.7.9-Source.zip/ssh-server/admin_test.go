package main

import (
	"encoding/base64"
	"encoding/json"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

func TestAdminAuthorizationAndAllowlist(t *testing.T) {
	for _, a := range []AdminRequest{{Action: "shell", Confirmation: "CONFIRM"}, {Action: "service"}, {Action: "package", Confirmation: "CONFIRM", SudoPassword: "a\nb"}} {
		if validateAdmin(a) == nil {
			t.Fatal("unsafe administrative action accepted", a.Action)
		}
	}
	for _, action := range []string{"agent-state", "raid-plan", "service-logs"} {
		if err := validateAdmin(AdminRequest{Action: action}); err != nil {
			t.Fatal(err)
		}
	}
}
func TestPythonCommandDoesNotInterpolateScript(t *testing.T) {
	script := []byte("print('a; $(injection)')")
	command := pythonCommand(script)
	if strings.Contains(command, "$(injection)") || !strings.Contains(command, base64.StdEncoding.EncodeToString(script)) {
		t.Fatal(command)
	}
}
func TestEndpointChangeRequiresPinnedKeyAndPreservesOwner(t *testing.T) {
	st, _ := openStore(t.TempDir())
	owner, _ := makeOwner("Owner", "owner-password-test")
	st.data.Owner = owner
	st.data.Profiles = []Profile{{ID: "p1", Name: "Test", Host: "lan.test", Port: 22, User: "qa", Auth: "password", HostKeys: []string{"lan.test ssh-ed25519 pinned"}}}
	s := &Server{store: st}
	r := httptest.NewRequest("POST", "/api/profiles", strings.NewReader(`{"id":"p1","name":"Test","host":"external.test","port":2222,"user":"qa","auth":"password","access":[{"name":"external","host":"external.test","port":2222}],"endpointKeys":{"external.test:2222":["untrusted"]}}`))
	w := httptest.NewRecorder()
	s.profiles(w, r)
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	d := st.snapshot()
	if len(d.Profiles[0].HostKeys) != 0 {
		t.Fatal("client supplied key was trusted")
	}
	if d.Owner.PasswordHash != owner.PasswordHash {
		t.Fatal("Owner modified")
	}
	if len(d.Profiles[0].EndpointKeys["lan.test:22"]) != 1 {
		t.Fatal("previous key not retained")
	}
	raw, _ := os.ReadFile(st.path)
	var data Data
	if json.Unmarshal(raw, &data) != nil || len(data.Profiles[0].Access) != 1 {
		t.Fatal("access data not persisted")
	}
}
