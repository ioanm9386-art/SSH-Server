package main

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"
)

func TestRemoteDirectoryIsCanonicalAndFilenamesPreserveSpacesAndTabs(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("GNU Linux listing")
	}
	dir := t.TempDir()
	for _, name := range []string{"a file.txt", "tab\tname.txt", "  padded name  "} {
		if e := os.WriteFile(filepath.Join(dir, name), []byte("test"), 0600); e != nil {
			t.Fatal(e)
		}
	}
	nested := filepath.Join(dir, "folder one")
	if e := os.Mkdir(nested, 0700); e != nil {
		t.Fatal(e)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "sh", "-c", listingCommand("."))
	cmd.Dir = dir
	out, e := cmd.Output()
	if e != nil {
		t.Fatal(e)
	}
	absolute, items, e := parseRemoteListing(string(out))
	if e != nil || absolute != dir || len(items) != 4 {
		t.Fatal(absolute, items, e)
	}
	if items[0].Type != "dir" {
		t.Fatal("directories must be first")
	}
	for _, item := range items {
		if !strings.HasPrefix(item.Path, dir+"/") {
			t.Fatal("relative path leaked", item)
		}
	}
	cmd = exec.CommandContext(ctx, "sh", "-c", listingCommand(nested+"/.."))
	out, e = cmd.Output()
	if e != nil {
		t.Fatal(e)
	}
	absolute, _, e = parseRemoteListing(string(out))
	if e != nil || absolute != dir {
		t.Fatal("Up navigation must resolve to the parent", absolute, e)
	}
}
func TestStorageLocationsIncludeMountedRAIDAndSkipPseudoFilesystems(t *testing.T) {
	raw := "/home/nebula\x00" + `{"filesystems":[{"target":"/","source":"/dev/sda2","fstype":"ext4"},{"target":"/DATA/RAID 1","source":"/dev/md0","fstype":"ext4"},{"target":"/proc","source":"proc","fstype":"proc"},{"target":"/snap/core/1","source":"/dev/loop0","fstype":"squashfs"}]}`
	locations, e := parseRemoteLocations(raw)
	if e != nil {
		t.Fatal(e)
	}
	if len(locations) != 3 {
		t.Fatal(locations)
	}
	if locations[2].Path != "/DATA/RAID 1" || locations[2].Source != "/dev/md0" {
		t.Fatal(locations)
	}
}
