package main

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestPortActionsRequireOwnerAndConfirmation176(t *testing.T) {
	for _, action := range []string{"ports-firewall-add", "ports-firewall-delete", "ports-firewall-state", "ports-router-add", "ports-router-delete"} {
		if validateAdmin(AdminRequest{Action: action}) == nil {
			t.Fatal("missing confirmation accepted", action)
		}
		if e := validateAdmin(AdminRequest{Action: action, Confirmation: "CONFIRM"}); e != nil {
			t.Fatal(e)
		}
	}
	if e := validateAdmin(AdminRequest{Action: "ports-router-state"}); e != nil {
		t.Fatal(e)
	}
	if validateAdmin(AdminRequest{Action: "ports-router-reset", Confirmation: "CONFIRM"}) == nil {
		t.Fatal("arbitrary operation accepted")
	}
	st, _ := openStore(t.TempDir())
	st.data.Profiles = []Profile{{ID: "p"}}
	s := &Server{store: st}
	for _, action := range []string{"ports-firewall-add", "ports-router-add"} {
		w := httptest.NewRecorder()
		r := httptest.NewRequest("POST", "/api/admin/operation", strings.NewReader(`{"id":"p","action":"`+action+`","confirmation":"CONFIRM","params":{"port":8080}}`))
		s.adminOperation(w, r)
		if w.Code != 403 {
			t.Fatal("unauthorized mutation reached execution", action, w.Code)
		}
	}
}
