package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"golang.org/x/crypto/ssh"
	"net"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestIntegratedHostScanDoesNotAuthenticateOrTrust(t *testing.T) {
	_, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(private)
	if err != nil {
		t.Fatal(err)
	}
	var authCalls atomic.Int32
	cfg := &ssh.ServerConfig{PasswordCallback: func(_ ssh.ConnMetadata, _ []byte) (*ssh.Permissions, error) { authCalls.Add(1); return nil, nil }}
	cfg.AddHostKey(signer)
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	done := make(chan struct{})
	go func() {
		defer close(done)
		conn, e := listener.Accept()
		if e != nil {
			return
		}
		defer conn.Close()
		_, _, _, _ = ssh.NewServerConn(conn, cfg)
	}()
	_, port, _ := net.SplitHostPort(listener.Addr().String())
	p, _ := strconv.Atoi(port)
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	keys, err := scanHostKey(ctx, "127.0.0.1", p)
	if err != nil {
		t.Fatal(err)
	}
	if len(keys) != 1 || keys[0].Fingerprint != ssh.FingerprintSHA256(signer.PublicKey()) {
		t.Fatalf("wrong fingerprint: %+v", keys)
	}
	if !strings.HasPrefix(keys[0].Line, "[127.0.0.1]:"+port+" ssh-ed25519 ") {
		t.Fatal(keys[0].Line)
	}
	<-done
	if authCalls.Load() != 0 {
		t.Fatal("identity scan must not attempt authentication")
	}
	st, err := openStore(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if _, err = (&Server{store: st}).knownHosts(Profile{ID: "test"}); err == nil {
		t.Fatal("scanning must not bypass explicit host trust")
	}
}
func TestIntegratedHostScanCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := scanHostKey(ctx, "127.0.0.1", 22); err == nil {
		t.Fatal("cancelled scan succeeded")
	}
	for _, p := range []int{0, -1, 65536} {
		if _, err := scanHostKey(context.Background(), "127.0.0.1", p); err == nil {
			t.Fatal("invalid port accepted")
		}
	}
}
