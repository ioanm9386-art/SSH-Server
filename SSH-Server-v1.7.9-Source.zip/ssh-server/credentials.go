package main

import (
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
)

func sshOptionPath(path string) string { return strconv.Quote(filepath.ToSlash(path)) }
func credentialID(p Profile) string {
	return strings.Join([]string{p.ID, p.Host, strconv.Itoa(p.Port), p.User, p.Auth}, "\x00")
}

// Credentials are kept only in this process, per server identity. They are never
// returned by the API or serialized in data.json, logs, backups or browser storage.
func (s *Server) sshCredential(p Profile, supplied string) string {
	if p.Auth != "password" {
		return ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.credentials == nil {
		s.credentials = map[string]string{}
	}
	key := credentialID(p)
	if supplied != "" {
		s.credentials[key] = supplied
	}
	return s.credentials[key]
}
func (s *Server) credentialsEndpoint(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	var a struct{ ID, Password string }
	if r.Method == "POST" {
		if body(r, &a) != nil || len(a.Password) > 4096 {
			fail(w, 400, "Invalid credential request")
			return
		}
		id = a.ID
	} else if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	p, ok := s.findProfile(id)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	if r.Method == "POST" {
		if a.Password == "" {
			s.mu.Lock()
			delete(s.credentials, credentialID(p))
			s.mu.Unlock()
		} else {
			s.sshCredential(p, a.Password)
		}
	}
	unlocked := p.Auth != "password" || s.sshCredential(p, "") != ""
	jsonOut(w, 200, map[string]any{"unlocked": unlocked, "scope": "application-memory", "serverId": p.ID})
}
