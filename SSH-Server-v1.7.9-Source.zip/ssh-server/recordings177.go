package main

import (
	"context"
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

type ArchiveLocation struct {
	ID        string `json:"id"`
	CameraID  string `json:"cameraId"`
	ServerID  string `json:"serverId"`
	Directory string `json:"directory"`
}
type ArchiveEntry struct {
	LocationID string    `json:"locationId"`
	Name       string    `json:"name"`
	Size       int64     `json:"size"`
	Modified   time.Time `json:"modified"`
	InProgress bool      `json:"inProgress"`
	Target     string    `json:"target"`
}

func (s *Server) archiveLocations(id string) []ArchiveLocation {
	rows := []ArchiveLocation{}
	for _, x := range s.store.snapshot().CameraArchives {
		if x.CameraID == id {
			rows = append(rows, x)
		}
	}
	dir := filepath.Join(s.store.dir, "recordings", id)
	sum := sha256.Sum256([]byte(id + "\x00\x00" + dir))
	base := ArchiveLocation{ID: fmt.Sprintf("%x", sum[:8]), CameraID: id, Directory: dir}
	for _, x := range rows {
		if x.ID == base.ID {
			return rows
		}
	}
	return append(rows, base)
}
func (s *Server) rememberArchive(id, server, dir string) error {
	sum := sha256.Sum256([]byte(id + "\x00" + server + "\x00" + dir))
	a := ArchiveLocation{ID: fmt.Sprintf("%x", sum[:8]), CameraID: id, ServerID: server, Directory: dir}
	s.store.mu.Lock()
	defer s.store.mu.Unlock()
	count := 0
	for _, x := range s.store.data.CameraArchives {
		if x.ID == a.ID {
			return nil
		}
		if x.CameraID == id {
			count++
		}
	}
	if count >= 8 {
		return fmt.Errorf("Archive location limit: 8 per camera")
	}
	s.store.data.CameraArchives = append(s.store.data.CameraArchives, a)
	return s.store.saveLocked()
}
func recordingName177(id, name string) bool {
	return !strings.ContainsAny(name, "/\\") && regexp.MustCompile("^"+regexp.QuoteMeta(id)+`-[0-9]{8}-[0-9]{6}\.mkv$`).MatchString(name)
}
func (s *Server) archiveList(ctx context.Context, a ArchiveLocation) ([]os.FileInfo, error) {
	if a.ServerID == "" {
		entries, e := os.ReadDir(a.Directory)
		if os.IsNotExist(e) {
			return []os.FileInfo{}, nil
		}
		if e != nil {
			return nil, e
		}
		out := []os.FileInfo{}
		for i, x := range entries {
			if i >= 10000 {
				break
			}
			if !recordingName177(a.CameraID, x.Name()) || x.Type()&os.ModeSymlink != 0 {
				continue
			}
			if info, e := x.Info(); e == nil && info.Mode().IsRegular() {
				out = append(out, info)
			}
		}
		return out, nil
	}
	p, ok := s.findProfile(a.ServerID)
	if !ok {
		return nil, fmt.Errorf("Recording server no longer exists")
	}
	sf, close, e := s.openSFTP(ctx, p, "")
	if e != nil {
		return nil, fmt.Errorf("Unlock the recording server to list its archive")
	}
	defer close()
	entries, e := sf.ReadDirContext(ctx, a.Directory)
	if e != nil {
		return nil, e
	}
	out := []os.FileInfo{}
	for i, x := range entries {
		if i >= 10000 {
			break
		}
		if recordingName177(a.CameraID, x.Name()) && x.Mode().IsRegular() {
			out = append(out, x)
		}
	}
	return out, nil
}
func (s *Server) cameraArchive(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	id := r.URL.Query().Get("id")
	if _, ok := s.findCamera(id); !ok {
		fail(w, 404, "Camera not found")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 30*time.Second)
	defer cancel()
	rows := []ArchiveEntry{}
	warnings := []string{}
	s.camerasMu.Lock()
	job := s.cameraJobs[id]
	s.camerasMu.Unlock()
	active, activeDir, activeServer := false, "", ""
	if job != nil {
		job.mu.Lock()
		active = job.Status == "starting" || job.Status == "recording"
		activeDir = job.Destination
		activeServer = job.ServerID
		job.mu.Unlock()
	}
	for _, location := range s.archiveLocations(id) {
		entries, e := s.archiveList(ctx, location)
		if e != nil {
			warnings = append(warnings, "Archive unavailable: "+location.Directory)
			continue
		}
		sort.Slice(entries, func(i, j int) bool { return entries[i].ModTime().After(entries[j].ModTime()) })
		target := "Windows"
		if location.ServerID != "" {
			if p, ok := s.findProfile(location.ServerID); ok {
				target = p.Name
			}
		}
		for i, x := range entries {
			rows = append(rows, ArchiveEntry{LocationID: location.ID, Name: x.Name(), Size: x.Size(), Modified: x.ModTime(), Target: target, InProgress: active && activeDir == location.Directory && (location.ServerID == activeServer) && i == 0})
		}
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].Modified.After(rows[j].Modified) })
	truncated := len(rows) > 1000
	if truncated {
		rows = rows[:1000]
	}
	jsonOut(w, 200, map[string]any{"recordings": rows, "warnings": warnings, "truncated": truncated})
}
func (s *Server) archiveOpen(ctx context.Context, id, locationID, name string) (io.ReadSeekCloser, func(), os.FileInfo, error) {
	if _, ok := s.findCamera(id); !ok {
		return nil, nil, nil, fmt.Errorf("Camera not found")
	}
	if !recordingName177(id, name) {
		return nil, nil, nil, fmt.Errorf("Invalid recording name")
	}
	var loc *ArchiveLocation
	for _, a := range s.archiveLocations(id) {
		if a.ID == locationID {
			copy := a
			loc = &copy
			break
		}
	}
	if loc == nil {
		return nil, nil, nil, fmt.Errorf("Unknown archive location")
	}
	if loc.ServerID == "" {
		p := filepath.Join(loc.Directory, name)
		info, e := os.Lstat(p)
		if e != nil || !info.Mode().IsRegular() {
			return nil, nil, nil, fmt.Errorf("Recording unavailable")
		}
		f, e := os.Open(p)
		if e != nil {
			return nil, nil, nil, e
		}
		actual, e := f.Stat()
		if e != nil || !os.SameFile(info, actual) {
			f.Close()
			return nil, nil, nil, fmt.Errorf("Recording changed")
		}
		return f, func() { f.Close() }, actual, nil
	}
	profile, ok := s.findProfile(loc.ServerID)
	if !ok {
		return nil, nil, nil, fmt.Errorf("Recording server missing")
	}
	sf, close, e := s.openSFTP(ctx, profile, "")
	if e != nil {
		return nil, nil, nil, fmt.Errorf("Unlock recording server")
	}
	p := path.Join(loc.Directory, name)
	info, e := sf.Lstat(p)
	if e != nil || !info.Mode().IsRegular() {
		close()
		return nil, nil, nil, fmt.Errorf("Recording unavailable")
	}
	f, e := sf.Open(p)
	if e != nil {
		close()
		return nil, nil, nil, e
	}
	return f, func() { f.Close(); close() }, info, nil
}
func (s *Server) cameraArchiveFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	q := r.URL.Query()
	f, close, info, e := s.archiveOpen(r.Context(), q.Get("id"), q.Get("location"), q.Get("name"))
	if e != nil {
		fail(w, 404, e.Error())
		return
	}
	defer close()
	w.Header().Set("Content-Type", "video/x-matroska")
	w.Header().Set("Content-Disposition", `attachment; filename="`+q.Get("name")+`"`)
	http.ServeContent(w, r, info.Name(), info.ModTime(), f)
}
func (s *Server) cameraPlayback(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	engine := s.ffmpegBinary()
	if engine == "" {
		fail(w, 412, "Select FFmpeg first")
		return
	}
	s.camerasMu.Lock()
	if s.cameraPlaybackActive >= 1 {
		s.camerasMu.Unlock()
		fail(w, 429, "One archive playback at a time")
		return
	}
	s.cameraPlaybackActive++
	s.camerasMu.Unlock()
	defer func() { s.camerasMu.Lock(); s.cameraPlaybackActive--; s.camerasMu.Unlock() }()
	q := r.URL.Query()
	f, close, _, e := s.archiveOpen(r.Context(), q.Get("id"), q.Get("location"), q.Get("name"))
	if e != nil {
		fail(w, 404, e.Error())
		return
	}
	defer close()
	ctx, cancel := context.WithCancel(r.Context())
	defer cancel()
	cmd := exec.CommandContext(ctx, engine, "-hide_banner", "-loglevel", "error", "-protocol_whitelist", "pipe", "-i", "pipe:0", "-map", "0:v:0", "-map", "0:a?", "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-c:a", "aac", "-movflags", "frag_keyframe+empty_moov", "-f", "mp4", "pipe:1")
	hideProcessWindow(cmd)
	cmd.Stdin = f
	cmd.Stderr = io.Discard
	out, e := cmd.StdoutPipe()
	if e != nil {
		fail(w, 500, "Playback unavailable")
		return
	}
	if e = cmd.Start(); e != nil {
		fail(w, 502, "Cannot start playback")
		return
	}
	defer func() { cancel(); cmd.Wait() }()
	first := make([]byte, 8192)
	n, e := out.Read(first)
	if n == 0 && e != nil {
		fail(w, 502, "Cannot decode recording with selected FFmpeg")
		return
	}
	w.Header().Set("Content-Type", "video/mp4")
	w.Header().Set("Cache-Control", "no-store")
	w.Write(first[:n])
	if flush, ok := w.(http.Flusher); ok {
		flush.Flush()
	}
	io.Copy(w, out)
}
