package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/pem"
	"golang.org/x/crypto/ssh"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestOpenSSHReadsPinnedHostFileInsideDirectoryWithSpaces(t *testing.T) {
	if _, err := exec.LookPath("ssh"); err != nil {
		t.Skip("OpenSSH not installed")
	}
	_, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(private)
	if err != nil {
		t.Fatal(err)
	}
	cfg := &ssh.ServerConfig{PublicKeyCallback: func(_ ssh.ConnMetadata, pub ssh.PublicKey) (*ssh.Permissions, error) { return nil, nil }}
	cfg.AddHostKey(signer)
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	go func() {
		conn, e := ln.Accept()
		if e != nil {
			return
		}
		defer conn.Close()
		sc, channels, requests, e := ssh.NewServerConn(conn, cfg)
		if e != nil {
			return
		}
		defer sc.Close()
		go ssh.DiscardRequests(requests)
		for ch := range channels {
			if ch.ChannelType() != "session" {
				_ = ch.Reject(ssh.UnknownChannelType, "unsupported")
				continue
			}
			channel, reqs, e := ch.Accept()
			if e != nil {
				return
			}
			for req := range reqs {
				if req.Type == "exec" {
					_ = req.Reply(true, nil)
					_, _ = channel.Write([]byte("PINNED_HOST_OK\n"))
					_, _ = channel.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{0}))
					_ = channel.Close()
					break
				} else {
					_ = req.Reply(false, nil)
				}
			}
		}
	}()
	dir := filepath.Join(t.TempDir(), "SSH Server")
	if err = os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	st, err := openStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	block, err := ssh.MarshalPrivateKey(private, "")
	if err != nil {
		t.Fatal(err)
	}
	keyPath := filepath.Join(dir, "id_test")
	if err = os.WriteFile(keyPath, pem.EncodeToMemory(block), 0600); err != nil {
		t.Fatal(err)
	}
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	pnum, _ := strconv.Atoi(port)
	p := Profile{ID: "space-test", Host: "127.0.0.1", Port: pnum, User: "qa", Auth: "key", KeyPath: keyPath, HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))}}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	s := &Server{store: st}
	cmd, err := s.sshCmd(ctx, p, "", false, "printf PINNED_HOST_OK")
	if err != nil {
		t.Fatal(err)
	}
	cmd.Args = append([]string{cmd.Args[0], "-F", nullDevice()}, cmd.Args[1:]...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("Pinned connection with space in data path failed: %v, %s", err, out)
	}
	if !strings.Contains(string(out), "PINNED_HOST_OK") {
		t.Fatal(string(out))
	}
}
func TestCredentialsAreScopedToExactServerIdentity(t *testing.T) {
	s := &Server{}
	p := Profile{ID: "a", Host: "server.test", Port: 22, User: "owner", Auth: "password"}
	if got := s.sshCredential(p, "secret-for-a"); got != "secret-for-a" {
		t.Fatal(got)
	}
	if got := s.sshCredential(p, ""); got != "secret-for-a" {
		t.Fatal("not reused")
	}
	q := p
	q.ID = "b"
	if s.sshCredential(q, "") != "" {
		t.Fatal("credential shared across servers")
	}
	q = p
	q.Host = "changed.test"
	if s.sshCredential(q, "") != "" {
		t.Fatal("credential reused for changed host")
	}
	q = p
	q.User = "other"
	if s.sshCredential(q, "") != "" {
		t.Fatal("credential reused for another user")
	}
	q = p
	q.Auth = "key"
	if s.sshCredential(q, "") != "" {
		t.Fatal("password leaked into key auth")
	}
}
