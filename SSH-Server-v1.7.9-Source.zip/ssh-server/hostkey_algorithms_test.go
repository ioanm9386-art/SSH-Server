package main

import (
	"context"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"golang.org/x/crypto/ssh"
	"net"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestApprovedHostTypesAndRSASignatures(t *testing.T) {
	_, ed, _ := ed25519.GenerateKey(rand.Reader)
	edSigner, _ := ssh.NewSignerFromKey(ed)
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	ecSigner, _ := ssh.NewSignerFromKey(key)
	rsaKey, _ := rsa.GenerateKey(rand.Reader, 2048)
	rsaSigner, _ := ssh.NewSignerFromKey(rsaKey)
	line := func(s ssh.Signer) string {
		return "server.test " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(s.PublicKey())))
	}
	algorithms, e := approvedHostKeyAlgorithms([]string{line(edSigner), line(edSigner), line(ecSigner), line(rsaSigner)})
	if e != nil {
		t.Fatal(e)
	}
	expected := []string{ssh.KeyAlgoED25519, ssh.KeyAlgoECDSA256, ssh.KeyAlgoRSASHA512, ssh.KeyAlgoRSASHA256}
	if strings.Join(algorithms, ",") != strings.Join(expected, ",") {
		t.Fatal(algorithms)
	}
	if _, e = approvedHostKeyAlgorithms(nil); e == nil {
		t.Fatal("Empty pins must not use default unapproved algorithms")
	}
	if _, e = approvedHostKeyAlgorithms([]string{"server.test ssh-ed25519 invalid"}); e == nil {
		t.Fatal("Malformed pin accepted")
	}
}
func TestNativeTerminalRejectsChangedApprovedHostKeyBeforeAuthentication(t *testing.T) {
	_, actual, _ := ed25519.GenerateKey(rand.Reader)
	signer, _ := ssh.NewSignerFromKey(actual)
	_, other, _ := ed25519.GenerateKey(rand.Reader)
	untrustedSigner, _ := ssh.NewSignerFromKey(other)
	var authenticationCalls atomic.Int32
	cfg := &ssh.ServerConfig{PasswordCallback: func(_ ssh.ConnMetadata, _ []byte) (*ssh.Permissions, error) {
		authenticationCalls.Add(1)
		return nil, nil
	}}
	cfg.AddHostKey(signer)
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	defer ln.Close()
	done := make(chan struct{})
	go func() {
		defer close(done)
		conn, e := ln.Accept()
		if e != nil {
			return
		}
		defer conn.Close()
		server, _, _, e := ssh.NewServerConn(conn, cfg)
		if e == nil {
			server.Close()
		}
	}()
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	number, _ := strconv.Atoi(port)
	p := Profile{ID: "changed", Host: "127.0.0.1", Port: number, User: "qa", Auth: "password", HostKeys: []string{"[127.0.0.1]:" + port + " " + strings.TrimSpace(string(ssh.MarshalAuthorizedKey(untrustedSigner.PublicKey())))}}
	st, e := openStore(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	s := &Server{store: st}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	session, e := s.openTerminal(ctx, p, "test-password")
	if e == nil {
		session.closeTransport()
		t.Fatal("Changed key was accepted")
	}
	if !strings.Contains(e.Error(), "knownhosts: key mismatch") {
		t.Fatal(e)
	}
	select {
	case <-done:
	case <-ctx.Done():
		t.Fatal("server handshake did not finish")
	}
	if authenticationCalls.Load() != 0 {
		t.Fatal("Password authentication attempted before validating host identity")
	}
}
