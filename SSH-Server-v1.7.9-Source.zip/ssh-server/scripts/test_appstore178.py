import unittest,sys,json,io,tempfile,socket,subprocess
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent))
import appstore,operations

class AppStoreTests(unittest.TestCase):
 def test_inventory_distinguishes_unknown_from_empty(self):
  with patch.object(appstore,'command',return_value=None),patch.object(appstore,'repositories',return_value=[]):
   data=appstore.collect()
  self.assertFalse(data['packagesKnown']);self.assertFalse(data['updatesKnown']);self.assertFalse(data['dockerAvailable']);self.assertEqual(data['packages'],{});self.assertIn('architecture',data);self.assertGreater(data['disk']['total'],0)
 def test_installed_versions_and_cache_updates_are_real_command_results(self):
  def command(args,*a):
   if args[0]=='dpkg-query':return 'nginx\t1.2-fixture\tinstalled\nremoved\t2\tconfig-files\n'
   if args[0]=='apt':return 'Listing...\nnginx/noble-updates 1.3-fixture amd64 [upgradable from: 1.2-fixture]\n'
   if args[:2]==['docker','ps']:return json.dumps({'Names':'existing','Image':'jellyfin/jellyfin:10','Status':'Up','Labels':'SECRET'})
   return ''
  with patch.object(appstore,'command',side_effect=command),patch.object(appstore,'repositories',return_value=[]):data=appstore.collect()
  self.assertEqual(data['packages'],{'nginx':'1.2-fixture'});self.assertEqual(data['updates'][0]['candidate'],'1.3-fixture');self.assertNotIn('Labels',data['containers'][0])
 def test_repository_credentials_are_not_returned(self):
  text='Types: deb\nURIs: https://user:SUPERSECRET@mirror.example/private\nSuites: noble\nComponents: main universe\nSigned-By: /secret/key\n'
  with patch.object(appstore.glob,'glob',side_effect=lambda p:['test.sources'] if p.endswith('*.sources') else []),patch('builtins.open',side_effect=lambda p,*a,**kw:io.StringIO(text if p=='test.sources' else 'deb https://name:PASS@example.test/private stable main\n')):repos=appstore.repositories()
  self.assertEqual(repos[1]['hosts'],['mirror.example']);self.assertNotIn('SUPERSECRET',json.dumps(repos));self.assertNotIn('PASS',json.dumps(repos));self.assertNotIn('/secret/key',json.dumps(repos))
 def test_package_injection_and_unknown_rejected_before_command(self):
  with patch.object(operations,'run') as run:
   for packages in [['nginx;id'],['unknown'],[['nested']]]:
    with self.assertRaises(ValueError):operations.operation({'action':'package','params':{'packages':packages}})
   run.assert_not_called()
 def test_no_candidate_does_not_install(self):
  with patch.object(operations,'run',return_value='Candidate: (none)'),patch.object(operations.subprocess,'run') as execute:
   with self.assertRaisesRegex(ValueError,'No cached'):operations.operation({'action':'package','params':{'packages':['nginx']}})
   execute.assert_not_called()
 def test_update_requests_only_upgrade_no_remove_and_no_shell(self):
  def run(args):return 'installed' if args[0]=='dpkg-query' else 'Candidate: 1.3'
  with patch.object(operations,'run',side_effect=run),patch.object(operations.subprocess,'run',return_value=subprocess.CompletedProcess([],0,'done','')) as execute:
   operations.operation({'action':'package-upgrade','params':{'packages':['nginx']}})
   args=execute.call_args.args[0];self.assertIn('--only-upgrade',args);self.assertIn('--no-remove',args);self.assertEqual(args[-1],'nginx');self.assertNotIn('shell',execute.call_args.kwargs)
 def test_update_uninstalled_rejected(self):
  with patch.object(operations,'run',side_effect=['Candidate: 1.3','not-installed']),patch.object(operations.subprocess,'run') as execute:
   with self.assertRaisesRegex(ValueError,'already installed'):operations.operation({'action':'package-upgrade','params':{'packages':['nginx']}})
   execute.assert_not_called()
 def test_compose_busy_port_fails_before_container_start_and_cleans_new_folder(self):
  with tempfile.TemporaryDirectory() as tmp,socket.socket() as listener:
   listener.bind(('127.0.0.1',0));listener.listen();port=listener.getsockname()[1]
   config={'services':{'web':{'ports':[{'published':str(port),'host_ip':'127.0.0.1','protocol':'tcp'}]}}}
   with patch.object(operations,'APP_BASE',tmp),patch.object(operations,'run',return_value=json.dumps(config)) as run:
    with self.assertRaisesRegex(ValueError,'already in use'):operations.operation({'action':'compose-deploy','params':{'name':'test','compose':'services: {}'}})
    self.assertEqual(run.call_count,1);self.assertFalse((Path(tmp)/'test').exists())
 def test_compose_existing_project_is_never_overwritten(self):
  with tempfile.TemporaryDirectory() as tmp:
   existing=Path(tmp)/'test';existing.mkdir();(existing/'compose.yaml').write_text('PRESERVE')
   with patch.object(operations,'APP_BASE',tmp),patch.object(operations,'run') as run:
    with self.assertRaisesRegex(ValueError,'already exists'):operations.operation({'action':'compose-deploy','params':{'name':'test','compose':'REPLACE'}})
    run.assert_not_called();self.assertEqual((existing/'compose.yaml').read_text(),'PRESERVE')
if __name__=='__main__':unittest.main()
