package main

import (
	"context"
	"embed"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
)

//go:embed scripts/inventory.py scripts/agent.py scripts/operations.py scripts/ddns.py scripts/energy.py scripts/network.py scripts/ports.py scripts/appstore.py
var adminAssets embed.FS

func pythonCommand(script []byte) string {
	return "python3 -c " + shellQuote("import base64;exec(compile(base64.b64decode('"+base64.StdEncoding.EncodeToString(script)+"'),'<ssh-server>','exec'))")
}
func (s *Server) adminInventory(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		fail(w, 405, "Method not allowed")
		return
	}
	p, ok := s.findProfile(r.URL.Query().Get("id"))
	if !ok {
		fail(w, 404, "Select a server")
		return
	}
	script, _ := adminAssets.ReadFile("scripts/inventory.py")
	ctx, cancel := context.WithTimeout(r.Context(), 70*time.Second)
	defer cancel()
	out, e := s.runNative(ctx, p, r.Header.Get("X-SSH-Password"), pythonCommand(script), "")
	if e != nil {
		fail(w, 502, e.Error()+". Python 3 and standard Linux tools are required.")
		return
	}
	var result any
	if json.Unmarshal(out, &result) != nil {
		fail(w, 502, "Invalid inventory response")
		return
	}
	jsonOut(w, 200, result)
}

type AdminRequest struct {
	ID            string         `json:"id"`
	Action        string         `json:"action"`
	Params        map[string]any `json:"params"`
	OwnerPassword string         `json:"ownerPassword"`
	Code          string         `json:"code"`
	SudoPassword  string         `json:"sudoPassword"`
	Confirmation  string         `json:"confirmation"`
}

var readonlyAdmin = map[string]bool{"agent-state": true, "service-logs": true, "raid-plan": true, "ports-router-state": true}
var rootAdmin = map[string]bool{"agent-install": true, "service": true, "package": true, "package-upgrade": true, "docker-control": true, "compose-deploy": true, "mount": true, "smart": true, "dns-flush": true, "ports-firewall-state": true, "ports-firewall-add": true, "ports-firewall-delete": true}

func validateAdmin(a AdminRequest) error {
	if !readonlyAdmin[a.Action] && !rootAdmin[a.Action] && a.Action != "agent-smtp" && a.Action != "ddns" && a.Action != "ports-router-add" && a.Action != "ports-router-delete" {
		return errors.New("Unsupported operation")
	}
	if !readonlyAdmin[a.Action] && a.Confirmation != "CONFIRM" {
		return errors.New("Review and confirm the operation")
	}
	if strings.ContainsAny(a.SudoPassword, "\r\n") || len(a.SudoPassword) > 4096 {
		return errors.New("Invalid sudo password")
	}
	return nil
}
func (s *Server) adminOperation(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		fail(w, 405, "Method not allowed")
		return
	}
	var a AdminRequest
	if body(r, &a) != nil {
		fail(w, 400, "Invalid request")
		return
	}
	if e := validateAdmin(a); e != nil {
		fail(w, 400, e.Error())
		return
	}
	p, ok := s.findProfile(a.ID)
	if !ok {
		fail(w, 404, "Server not found")
		return
	}
	if !readonlyAdmin[a.Action] && !ownerVerified(s.store.snapshot().Owner, a.OwnerPassword, a.Code) {
		fail(w, 403, "Owner password or TOTP code is incorrect")
		return
	}
	payload := map[string]any{"action": a.Action, "params": a.Params}
	if strings.HasPrefix(a.Action, "ports-") {
		if a.Params == nil {
			a.Params = map[string]any{}
		}
		a.Params["sshPort"] = p.Port
		payload["params"] = a.Params
	}
	if a.Action == "agent-install" {
		files := map[string]string{}
		for _, name := range []string{"inventory.py", "agent.py", "ddns.py"} {
			raw, _ := adminAssets.ReadFile("scripts/" + name)
			files[name] = base64.StdEncoding.EncodeToString(raw)
		}
		payload["files"] = files
	}
	input, _ := json.Marshal(payload)
	script, _ := adminAssets.ReadFile("scripts/operations.py")
	if strings.HasPrefix(a.Action, "ports-") {
		script, _ = adminAssets.ReadFile("scripts/ports.py")
	}
	command := pythonCommand(script)
	stdin := string(input)
	if rootAdmin[a.Action] {
		if a.SudoPassword != "" {
			command = "sudo -S -p '' -- " + command
			stdin = a.SudoPassword + "\n" + stdin
		} else {
			command = "sudo -n -- " + command
		}
	}
	ctx, cancel := context.WithTimeout(r.Context(), 12*time.Minute)
	defer cancel()
	out, e := s.runNative(ctx, p, "", command, stdin)
	var result struct {
		OK     bool            `json:"ok"`
		Error  string          `json:"error"`
		Result json.RawMessage `json:"result"`
	}
	if json.Unmarshal(out, &result) != nil {
		if e != nil {
			fail(w, 502, e.Error())
		} else {
			fail(w, 502, "Invalid operation response")
		}
		return
	}
	if !result.OK {
		fail(w, 422, result.Error)
		return
	}
	if a.Action == "agent-install" {
		s.store.mu.Lock()
		for i := range s.store.data.Profiles {
			if s.store.data.Profiles[i].ID == p.ID {
				s.store.data.Profiles[i].AgentInstalled = true
			}
		}
		_ = s.store.saveLocked()
		s.store.mu.Unlock()
	}
	if !readonlyAdmin[a.Action] {
		s.store.log("admin_"+a.Action, p.Name+" — confirmed operation completed; secrets and command content are not logged", "info")
	}
	jsonOut(w, 200, map[string]any{"ok": true, "result": result.Result})
}
func adminCapability(w http.ResponseWriter, r *http.Request) {
	jsonOut(w, 200, map[string]any{"version": "1.7.9", "manualPorts": true, "ufwRules": true, "routerUPnP": true, "inventory": true, "agent": true, "smtp": true, "ddns": true, "services": true, "packages": true, "compose": true, "mountExisting": true, "raidPreview": true, "raidExecution": false, "formatting": false, "networkApply": false, "routerAutomation": false, "note": fmt.Sprint("Destructive storage and network changes require an independently validated recovery environment.")})
}
