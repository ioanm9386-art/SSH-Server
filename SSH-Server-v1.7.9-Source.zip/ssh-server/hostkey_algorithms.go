package main

import (
	"errors"
	"golang.org/x/crypto/ssh"
	"strings"
)

// The transport must negotiate one of the host-key types already approved for
// this profile. This does not approve new keys: knownhosts.New still compares
// the exact public key and host/port during the SSH handshake.
func approvedHostKeyAlgorithms(lines []string) ([]string, error) {
	algorithms := []string{}
	seen := map[string]bool{}
	for _, line := range lines {
		fields := strings.Fields(line)
		if len(fields) != 3 {
			return nil, errors.New("Invalid approved SSH host key")
		}
		key, _, _, _, err := ssh.ParseAuthorizedKey([]byte(fields[1] + " " + fields[2]))
		if err != nil {
			return nil, errors.New("Cannot decode the approved SSH host key")
		}
		types := []string{key.Type()}
		// ssh-rsa is the key format. Negotiate modern RSA SHA-2 signatures, without
		// silently enabling the obsolete RSA/SHA-1 signature algorithm.
		if key.Type() == ssh.KeyAlgoRSA {
			types = []string{ssh.KeyAlgoRSASHA512, ssh.KeyAlgoRSASHA256}
		}
		for _, algorithm := range types {
			if !seen[algorithm] {
				seen[algorithm] = true
				algorithms = append(algorithms, algorithm)
			}
		}
	}
	if len(algorithms) == 0 {
		return nil, errors.New("Verify and approve the SSH host fingerprint before connecting")
	}
	return algorithms, nil
}
