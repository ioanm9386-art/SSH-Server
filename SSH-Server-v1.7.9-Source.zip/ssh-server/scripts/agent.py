#!/usr/bin/env python3
import os,json,time,ssl,smtplib,sys
from email.message import EmailMessage
from inventory import collect,read
BASE='/var/lib/ssh-server-agent'

def alerts_for(s,previous=None):
    out=[]
    def add(key,severity,title,detail):out.append({'key':key,'severity':severity,'title':title,'detail':detail})
    if previous:
        total=s.get('cpuTotal',0)-previous.get('cpuTotal',0);idle=s.get('cpuIdle',0)-previous.get('cpuIdle',0)
        if total>0 and 100*(1-idle/total)>=95:add('cpu','warning','CPU utilization above 95%','Inspect running processes before stopping anything.')
    total=s.get('memoryTotal',0)
    if total and 100*(1-s.get('memoryAvailable',0)/total)>=95:add('memory','warning','Memory utilization above 95%','Inspect memory usage and swap.')
    for a in s.get('raid',[]):
        if str(a.get('degraded','')).isdigit() and int(a['degraded'])>0:add('raid:'+a['name'],'critical','Degraded RAID '+a['name'],'Check member disks and backup. Do not initialize or format the array.')
    def mounts(items):
        for m in items:
            try:
                usage=int(str(m.get('use%',0)).rstrip('%'))
                if usage>=90 and m.get('fstype') not in ('tmpfs','devtmpfs','squashfs','overlay'):add('disk:'+m['target'],'critical' if usage>=98 else 'warning','Low disk space: '+m['target'],str(usage)+'% used. Review files and backups before deleting anything.')
            except (ValueError,KeyError):pass
            mounts(m.get('children',[]))
    if isinstance(s.get('mounts'),dict):mounts(s['mounts'].get('filesystems',[]))
    for x in s.get('smart',[]):
        if x.get('result',{}).get('smart_status',{}).get('passed') is False:add('smart:'+x['device'],'critical','Disk SMART health failed: '+x['device'],'Back up important data and inspect the disk. A successful RAID status does not replace this check.')
    services=s.get('services','')
    if isinstance(services,str):
        for line in services.splitlines():
            f=line.split()
            if len(f)>3 and f[2]=='failed':add('service:'+f[0],'warning','Service failed: '+f[0],'Inspect service logs before restarting.')
    for c in s.get('containers',[]):
        if 'unhealthy' in c.get('Status','').lower() or 'restarting' in c.get('Status','').lower():add('container:'+c.get('Names',''),'warning','Container needs attention: '+c.get('Names',''),'Inspect the container logs and health check.')
    return out

def load(name,default):
    try:
        with open(BASE+'/'+name) as f:return json.load(f)
    except (OSError,ValueError):return default

def save(name,value):
    tmp=BASE+'/'+name+'.tmp'
    with open(tmp,'w') as f:json.dump(value,f)
    os.chmod(tmp,0o600);os.replace(tmp,BASE+'/'+name)

def mail(config,subject,text):
    c=config.get('smtp',{})
    if not c.get('enabled'):return
    msg=EmailMessage();msg['From']=c['from'];msg['To']=c['to'];msg['Subject']='SSH Server: '+subject;msg.set_content(text)
    context=ssl.create_default_context()
    if c.get('mode')=='tls':server=smtplib.SMTP_SSL(c['host'],int(c.get('port',465)),timeout=15,context=context)
    else:
        server=smtplib.SMTP(c['host'],int(c.get('port',587)),timeout=15);server.ehlo();server.starttls(context=context);server.ehlo()
    try:
        if c.get('username'):server.login(c['username'],c.get('password',''))
        server.send_message(msg)
    finally:server.quit()

def once(previous=None):
    snapshot=collect();now=int(time.time());state=load('state.json',{'alerts':[]});old={x['key']:x for x in state.get('alerts',[]) if x.get('active')};active=alerts_for(snapshot,previous);new=[];config=load('config.json',{});mailerror=''
    for a in active:
        prev=old.get(a['key']);a.update({'firstSeen':prev.get('firstSeen',now) if prev else now,'lastSeen':now,'active':True,'acknowledged':prev.get('acknowledged',False) if prev else False})
        if not prev:
            try:mail(config,a['title'],a['detail']+'\nServer: '+snapshot['hostname'])
            except Exception:mailerror='Email delivery failed. Check SMTP settings and credentials.'
        new.append(a)
    for key,a in old.items():
        if not any(x['key']==key for x in active):
            a.update({'active':False,'resolvedAt':now});new.append(a)
            try:mail(config,'Resolved: '+a['title'],'The condition is no longer detected on '+snapshot['hostname'])
            except Exception:mailerror='Email recovery notification failed.'
    past=[a for a in state.get('alerts',[]) if not a.get('active') and a.get('resolvedAt',0)>now-30*86400]
    ddns_state=state.get('ddns',{'status':'Not configured'})
    if config.get('ddns',{}).get('enabled') and now-ddns_state.get('at',0)>=300:
        try:
            from ddns import update
            ddns_state={'at':now,'status':update(config['ddns'])}
        except Exception:ddns_state={'at':now,'status':'Update failed; check DDNS settings'}
    state={'ddns':ddns_state,'at':now,'hostname':snapshot['hostname'],'alerts':(new+past)[:500],'emailError':mailerror,'inventory':snapshot,'version':'1.7.2'};save('state.json',state);return snapshot
if __name__=='__main__':
    os.umask(0o077);previous=None
    while True:
        try:previous=once(previous)
        except Exception as e:print('Monitoring cycle failed: '+type(e).__name__,file=sys.stderr,flush=True)
        time.sleep(60)
