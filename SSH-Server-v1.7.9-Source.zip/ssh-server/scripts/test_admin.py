import unittest,sys,os,tempfile,json,importlib.util,subprocess
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent))
import agent,operations,ddns,inventory
class AdminTests(unittest.TestCase):
 def test_real_inventory_read_only(self):
  data=inventory.collect();self.assertIn('disks',data);self.assertIn('raid',data);self.assertIn('interfaces',data);self.assertNotIn('netplanRaw',data)
 def test_missing_smart_not_reported_healthy(self):
  self.assertEqual(agent.alerts_for({'smart':[{'device':'/dev/sda','result':{'available':False}}]}),[])
 def test_faults_and_recovery_are_persisted_without_email_spam(self):
  with tempfile.TemporaryDirectory() as folder,patch.object(agent,'BASE',folder),patch.object(agent,'mail') as mail:
   sample={'hostname':'qa','cpuTotal':100,'cpuIdle':50,'raid':[{'name':'md0','degraded':'1'}],'smart':[]}
   with patch.object(agent,'collect',return_value=sample):agent.once();agent.once()
   self.assertEqual(mail.call_count,1)
   with patch.object(agent,'collect',return_value={'hostname':'qa','raid':[]}):agent.once()
   self.assertEqual(mail.call_count,2)
   saved=agent.load('state.json',{});self.assertTrue(any(not a['active'] for a in saved['alerts']))
 def test_smart_disk_and_array_faults(self):
  out=agent.alerts_for({'smart':[{'device':'/dev/sdb','result':{'smart_status':{'passed':False}}}],'raid':[{'name':'md0','degraded':'1'}]})
  self.assertEqual({a['key'] for a in out},{'raid:md0','smart:/dev/sdb'})
 def test_mount_fails_before_any_command_for_path_injection(self):
  with patch.object(operations,'run') as run:
   with self.assertRaises(ValueError):operations.operation({'action':'mount','params':{'uuid':'uuid-test','target':'/mnt/../../etc'}})
   run.assert_not_called()
 def test_critical_service_blocked(self):
  with patch.object(operations,'run') as run:
   for name in ('ssh.service','networking.service','tailscaled.service','wg-quick@wg0.service'):
    with self.assertRaises(ValueError):operations.operation({'action':'service','params':{'name':name,'verb':'stop'}})
   run.assert_not_called()
 def test_package_allowlist(self):
  with patch.object(operations,'run') as run:
   with self.assertRaises(ValueError):operations.operation({'action':'package','params':{'packages':['; rm -rf /']}})
   run.assert_not_called()
 def test_raid_preview_rejects_existing_filesystem(self):
  layout={'blockdevices':[{'path':'/dev/sdb','type':'disk','size':100,'fstype':'ext4'},{'path':'/dev/sdc','type':'disk','size':100}]}
  with patch.object(operations,'run',return_value=json.dumps(layout)):
   with self.assertRaises(ValueError):operations.operation({'action':'raid-plan','params':{'level':'1','devices':['/dev/sdb','/dev/sdc']}})
 def test_raid_calculation_and_never_executes_mdadm(self):
  layout={'blockdevices':[{'path':'/dev/sd'+c,'type':'disk','size':100,'serial':c} for c in 'bcde']}
  with patch.object(operations,'run',return_value=json.dumps(layout)) as run:
   for level,capacity in [('1',100),('5',300),('6',200),('10',200)]:
    r=operations.operation({'action':'raid-plan','params':{'level':level,'devices':['/dev/sd'+c for c in 'bcde']}});self.assertTrue(r['planOnly']);self.assertEqual(r['usableBytes'],capacity)
   for call in run.call_args_list:self.assertEqual(call.args[0][0],'lsblk')
 def test_ddns_uses_only_provider_https_and_redacts_errors(self):
  with patch('urllib.request.urlopen',side_effect=OSError('secret-token')) as request:
   with self.assertRaisesRegex(ValueError,'DDNS request failed'):ddns.update({'provider':'duckdns','hostname':'demo.duckdns.org','token':'secret-token'})
   self.assertTrue(request.call_args.args[0].full_url.startswith('https://www.duckdns.org/update?'))
 def test_shell_names_cannot_inject_commands(self):
  with self.assertRaises(ValueError):operations.operation({'action':'docker-control','params':{'name':'test;id','verb':'restart'}})
if __name__=='__main__':unittest.main()
