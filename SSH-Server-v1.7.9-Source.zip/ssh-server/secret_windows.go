//go:build windows

package main

import (
	"encoding/base64"
	"errors"
	"os/exec"
	"syscall"
	"unsafe"
)

type dataBlob struct {
	Length uint32
	Data   *byte
}

var crypt32 = syscall.NewLazyDLL("crypt32.dll")
var protect = crypt32.NewProc("CryptProtectData")
var unprotect = crypt32.NewProc("CryptUnprotectData")
var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var localFree = kernel32.NewProc("LocalFree")

func dpapi(input []byte, encrypt bool) ([]byte, error) {
	if len(input) == 0 {
		return nil, errors.New("empty secret")
	}
	in := dataBlob{Length: uint32(len(input)), Data: &input[0]}
	var out dataBlob
	proc := unprotect
	if encrypt {
		proc = protect
	}
	ret, _, err := proc.Call(uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 0, uintptr(unsafe.Pointer(&out)))
	if ret == 0 {
		return nil, err
	}
	defer localFree.Call(uintptr(unsafe.Pointer(out.Data)))
	res := make([]byte, out.Length)
	copy(res, unsafe.Slice(out.Data, out.Length))
	return res, nil
}
func encryptSecret(s string) (string, error) {
	b, e := dpapi([]byte(s), true)
	if e != nil {
		return "", e
	}
	return "dpapi:" + base64.StdEncoding.EncodeToString(b), nil
}
func decryptSecret(s string) (string, error) {
	if len(s) < 6 || s[:6] != "dpapi:" {
		return "", errors.New("unsupported encoding")
	}
	b, e := base64.StdEncoding.DecodeString(s[6:])
	if e != nil {
		return "", e
	}
	res, e := dpapi(b, false)
	return string(res), e
}
func hideProcessWindow(c *exec.Cmd) { c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true} }
