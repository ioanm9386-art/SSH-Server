import json,sys,os,re,ipaddress,subprocess,secrets,time,fcntl,stat
from contextlib import contextmanager
PREFIX='SSHServer-'
IDENT=re.compile(r'^SSHServer-[0-9a-f]{16}$')

def run(args):
    result=subprocess.run(args,capture_output=True,text=True,timeout=25,env={**os.environ,'LC_ALL':'C'})
    if result.returncode:raise ValueError((result.stderr or result.stdout)[-1200:] or 'Command failed')
    return result.stdout

def port(value):
    if isinstance(value,bool):raise ValueError('Invalid port')
    text=str(value)
    if not re.fullmatch(r'[0-9]{1,5}',text) or not 1<=int(text)<=65535:raise ValueError('Port must be 1–65535')
    return int(text)
def protocols(value):
    if value=='both':return ['tcp','udp']
    if value in ('tcp','udp'):return [value]
    raise ValueError('Choose TCP, UDP or both')
def source(value):
    if value in ('','any',None):return 'any'
    return str(ipaddress.ip_network(value,strict=False))
@contextmanager
def exclusive():
    path='/tmp/ssh-server-ports-'+str(os.geteuid())+'.lock'
    fd=os.open(path,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    try:
        meta=os.fstat(fd)
        if meta.st_uid!=os.geteuid() or not stat.S_ISREG(meta.st_mode) or meta.st_nlink!=1:raise ValueError('Unsafe lock file')
        fcntl.flock(fd,fcntl.LOCK_EX);yield
    finally:os.close(fd)
def parse_fw(text):
    rows=[]
    for line in text.splitlines():
        m=re.match(r'^\[\s*(\d+)\]\s*(.*?)\s+#\s*(SSHServer-[0-9a-f]{16})\s*$',line.strip())
        if m:
            rule=m[2];p=re.search(r'^(\d+)/(tcp|udp)\b',rule)
            if p:rows.append({'number':int(m[1]),'id':m[3],'port':int(p[1]),'protocol':p[2],'raw':rule,'action':'deny' if re.search(r'\bDENY\b',rule) else 'allow'})
    return rows
def firewall_state():
    text=run(['ufw','status','numbered']);return {'active':bool(re.search(r'^Status: active$',text,re.M)),'rules':parse_fw(text),'raw':text}
def protected(p):
    values={22,port(p.get('sshPort',22))}
    text=run(['ss','-H','-lntup'])
    for line in text.splitlines():
        if any(name in line.lower() for name in ['sshd','dropbear','tailscaled','openvpn','wireguard']):
            fields=line.split()
            try:values.add(port(fields[4].rsplit(':',1)[-1]))
            except (ValueError,IndexError):pass
    # Common VPN listeners and dynamic WireGuard ports.
    values.update([41641,51820,1194])
    try:
        for line in run(['wg','show','all','listen-port']).splitlines():values.add(port(line.split()[-1]))
    except (OSError,ValueError):pass
    return values

def remove_fw(label):
    if not IDENT.fullmatch(label):raise ValueError('Invalid managed rule ID')
    changed=0
    while True:
        rows=[x for x in firewall_state()['rules'] if x['id']==label]
        if not rows:break
        number=max(x['number'] for x in rows)
        run(['ufw','--force','delete',str(number)]);changed+=1
        if changed>4:raise ValueError('Unexpected number of matching rules; stop and review UFW')
    return changed

def firewall(action,p):
    if os.geteuid()!=0:raise ValueError('sudo required for UFW')
    state=firewall_state()
    if action=='state':return state
    if not state['active']:raise ValueError('UFW is inactive. This app does not enable/reset it automatically.')
    reserved=protected(p)
    if action=='delete':
        label=p.get('ruleId','');rows=[x for x in state['rules'] if x['id']==label]
        if not rows:raise ValueError('Managed rule no longer exists')
        if any(x['port'] in reserved for x in rows):raise ValueError('SSH/VPN management ports are protected')
        remove_fw(label);return firewall_state()
    number=port(p.get('port'));protos=protocols(p.get('protocol'));verb=p.get('verb');origin=source(p.get('source'))
    if verb not in ('allow','deny'):raise ValueError('Choose Allow or Block')
    if number in reserved:raise ValueError('SSH/VPN management ports are protected; other ports can be entered manually')
    for line in state['raw'].splitlines():
        existing=re.match(r'^\[\s*\d+\]\s*(\d+)/(tcp|udp)\b',line.strip())
        if existing and int(existing[1])==number and existing[2] in protos:raise ValueError('This port already has a UFW rule. Existing rules are not overwritten; remove only an owned rule before replacing it.')
    label=PREFIX+secrets.token_hex(8)
    try:
        for proto in protos:
            run(['ufw','insert','1',verb,'in','proto',proto,'from',origin,'to','any','port',str(number),'comment',label])
        final=firewall_state();found=[x for x in final['rules'] if x['id']==label]
        if not all(any(x['protocol']==proto and x['port']==number for x in found) for proto in protos):raise ValueError('New UFW rule could not be verified')
        final['createdId']=label;final['note']='Rule inserted at the top of UFW user rules. Listening services, Docker chains and upstream filters are separate.';return final
    except Exception as e:
        try:remove_fw(label)
        except Exception as rollback:raise ValueError('Operation failed; rollback incomplete. Inspect UFW immediately: '+str(rollback)) from e
        raise

def local_ips():
    data=json.loads(run(['ip','-j','-4','address','show']))
    return sorted({a['local'] for item in data for a in item.get('addr_info',[]) if a.get('family')=='inet' and not ipaddress.ip_address(a['local']).is_loopback})
def parse_router(text):
    rows=[]
    for line in text.splitlines():
        m=re.match(r"^\s*\d+\s+(TCP|UDP)\s+(\d+)->([0-9.]+):(\d+)\s+'([^']*)'\s+'([^']*)'\s+(\d+)",line)
        if m:rows.append({'protocol':m[1].lower(),'externalPort':int(m[2]),'internalIP':m[3],'internalPort':int(m[4]),'description':m[5],'remoteHost':m[6],'lease':int(m[7]),'managed':bool(IDENT.fullmatch(m[5]))})
    gateway=re.search(r'Found valid IGD\s*:\s*(\S+)',text)
    public=re.search(r'ExternalIPAddress\s*=\s*([0-9.]+)',text)
    devices=re.findall(r'^\s*desc:\s*(\S+)',text,re.M)
    return {'gateway':gateway[1] if gateway else '', 'externalIP':public[1] if public else '', 'rules':rows,'deviceCount':len(set(devices)), 'raw':text}
def router_state(ip):
    if ip not in local_ips():raise ValueError('Select an IPv4 address actually assigned to the Linux server')
    data=parse_router(run(['upnpc','-m',ip,'-l']))
    if not data['gateway']:raise ValueError('No compatible connected UPnP gateway found; use the manual router form')
    return data

def remove_router(ip,entry):
    if entry.get('remoteHost'):raise ValueError('Mapping source restriction changed; refusing deletion')
    current=router_state(ip)
    owned=[x for x in current['rules'] if x['externalPort']==entry['externalPort'] and x['protocol']==entry['protocol'] and x['description']==entry['description'] and x['internalIP']==ip and x['internalPort']==entry['internalPort']]
    if not owned:raise ValueError('Router rule changed; refusing deletion')
    run(['upnpc','-m',ip,'-d',str(entry['externalPort']),entry['protocol'].upper()])

def router(action,p):
    ip=str(ipaddress.IPv4Address(p.get('internalIP','')))
    state=router_state(ip)
    if action=='state':return state
    if state['deviceCount']>1:raise ValueError('Multiple UPnP devices found; use manual router configuration')
    if action=='delete':
        label=p.get('ruleId','');proto=protocols(p.get('protocol'))
        if not IDENT.fullmatch(label):raise ValueError('Only SSH Server mappings can be removed')
        rows=[x for x in state['rules'] if x['description']==label and x['protocol'] in proto and x['internalIP']==ip]
        if not rows:raise ValueError('Managed mapping no longer exists')
        if any(x['externalPort']==port(p.get('sshPort',22)) for x in rows):raise ValueError('Current SSH access port is protected')
        for entry in rows:remove_router(ip,entry)
        final=router_state(ip)
        if any(x['description']==label and x['protocol'] in proto for x in final['rules']):raise ValueError('Router did not confirm mapping deletion')
        return final
    external=port(p.get('externalPort'));internal=port(p.get('internalPort'));protos=protocols(p.get('protocol'));lease=int(p.get('lease',3600))
    if lease<60 or lease>86400:raise ValueError('Lease must be 60–86400 seconds')
    if any(x['externalPort']==external and x['protocol'] in protos for x in state['rules']):raise ValueError('External port already mapped. Existing mappings are never overwritten.')
    label=PREFIX+secrets.token_hex(8);created=[]
    try:
        for proto in protos:
            run(['upnpc','-m',ip,'-e',label,'-a',ip,str(internal),str(external),proto.upper(),str(lease)])
            final=router_state(ip)
            matching=[x for x in final['rules'] if x['externalPort']==external and x['protocol']==proto and x['description']==label and x['internalIP']==ip and x['internalPort']==internal]
            if not matching:raise ValueError('Gateway did not confirm the new mapping. Check it before retrying.')
            if final['gateway']!=state['gateway']:raise ValueError('Gateway changed during application; check router mappings')
            if any(x['lease']<=0 or x['lease']>lease+5 for x in matching):raise ValueError('Gateway ignored the requested expiry; removing the mapping')
            created.extend(matching)
        final['createdId']=label;final['note']='Router mapping verified; Internet reachability is not verified. CGNAT/double NAT and server firewall may still block access.';return final
    except Exception as e:
        # Include mappings created even when verification failed midway.
        try:
            for entry in router_state(ip)['rules']:
                if entry['description']==label and entry['internalIP']==ip:remove_router(ip,entry)
        except Exception as rollback:raise ValueError('Mapping failed; rollback incomplete. Inspect router mappings: '+str(rollback)) from e
        raise

def operation(a):
    action=a.get('action','');p=a.get('params',{})
    with exclusive():
        if action.startswith('ports-firewall-'):return firewall(action.removeprefix('ports-firewall-'),p)
        if action.startswith('ports-router-'):return router(action.removeprefix('ports-router-'),p)
        raise ValueError('Unsupported port operation')
if __name__=='__main__':
    try:print(json.dumps({'ok':True,'result':operation(json.load(sys.stdin))}))
    except Exception as e:print(json.dumps({'ok':False,'error':str(e)[:1800]}));sys.exit(1)
