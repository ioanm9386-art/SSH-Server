# SSH Server v1.7.3 — Windows Files test

Read README-v1.7.3-FILES-RO.md for the new Files page, update instructions, verified scope and limitations. This release focuses on Files; the remaining requested pages are unchanged.

# SSH Server v1.7.2 — Windows test build

See [README-v1.7.2-RO.md](README-v1.7.2-RO.md) for implemented scope, installation and limitations. This build does not yet implement the complete roadmap.

# SSH Server

Version 1.7.1 Windows desktop hotfix. The product name and application ID remain
SSH Server. Existing user data is preserved outside the installation directory.

This release introduces a native Go SSH PTY terminal with xterm.js 6.0, scoped
clipboard IPC, absolute remote paths, per-server directory history, mounted
storage selection and remembered starting folders. It preserves LiveCam beta.
See RELEASE-v1.7.1-RO.txt for the host-key negotiation fix and RELEASE-v1.7-RO.txt for the previous feature guide.

Build requirements: Go 1.26+, Node.js/npm. Run desktop/BUILD-WINDOWS.ps1.
Backend checks: go test -race ./... && go vet ./...
Desktop checks: cd desktop && npm ci && npm run check
DOM checks: cd tests && npm install && npm test

The xterm browser assets are vendored in web/vendor with their MIT licenses;
their pinned build packages are declared in desktop/package.json.
The terminal uses golang.org/x/crypto/ssh with approved known_hosts verification.
File operations and monitoring still require Windows OpenSSH. The UI uses
Electron with a sandboxed renderer, no Node integration and restricted clipboard
IPC to the trusted local main frame. SSH passwords remain in process memory.

RAID access uses actual Linux mount points and normal SSH-user permissions.
The application does not configure, format, mount or repair disks.
LiveCam beta requires optional external FFmpeg; universal vendor compatibility,
ONVIF discovery, Android APK and remote Web/iOS are not claimed or shipped.

License: AGPL-3.0-or-later. See COPYING and dependency licenses.
