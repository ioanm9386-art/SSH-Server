package main

import (
	"bytes"
	"context"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const deviceNS179 = "http://www.onvif.org/ver10/device/wsdl"
const mediaNS179 = "http://www.onvif.org/ver10/media/wsdl"
const media2NS179 = "http://www.onvif.org/ver20/media/wsdl"

type xmlNode179 struct {
	Name     string
	Text     string
	Attrs    map[string]string
	Children []*xmlNode179
}

func parseXML179(raw []byte) (*xmlNode179, error) {
	d := xml.NewDecoder(bytes.NewReader(raw))
	root := &xmlNode179{}
	stack := []*xmlNode179{root}
	count := 0
	for {
		t, e := d.Token()
		if e == io.EOF {
			break
		}
		if e != nil {
			return nil, errors.New("Invalid ONVIF XML response")
		}
		switch x := t.(type) {
		case xml.StartElement:
			count++
			if count > 10000 || len(stack) > 64 {
				return nil, errors.New("ONVIF response exceeds XML limits")
			}
			n := &xmlNode179{Name: x.Name.Local, Attrs: map[string]string{}}
			for _, a := range x.Attr {
				n.Attrs[a.Name.Local] = a.Value
			}
			p := stack[len(stack)-1]
			p.Children = append(p.Children, n)
			stack = append(stack, n)
		case xml.CharData:
			p := stack[len(stack)-1]
			p.Text += string(x)
		case xml.EndElement:
			if len(stack) < 2 {
				return nil, errors.New("Invalid ONVIF XML")
			}
			stack = stack[:len(stack)-1]
		}
	}
	if len(stack) != 1 {
		return nil, errors.New("Incomplete ONVIF XML")
	}
	return root, nil
}
func (n *xmlNode179) all(name string) (out []*xmlNode179) {
	if n.Name == name {
		out = append(out, n)
	}
	for _, c := range n.Children {
		out = append(out, c.all(name)...)
	}
	return
}
func (n *xmlNode179) first(name string) *xmlNode179 {
	if n == nil {
		return nil
	}
	if n.Name == name {
		return n
	}
	for _, c := range n.Children {
		if f := c.first(name); f != nil {
			return f
		}
	}
	return nil
}
func (n *xmlNode179) value(name string) string {
	f := n.first(name)
	if f == nil {
		return ""
	}
	return strings.TrimSpace(f.Text)
}
func xmlEscape179(s string) string {
	var b bytes.Buffer
	_ = xml.EscapeText(&b, []byte(s))
	return b.String()
}
func wsSecurity179(user, password string, at time.Time) string {
	if user == "" {
		return ""
	}
	nonce := make([]byte, 20)
	_, _ = rand.Read(nonce)
	created := at.UTC().Format(time.RFC3339Nano)
	h := sha1.New()
	h.Write(nonce)
	h.Write([]byte(created))
	h.Write([]byte(password))
	digest := base64.StdEncoding.EncodeToString(h.Sum(nil))
	return `<wsse:Security s:mustUnderstand="true" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"><wsse:UsernameToken><wsse:Username>` + xmlEscape179(user) + `</wsse:Username><wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">` + digest + `</wsse:Password><wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">` + base64.StdEncoding.EncodeToString(nonce) + `</wsse:Nonce><wsu:Created>` + created + `</wsu:Created></wsse:UsernameToken></wsse:Security>`
}
func digestAuth179(challenge, method, uri, user, password string) (string, error) {
	if len(challenge) > 8192 || !strings.HasPrefix(strings.ToLower(challenge), "digest ") {
		return "", errors.New("Unsupported HTTP authentication")
	}
	fields := map[string]string{}
	re := regexp.MustCompile(`([A-Za-z][A-Za-z0-9_-]*)\s*=\s*("(?:[^"\\]|\\.)*"|[^,\s]+)`)
	for _, m := range re.FindAllStringSubmatch(challenge[7:], -1) {
		v := m[2]
		if strings.HasPrefix(v, `"`) {
			var e error
			v, e = strconv.Unquote(v)
			if e != nil {
				return "", errors.New("Invalid digest challenge")
			}
		}
		fields[strings.ToLower(m[1])] = v
	}
	realm, nonce := fields["realm"], fields["nonce"]
	if nonce == "" {
		return "", errors.New("Missing digest nonce")
	}
	algorithm := strings.ToUpper(fields["algorithm"])
	if algorithm == "" {
		algorithm = "MD5"
	}
	session := strings.HasSuffix(algorithm, "-SESS")
	base := strings.TrimSuffix(algorithm, "-SESS")
	hash := func(s string) string {
		if base == "SHA-256" {
			v := sha256.Sum256([]byte(s))
			return hex.EncodeToString(v[:])
		}
		v := md5.Sum([]byte(s))
		return hex.EncodeToString(v[:])
	}
	if base != "MD5" && base != "SHA-256" {
		return "", errors.New("Unsupported device digest algorithm")
	}
	qop := ""
	if fields["qop"] != "" {
		for _, p := range strings.Split(fields["qop"], ",") {
			if strings.TrimSpace(p) == "auth" {
				qop = "auth"
			}
		}
		if qop == "" {
			return "", errors.New("Device requires unsupported digest qop")
		}
	}
	cnonce := randHex(16)
	ha1 := hash(user + ":" + realm + ":" + password)
	if session {
		ha1 = hash(ha1 + ":" + nonce + ":" + cnonce)
	}
	ha2 := hash(method + ":" + uri)
	response := hash(ha1 + ":" + nonce + ":" + ha2)
	if qop != "" {
		response = hash(ha1 + ":" + nonce + ":00000001:" + cnonce + ":" + qop + ":" + ha2)
	}
	quote := func(s string) string { return `"` + strings.NewReplacer(`\`, `\\`, `"`, `\"`).Replace(s) + `"` }
	out := `Digest username=` + quote(user) + `, realm=` + quote(realm) + `, nonce=` + quote(nonce) + `, uri=` + quote(uri) + `, response=` + quote(response) + `, algorithm=` + algorithm
	if qop != "" {
		out += `, qop=auth, nc=00000001, cnonce=` + quote(cnonce)
	} else if session {
		out += `, cnonce=` + quote(cnonce)
	}
	if fields["opaque"] != "" {
		out += `, opaque=` + quote(fields["opaque"])
	}
	return out, nil
}

type onvifClient179 struct {
	http   *http.Client
	conn   CameraConnection179
	offset time.Duration
}

func newONVIF179(c CameraConnection179) *onvifClient179 {
	t := &http.Transport{Proxy: nil, DialContext: (&net.Dialer{Timeout: 6 * time.Second}).DialContext, TLSHandshakeTimeout: 6 * time.Second, ResponseHeaderTimeout: 8 * time.Second, MaxResponseHeaderBytes: 32768, DisableKeepAlives: true}
	return &onvifClient179{http: &http.Client{Timeout: 10 * time.Second, Transport: t, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}, conn: c}
}
func sameDeviceEndpoint179(raw string, c CameraConnection179) (string, error) {
	u, e := url.Parse(raw)
	if e != nil || u.User != nil || u.Fragment != "" || u.Hostname() == "" || u.Scheme != "http" && u.Scheme != "https" {
		return "", errors.New("Invalid ONVIF service endpoint")
	}
	if !strings.EqualFold(u.Hostname(), c.Host) {
		return "", errors.New("ONVIF returned another host. Credentials were not forwarded; use the correct device endpoint")
	}
	if c.HTTPS && u.Scheme != "https" {
		return "", errors.New("ONVIF attempted an HTTPS downgrade")
	}
	return u.String(), nil
}
func (c *onvifClient179) soap(ctx context.Context, endpoint, namespace, operation, inside string, authenticated bool) (*xmlNode179, error) {
	endpoint, e := sameDeviceEndpoint179(endpoint, c.conn)
	if e != nil {
		return nil, e
	}
	header := ""
	if authenticated {
		header = wsSecurity179(c.conn.Username, c.conn.Password, time.Now().Add(c.offset))
	}
	payload := `<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:tt="http://www.onvif.org/ver10/schema"><s:Header>` + header + `</s:Header><s:Body><m:` + operation + ` xmlns:m="` + namespace + `">` + inside + `</m:` + operation + `></s:Body></s:Envelope>`
	authorization := ""
	for attempt := 0; attempt < 2; attempt++ {
		req, e := http.NewRequestWithContext(ctx, "POST", endpoint, strings.NewReader(payload))
		if e != nil {
			return nil, errors.New("Invalid ONVIF endpoint")
		}
		req.Header.Set("Content-Type", `application/soap+xml; charset=utf-8; action="`+namespace+`/`+operation+`"`)
		req.Header.Set("SOAPAction", `"`+namespace+`/`+operation+`"`)
		if authorization != "" {
			req.Header.Set("Authorization", authorization)
		}
		res, e := c.http.Do(req)
		if e != nil {
			return nil, errors.New("ONVIF request failed. Check device IP, service port, network/VPN and HTTPS certificate trust")
		}
		raw, readErr := io.ReadAll(io.LimitReader(res.Body, (1<<20)+1))
		res.Body.Close()
		if readErr != nil || len(raw) > 1<<20 {
			return nil, errors.New("ONVIF response unavailable or too large")
		}
		if res.StatusCode == 401 && attempt == 0 && c.conn.Username != "" {
			for _, challenge := range res.Header.Values("WWW-Authenticate") {
				if strings.HasPrefix(strings.ToLower(challenge), "digest ") {
					authorization, e = digestAuth179(challenge, "POST", req.URL.RequestURI(), c.conn.Username, c.conn.Password)
					break
				}
				if strings.HasPrefix(strings.ToLower(challenge), "basic ") {
					authorization = "Basic " + base64.StdEncoding.EncodeToString([]byte(c.conn.Username+":"+c.conn.Password))
				}
			}
			if authorization != "" && e == nil {
				continue
			}
		}
		if res.StatusCode == 401 || res.StatusCode == 403 {
			return nil, errors.New("ONVIF authentication rejected. Check the device/ONVIF user, password, permissions and device clock")
		}
		if res.StatusCode != 200 {
			return nil, fmt.Errorf("ONVIF %s rejected (HTTP %d)", operation, res.StatusCode)
		}
		n, e := parseXML179(raw)
		if e != nil {
			return nil, e
		}
		if n.first("Fault") != nil {
			return nil, errors.New("ONVIF SOAP operation rejected. Check ONVIF support, credentials, permissions and device clock")
		}
		if n.first(operation+"Response") == nil {
			return nil, errors.New("Unexpected ONVIF response")
		}
		return n, nil
	}
	return nil, errors.New("ONVIF authentication failed")
}

type ONVIFProfile179 struct {
	Token    string `json:"token"`
	Name     string `json:"name"`
	Encoding string `json:"encoding"`
	Width    string `json:"width"`
	Height   string `json:"height"`
	Service  string `json:"service"`
}
type ONVIFResult179 struct {
	Manufacturer     string            `json:"manufacturer"`
	Model            string            `json:"model"`
	Serial           string            `json:"serial"`
	Firmware         string            `json:"firmware"`
	Profiles         []ONVIFProfile179 `json:"profiles"`
	InformationKnown bool              `json:"informationKnown"`
	Source           string            `json:"-"`
}

func readONVIF179(ctx context.Context, conn CameraConnection179, stream bool) (ONVIFResult179, error) {
	result := ONVIFResult179{Profiles: []ONVIFProfile179{}}
	client := newONVIF179(conn)
	defer client.http.CloseIdleConnections()
	scheme := "http"
	if conn.HTTPS {
		scheme = "https"
	}
	device := scheme + "://" + net.JoinHostPort(conn.Host, strconv.Itoa(conn.ONVIFPort)) + conn.DevicePath
	if t, e := client.soap(ctx, device, deviceNS179, "GetSystemDateAndTime", "", false); e == nil {
		if utc := t.first("UTCDateTime"); utc != nil {
			part := func(k string) int { v, _ := strconv.Atoi(utc.value(k)); return v }
			year := part("Year")
			if year >= 2000 && year <= 2200 {
				clock := time.Date(year, time.Month(part("Month")), part("Day"), part("Hour"), part("Minute"), part("Second"), 0, time.UTC)
				client.offset = time.Until(clock)
			}
		}
	}
	if info, e := client.soap(ctx, device, deviceNS179, "GetDeviceInformation", "", true); e == nil {
		result.Manufacturer = trimSpace(info.value("Manufacturer"), 200)
		result.Model = trimSpace(info.value("Model"), 200)
		result.Serial = trimSpace(info.value("SerialNumber"), 200)
		result.Firmware = trimSpace(info.value("FirmwareVersion"), 200)
		result.InformationKnown = true
	}
	endpoints := map[string]string{}
	if caps, e := client.soap(ctx, device, deviceNS179, "GetCapabilities", "<m:Category>Media</m:Category>", true); e == nil {
		if media := caps.first("Media"); media != nil {
			endpoints[mediaNS179] = media.value("XAddr")
		}
	}
	// GetServices is used when Media1 is absent, and as a fallback for Media2-only devices.
	services := func() {
		if nodes, e := client.soap(ctx, device, deviceNS179, "GetServices", "<m:IncludeCapability>false</m:IncludeCapability>", true); e == nil {
			for _, n := range nodes.all("Service") {
				ns := n.value("Namespace")
				if ns == mediaNS179 || ns == media2NS179 {
					endpoints[ns] = n.value("XAddr")
				}
			}
		}
	}
	if endpoints[mediaNS179] == "" {
		services()
	}
	selectedNamespace, selectedEndpoint := "", ""
	readProfiles := func(ns string) bool {
		ep := endpoints[ns]
		if ep == "" {
			return false
		}
		profiles, e := client.soap(ctx, ep, ns, "GetProfiles", "", true)
		if e != nil {
			return false
		}
		for _, p := range profiles.all("Profiles") {
			token := p.Attrs["token"]
			if token == "" {
				token = p.value("Token")
			}
			if token == "" || len(token) > 256 {
				continue
			}
			result.Profiles = append(result.Profiles, ONVIFProfile179{Token: token, Name: trimSpace(p.value("Name"), 120), Encoding: trimSpace(p.value("Encoding"), 40), Width: p.value("Width"), Height: p.value("Height"), Service: map[bool]string{true: "Media2", false: "Media"}[ns == media2NS179]})
			if len(result.Profiles) >= 128 {
				break
			}
		}
		if len(result.Profiles) == 0 {
			return false
		}
		selectedNamespace = ns
		selectedEndpoint = ep
		return true
	}
	if !readProfiles(mediaNS179) {
		services()
		if !readProfiles(media2NS179) {
			return result, errors.New("No ONVIF Media/Media2 video profiles could be read. Enable ONVIF, check the service port and account, or use an exact RTSP URL")
		}
	}
	if !stream {
		return result, nil
	}
	token := conn.ProfileToken
	if token == "" {
		return result, errors.New("Read the ONVIF profiles and select a video profile first")
	}
	found := false
	for _, p := range result.Profiles {
		if p.Token == token {
			found = true
		}
	}
	if !found {
		return result, errors.New("The selected ONVIF profile is no longer available; read profiles again")
	}
	inside := `<m:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></m:StreamSetup><m:ProfileToken>` + xmlEscape179(token) + `</m:ProfileToken>`
	if selectedNamespace == media2NS179 {
		inside = `<m:Protocol>RtspUnicast</m:Protocol><m:ProfileToken>` + xmlEscape179(token) + `</m:ProfileToken>`
	}
	uri, e := client.soap(ctx, selectedEndpoint, selectedNamespace, "GetStreamUri", inside, true)
	if e != nil {
		return result, e
	}
	u, e := validateCameraURL(uri.value("Uri"))
	if e != nil {
		return result, errors.New("ONVIF returned an invalid video URI")
	}
	if !strings.EqualFold(u.Hostname(), conn.Host) {
		return result, errors.New("ONVIF stream host differs from the configured device. Use the exact RTSP URL and reachable address explicitly")
	}
	result.Source, e = sourceWithCredentials179(u.String(), conn.Username, conn.Password)
	return result, e
}
