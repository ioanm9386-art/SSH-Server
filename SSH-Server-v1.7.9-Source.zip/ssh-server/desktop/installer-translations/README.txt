Hindi and Yoruba translation files originate from the pinned NSIS 3.0.4.1 build
distribution. Hindi.nsh had one missing closing quote in the per-user install
message. Yoruba.nsh had a misplaced opening quote in the finish-page message.
Only quotation delimiters were corrected; translated words were not changed.
The original file headers and attribution are preserved.
