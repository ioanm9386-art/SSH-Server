//go:build !windows

package main

import (
	"errors"
	"io"
	"net"
	"os"
	"time"
)

func openSSHAgent() (io.ReadWriteCloser, error) {
	p := os.Getenv("SSH_AUTH_SOCK")
	if p == "" {
		return nil, errors.New("SSH_AUTH_SOCK is not set")
	}
	return net.DialTimeout("unix", p, 5*time.Second)
}
