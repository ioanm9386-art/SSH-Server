# Semnarea SSH Server

Versiunea pentru testare este nesemnată. Aceste fișiere pregătesc procesul de publicare, fără a crea un certificat și fără a dezactiva protecțiile Windows.

Pentru o versiune semnată, pe o mașină Windows de compilare:

- Configurează certificatul public recunoscut al editorului prin `WIN_CSC_LINK` / `WIN_CSC_KEY_PASSWORD` în secretele sistemului de compilare, sau `SSH_SERVER_CERT_SHA1` pentru un certificat accesibil din Windows Certificate Store și tokenul hardware aferent.
- Setează `SSH_SERVER_SIGN_RELEASE=1` și `SSH_SERVER_PUBLISHER` exact ca în certificatul verificat.
- Rulează BUILD-WINDOWS.ps1. Modul semnat oprește compilarea dacă lipsesc credențialele de semnare. Verificarea finală cere semnături Authenticode valide pentru aplicație, motor și instalator.
- Nu pune certificatul privat sau parola lui în GitHub, în ZIP-ul surselor sau în conversație. Nu modifica executabilele după semnare.

Configurația este pentru electron-builder 26.18.0. Semnarea reală și verificarea pe Windows trebuie efectuate când există un certificat valid; nu au fost executate în această versiune de test. Un certificat autosemnat nu acordă încredere publică. Semnarea publică nu garantează că un fișier nou va evita imediat SmartScreen.

Microsoft Store/MSIX este un traseu de distribuție separat; acest pachet nu este deja certificat sau publicat în Store.
